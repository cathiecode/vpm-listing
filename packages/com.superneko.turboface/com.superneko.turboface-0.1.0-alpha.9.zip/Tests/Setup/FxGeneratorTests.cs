using NUnit.Framework;

#nullable enable

namespace com.superneko.TurboFace.Tests.Setup
{
    using System;
    using System.Linq;
    using com.superneko.TurboFace.Editor;
    using com.superneko.TurboFace.Editor.Setup;
    using com.superneko.TurboFace.Editor.Setup.HeuristicAnimatorControllerParser;
    using com.superneko.TurboFace.Editor.Setup.VirtualController;
    using com.superneko.TurobFace.Editor;
    using Editor.Setup.Processor;
    using UnityEditor;
    using UnityEngine;

    class FxGeneratorTests
    {
        [Test]
        public void Scenario()
        {
            var generator = new FxGenerator(new NullAssetJar());

            var avatarLikeObject = new GameObject();
            var smr = avatarLikeObject.AddComponent<SkinnedMeshRenderer>();

            var avatarData = new AvatarData("Test Avatar", avatarLikeObject.transform, smr, new string[] { }, Vector3.zero, Vector3.forward);

            var defaultAnimationClipA = new AnimationClipBuilder().WithName("Default Animation Clip A").FloatCurve(typeof(SkinnedMeshRenderer), "body", "blendShape.id_defaultA").ToAnimationClip();
            var defaultAnimationClipB = new AnimationClipBuilder().WithName("Default Animation Clip B").FloatCurve(typeof(SkinnedMeshRenderer), "body", "blendShape.id_defaultB").ToAnimationClip();

            var animationClipA = new AnimationClipBuilder()
                .WithName("Animation Clip A")
                .FloatCurve(typeof(SkinnedMeshRenderer), "body", "blendShape.id_A").ToAnimationClip();
            var animationClipB = new AnimationClipBuilder()
                .WithName("Animation Clip B")
                .FloatCurve(typeof(SkinnedMeshRenderer), "body", "blendShape.id_B").ToAnimationClip();
            var animationClipC = new AnimationClipBuilder()
                .WithName("Animation Clip C")
                .FloatCurve(typeof(SkinnedMeshRenderer), "body", "blendShape.id_C").ToAnimationClip();
            var animationClipD = new AnimationClipBuilder()
                .WithName("Animation Clip D")
                .FloatCurve(typeof(SkinnedMeshRenderer), "body", "blendShape.id_D").ToAnimationClip();

            var setupData = new SetupData()
            {
                BlinkingSettings = new(BlinkingAnimationMode.UseBuiltInAnimation, new AssetReference<AnimationClip>(null)),
                ExpressionSets = new ExpressionSetData[]
                {
                    new()
                    {
                        Name = "A",
                        DefaultExpression = new ExpressionData()
                        {
                            AnimationClip = new AssetReference<AnimationClip>(defaultAnimationClipA),
                            CompatibleWithBlinking = true,
                            CompatibleWithEyeMovements = true,
                            CompatibleWithLipsync = true,
                            ShouldCancelMouthMorphing = false,
                            GestureRules = new GestureRuleData[] { }
                        },
                        Expressions = new ExpressionData[]
                        {
                            new()
                            {
                                AnimationClip = new AssetReference<AnimationClip>(animationClipA),
                                CompatibleWithBlinking = true,
                                CompatibleWithEyeMovements = true,
                                CompatibleWithLipsync = true,
                                ShouldCancelMouthMorphing = true,
                                GestureRules = new GestureRuleData[]
                                {
                                    new()
                                    {
                                        Hand = HandData.Left,
                                        Gesture = GestureData.Fist,
                                    }
                                }
                            },
                            new()
                            {
                                AnimationClip = new AssetReference<AnimationClip>(animationClipB),
                                CompatibleWithBlinking = false,
                                CompatibleWithEyeMovements = false,
                                CompatibleWithLipsync = false,
                                ShouldCancelMouthMorphing = false,
                                GestureRules = new GestureRuleData[]
                                {
                                    new()
                                    {
                                        Hand = HandData.Right,
                                        Gesture = GestureData.Fist,
                                    }
                                }
                            }
                        }
                    },
                    new()
                    {
                        Name = "B",
                        DefaultExpression = new ExpressionData()
                        {
                            AnimationClip = new AssetReference<AnimationClip>(defaultAnimationClipB),
                            CompatibleWithBlinking = true,
                            CompatibleWithEyeMovements = true,
                            CompatibleWithLipsync = true,
                            ShouldCancelMouthMorphing = false,
                            GestureRules = new GestureRuleData[] { }
                        },
                        Expressions = new ExpressionData[]
                        {
                            new()
                            {
                                AnimationClip = new AssetReference<AnimationClip>(animationClipC),
                                CompatibleWithBlinking = true,
                                CompatibleWithEyeMovements = true,
                                CompatibleWithLipsync = true,
                                ShouldCancelMouthMorphing = false,
                                GestureRules = new GestureRuleData[]
                                {
                                    new()
                                    {
                                        Hand = HandData.Left,
                                        Gesture = GestureData.Neutral,
                                    }
                                }
                            }
                        }
                    }
                }
            };

            Func<Node, bool> NodePlayingAnimationClipOriginatedFrom(AnimationClip originalClip)
            {
                return node =>
                {
                    if (node is not VirtualState virtualState)
                    {
                        return false;
                    }

                    if (virtualState.BaseState.motion == null)
                    {
                        return false;
                    }

                    if (virtualState.BaseState.motion is not AnimationClip playingClip)
                    {
                        return false;
                    }

                    return AnimationClipIsOriginatedFrom(playingClip, originalClip);
                };
            }

            var setup = new Setup(setupData);

            var compiledSetup = CompiledSetup.Compile(avatarData, setup, new NullAssetJar());

            var animatorController = generator.Generate(compiledSetup);

            // NOTE: We use VRCVirtualContorller to emulate the behaviour of the generated animator controller because actual animator controller is difficult to test.

            var parameterRegistry = new VRCParameterRegistry(Gesture.Neutral, Gesture.Neutral);

            var virtualControllerGraph = new VirtualAnimatorControllerGraph(animatorController);

            var runner = new VRCAnimatorControllerGraphRunner(virtualControllerGraph, parameterRegistry);

            // Preheat
            runner.StepUntilStop();

            // Set A

            parameterRegistry.Set("GestureLeft", 1f); // Fist

            runner.StepUntilStop();

            Assert.IsTrue(
                runner.EnumerateCurrentNodes().Any(NodePlayingAnimationClipOriginatedFrom(animationClipA)),
                "Expected to be in the state with Animation Clip A, but was not."
            );

            Assert.IsTrue(
                runner.EnumerateCurrentNodes().Any(NodePlayingAnimationClipOriginatedFrom(defaultAnimationClipA)),
                "Expected to be in the state with Default Animation Clip A, but was not."
            );

            Assert.IsTrue(runner.IsEyeTrackingEnabled); // CompatibleWithEyeMovements is true
            Assert.IsTrue(runner.IsMouthTrackingEnabled); // CompatibleWithLipsync is true

            // We also need to gesture priority so don't reset GestureRight to Neutral
            parameterRegistry.Set("GestureRight", 1f); // Fist

            runner.StepUntilStop();

            Assert.IsTrue(
                runner.EnumerateCurrentNodes().Any(NodePlayingAnimationClipOriginatedFrom(animationClipB)),
                "Expected to be in the state with Animation Clip B, but was not."
            );

            Assert.IsTrue(
                runner.EnumerateCurrentNodes().Any(NodePlayingAnimationClipOriginatedFrom(defaultAnimationClipA)),
                "Expected to be in the state with Default Animation Clip A, but was not."
            );

            Assert.IsFalse(runner.IsEyeTrackingEnabled); // CompatibleWithEyeMovements is false
            Assert.IsFalse(runner.IsMouthTrackingEnabled); // CompatibleWithLipsync is false

            // Set B

            parameterRegistry.Set("EM_EMOTE_PATTERN", 1f); // Emote Pattern 1

            runner.StepUntilStop();

            // Make sure that previous set does not affecting animation
            Assert.IsTrue(
                !runner.EnumerateCurrentNodes().Any(NodePlayingAnimationClipOriginatedFrom(animationClipB)),
                "Expected to not be in the state with Animation Clip B, but was."
            );

            Assert.IsTrue(
                !runner.EnumerateCurrentNodes().Any(NodePlayingAnimationClipOriginatedFrom(defaultAnimationClipA)),
                "Expected to not be in the state with Default Animation Clip A, but was."
            );

            parameterRegistry.Set("GestureLeft", 0f); // Neutral
            parameterRegistry.Set("GestureRight", 0f); // Neutral

            runner.StepUntilStop();

            Assert.IsTrue(
                runner.EnumerateCurrentNodes().Any(NodePlayingAnimationClipOriginatedFrom(animationClipC)),
                "Expected to be in the state with Animation Clip C, but was not."
            );

            // Menu selection
            parameterRegistry.Set("CN_EMOTE_PRELOCK_ENABLE", 1f); // Select Emote

            runner.StepUntilStop();

            parameterRegistry.Set("GestureLeft", 1f); // Some random gesture
            parameterRegistry.Set("GestureRight", 1f); // Some random gesture

            // NOTE: Because of default expression, the index of animationClipB is offset by 1
            parameterRegistry.Set("SYNC_EM_EMOTE", 2f); // Second emote(B)

            runner.StepUntilStop();

            Assert.IsTrue(
                runner.EnumerateCurrentNodes().Any(NodePlayingAnimationClipOriginatedFrom(animationClipB)),
                "Expected to be in the state with Animation Clip B, but was not."
            );
        }

        bool AnimationClipIsOriginatedFrom(AnimationClip clip, AnimationClip originalClip)
        {
            var originalClipBindings = AnimationUtility.GetCurveBindings(originalClip);

            return AnimationUtility.GetCurveBindings(clip)
                .Any(b => originalClipBindings.Any(
                        ob => ob.path == b.path && ob.propertyName == b.propertyName && ob.type == b.type
                    )
                );
        }
    }
}
