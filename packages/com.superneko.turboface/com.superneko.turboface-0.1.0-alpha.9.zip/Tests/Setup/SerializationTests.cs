namespace com.superneko.TurboFace.Tests.Setup
{
    using System.IO;
    using com.superneko.TurboFace.Runtime.Setup;
    using NUnit.Framework;
    using TurboFace.Editor.Setup;
    using UnityEditor;
    using UnityEngine;

    class SerializationTests
    {
        [Test]
        public void ParseSetupV3()
        {
            var path = "Packages/com.superneko.turboface/Tests/TestAssets/SetupV3.json";

            var json = File.ReadAllText(path);

            var wrapper = new SerializedDataWrapper()
            {
                Version = 3,
                Body = json
            };

            var setupData = SetupSerializer.Deserialize(wrapper);

            AssertSetupDataV3(setupData);
        }

        [Test]
        public void SerializeSetup()
        {
            var emptyAnimationClipPath = "Packages/com.superneko.turboface/Tests/TestAssets/Empty Animation Clip.anim";

            var emptyAnimationClip = AssetDatabase.LoadAssetAtPath<AnimationClip>(emptyAnimationClipPath);

            var setup = new SetupData()
            {
                BlinkingSettings = new(
                    BlinkingAnimationMode.GenerateFromEyeClosingAnimation,
                    new AssetReference<AnimationClip>(emptyAnimationClip)
                ),
                ExpressionSets = new ExpressionSetData[]
                {
                    new()
                    {
                        Name = "A 日本語 👨‍👩‍👦‍👦",
                        DefaultExpression = new()
                        {
                            AnimationClip = new AssetReference<AnimationClip>(emptyAnimationClip),
                        },
                        Expressions = new ExpressionData[]
                        {
                            new()
                            {
                                AnimationClip = new AssetReference<AnimationClip>(emptyAnimationClip),
                                CompatibleWithBlinking = true,
                                CompatibleWithEyeMovements = true,
                                CompatibleWithLipsync = true,
                                ShouldCancelMouthMorphing = true,
                                GestureRules = new GestureRuleData[]
                                {
                                    new()
                                    {
                                        Gesture = GestureData.Fist,
                                        Hand = HandData.Right
                                    },
                                    new()
                                    {
                                        Gesture = GestureData.Neutral,
                                        Hand = HandData.Left
                                    }
                                }
                            },
                            new()
                            {
                                AnimationClip = new AssetReference<AnimationClip>(null),
                                CompatibleWithBlinking = false,
                                CompatibleWithEyeMovements = false,
                                CompatibleWithLipsync = false,
                                ShouldCancelMouthMorphing = false,
                                GestureRules = new GestureRuleData[0]
                            }
                        }
                    },
                    new()
                    {
                        Name = "B",
                        DefaultExpression = new()
                        {
                            AnimationClip = new AssetReference<AnimationClip>(null),
                        },
                        Expressions = new ExpressionData[0]
                    },
                    new()
                    {
                        Name = "C",
                        DefaultExpression = new()
                        {
                            AnimationClip = new AssetReference<AnimationClip>(null),
                        },
                        Expressions = new ExpressionData[0]
                    }
                }
            };

            var wrapper = SetupSerializer.Serialize(setup);

            var setupData = SetupSerializer.Deserialize(wrapper);

            // Setup
            Assert.AreEqual(setupData.BlinkingSettings.BlinkingAnimationMode, BlinkingAnimationMode.GenerateFromEyeClosingAnimation);
            Assert.AreEqual(setupData.BlinkingSettings.AnimationClipForBlinking.Instance.name, "Empty Animation Clip");

            // ExpressionSets 1
            Assert.AreEqual(setupData.ExpressionSets[0].Name, "A 日本語 👨‍👩‍👦‍👦");
            Assert.AreEqual(setupData.ExpressionSets[0].DefaultExpression.AnimationClip.Instance.name, "Empty Animation Clip");

            // Expressions 1
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions.Length, 2);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].AnimationClip.Instance.name, "Empty Animation Clip");
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].CompatibleWithBlinking, true);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].CompatibleWithEyeMovements, true);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].CompatibleWithLipsync, true);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].ShouldCancelMouthMorphing, true);

            // GestureRules
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules.Length, 2);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules[0].Gesture, GestureData.Fist);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules[0].Hand, HandData.Right);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules[1].Gesture, GestureData.Neutral);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules[1].Hand, HandData.Left);

            // Expressions 2
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].AnimationClip.Instance, null);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].CompatibleWithBlinking, false);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].CompatibleWithEyeMovements, false);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].CompatibleWithLipsync, false);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].ShouldCancelMouthMorphing, false);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].GestureRules.Length, 0);

            // ExpressionSets 2
            Assert.AreEqual(setupData.ExpressionSets[1].Name, "B");
            Assert.AreEqual(setupData.ExpressionSets[1].DefaultExpression.AnimationClip.Instance, null);
            Assert.AreEqual(setupData.ExpressionSets[1].Expressions.Length, 0);

            // ExpressionSets 3
            Assert.AreEqual(setupData.ExpressionSets[2].Name, "C");
            Assert.AreEqual(setupData.ExpressionSets[2].DefaultExpression.AnimationClip.Instance, null);
            Assert.AreEqual(setupData.ExpressionSets[2].Expressions.Length, 0);
        }

        static void AssertSetupDataV3(SetupData setupData)
        {
            // NOTE: expected and actual are swapped as yoda for readability

            // Setup
            Assert.AreEqual(setupData.BlinkingSettings.BlinkingAnimationMode, BlinkingAnimationMode.UseBuiltInAnimation); // Migrated from first set
            Assert.AreEqual(setupData.BlinkingSettings.AnimationClipForBlinking.Instance, null); // Migrated from first set

            // ExpressionSets 1
            Assert.AreEqual(setupData.ExpressionSets[0].Name, "A 日本語 👨‍👩‍👦‍👦");
            Assert.AreEqual(setupData.ExpressionSets[0].DefaultExpression.AnimationClip.Instance.name, "Empty Animation Clip");// Migrated from DefaultFaceAnimationClip

            // Expressions 1
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions.Length, 2);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].AnimationClip.Instance.name, "Empty Animation Clip");
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].CompatibleWithBlinking, true);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].CompatibleWithEyeMovements, true);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].CompatibleWithLipsync, true);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].ShouldCancelMouthMorphing, true);

            // GestureRules
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules.Length, 2);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules[0].Gesture, GestureData.Fist);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules[0].Hand, HandData.Right);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules[1].Gesture, GestureData.Neutral);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[0].GestureRules[1].Hand, HandData.Left);

            // Expressions 2
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].AnimationClip.Instance, null);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].CompatibleWithBlinking, false);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].CompatibleWithEyeMovements, false);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].CompatibleWithLipsync, false);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].ShouldCancelMouthMorphing, false);
            Assert.AreEqual(setupData.ExpressionSets[0].Expressions[1].GestureRules.Length, 0);

            // ExpressionSets 2
            Assert.AreEqual(setupData.ExpressionSets[1].Name, "B");
            Assert.AreEqual(setupData.ExpressionSets[1].DefaultExpression.AnimationClip.Instance, null); // Migrated from DefaultFaceAnimationClip
            Assert.AreEqual(setupData.ExpressionSets[1].Expressions.Length, 0);

            // ExpressionSets 3
            Assert.AreEqual(setupData.ExpressionSets[2].Name, "C");
            Assert.AreEqual(setupData.ExpressionSets[2].DefaultExpression.AnimationClip.Instance, null); // Migrated from DefaultFaceAnimationClip
            Assert.AreEqual(setupData.ExpressionSets[2].Expressions.Length, 0);
        }
    }
}
