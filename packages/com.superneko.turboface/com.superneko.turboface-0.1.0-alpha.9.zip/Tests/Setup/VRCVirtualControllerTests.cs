using System.Linq;
using com.superneko.TurboFace.Editor.Setup.HeuristicAnimatorControllerParser;
using com.superneko.TurboFace.Editor.Setup.VirtualController;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Animations;

namespace com.superneko.TurboFace.Tests.Setup
{
    class VRCVirtualControllerTests
    {
        [Test]
        public void SimpleParameterTest()
        {
            var vrcSimpleAnimatorControllerPath = "Packages/com.superneko.turboface/Tests/TestAssets/VRCSimpleAnimatorController.controller";

            var vrcSimpleAnimatorController = AssetDatabase.LoadAssetAtPath<AnimatorController>(vrcSimpleAnimatorControllerPath);

            var parameterRegistry = new VRCParameterRegistry(Editor.Setup.Gesture.Neutral, Editor.Setup.Gesture.Fist);

            var virtualControllerGraph = new VirtualAnimatorControllerGraph(vrcSimpleAnimatorController);

            var runner = new VRCAnimatorControllerGraphRunner(virtualControllerGraph, parameterRegistry);

            runner.StepUntilStop();

            var lastState = runner.EnumerateLayerRunners().First().CurrentState;

            if (lastState is not VirtualState virtualState)
            {
                Assert.Fail($"Expected to end in a VirtualState, but ended in {lastState}");
                return;
            }

            Assert.AreEqual(virtualState.BaseState.name, "GestureRight is Fist");
        }

        [Test]
        public void VRCControllerWithParameterDriver()
        {
            var vrcControllerWithParameterDriverPath = "Packages/com.superneko.turboface/Tests/TestAssets/VRCControllerWithParameterDriver.controller";

            var vrcControllerWithParameterDriver = AssetDatabase.LoadAssetAtPath<AnimatorController>(vrcControllerWithParameterDriverPath);

            var parameterRegistry = new VRCParameterRegistry(Editor.Setup.Gesture.Neutral, Editor.Setup.Gesture.Fist);

            var virtualControllerGraph = new VirtualAnimatorControllerGraph(vrcControllerWithParameterDriver);

            var runner = new VRCAnimatorControllerGraphRunner(virtualControllerGraph, parameterRegistry);

            runner.StepUntilStop();

            AssertAllFinalStateIsExpectedState(runner);
        }

        [Test]
        public void VRCControllerComplexSituation()
        {
            var vrcControllerComplexSituationPath = "Packages/com.superneko.turboface/Tests/TestAssets/VRCControllerComplexSituation.controller";

            var vrcControllerComplexSituation = AssetDatabase.LoadAssetAtPath<AnimatorController>(vrcControllerComplexSituationPath);

            var parameterRegistry = new VRCParameterRegistry(Editor.Setup.Gesture.Neutral, Editor.Setup.Gesture.Fist);

            var virtualControllerGraph = new VirtualAnimatorControllerGraph(vrcControllerComplexSituation);

            var runner = new VRCAnimatorControllerGraphRunner(virtualControllerGraph, parameterRegistry);

            runner.StepUntilStop();

            AssertAllFinalStateIsExpectedState(runner);
        }

        void AssertAllFinalStateIsExpectedState(AnimatorControllerGraphRunner runner)
        {
            foreach (var node in runner.EnumerateCurrentNodes())
            {
                if (node is VirtualState virtualState)
                {
                    Assert.AreEqual(virtualState.BaseState.name.StartsWith("ExpectedFinalState"), true, $"Expected to end in a state whose name starts with 'ExpectedFinalState', but ended in {virtualState.BaseState.name}");
                }
                else
                {
                    Assert.Fail($"Expected to end in a VirtualState, but ended in {node}");
                }
            }
        }
    }
}
