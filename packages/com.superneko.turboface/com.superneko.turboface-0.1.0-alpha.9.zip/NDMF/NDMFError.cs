using System.Collections.Generic;
using System.Linq;
using nadena.dev.ndmf;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.NDMF
{
    using Editor;

    abstract class NDMFError : SimpleError
    {
        readonly MessageKey messageKey;

        public override string TitleKey => messageKey + ".title";
        public override string DetailsKey => messageKey;
        public override string HintKey => messageKey + ".hint";

        internal NDMFError(MessageKey messageKey, GameObject gameObject)
        {
            this.messageKey = messageKey;
            AddReference(ObjectRegistry.GetReference(gameObject));
        }

        public override nadena.dev.ndmf.localization.Localizer Localizer => new("ja-JP", GetLocalizers);

        static List<(string, System.Func<string, string>)> GetLocalizers()
        {
            return Editor.Localizer.AvailableLanguages.AsEnumerable().Select(CreateLocalizerPair).ToList();
        }

        static (string, System.Func<string, string>) CreateLocalizerPair(string lang)
        {
            // NOTE: Lazy load
            Localizer? localizer = null;

            return (lang, key =>
                {
                    localizer ??= Editor.Localizer.Load(lang);
                    return localizer.GetTranslated(MessageKey.Get(key));
                }
            );
        }
    }
}
