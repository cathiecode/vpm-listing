using nadena.dev.ndmf;

namespace com.superneko.TurboFace.NDMF
{
    abstract class TurboFaceSetupPass<T> : Pass<T> where T: TurboFaceSetupPass<T>, new()
    {
        protected sealed override void Execute(BuildContext context)
        {
            var state = context.GetState<NDMFState>();

            if (state.IsSetupExists)
            {
                WhenSetupExists(context);
            }
        }

        protected abstract void WhenSetupExists(BuildContext context);
    }
}
