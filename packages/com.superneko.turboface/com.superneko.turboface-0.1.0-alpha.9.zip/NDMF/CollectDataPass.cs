using System.Linq;
using com.superneko.TurboFace.Runtime.Setup;
using nadena.dev.ndmf;

namespace com.superneko.TurboFace.NDMF
{
    class CollectDataPass : Pass<CollectDataPass>
    {
        public override string DisplayName => "Collect Setup Data";

        protected override void Execute(BuildContext context)
        {
            var state = context.GetState<NDMFState>();

            var components = context.AvatarRootTransform.GetComponentsInChildren<TurboFaceSetupComponent>();

            var component = components.LastOrDefault();

            if (component != null)
            {
                state.IsSetupExists = true;
            }
        }
    }
}
