using nadena.dev.ndmf;
using UnityEngine;

namespace com.superneko.TurboFace.NDMF
{
    using Editor;

    class NDMFUserError : NDMFError
    {
        public override ErrorSeverity Severity => ErrorSeverity.NonFatal;

        public NDMFUserError(MessageKey messageKey, GameObject gameObject) : base(messageKey, gameObject) {}
    }
}
