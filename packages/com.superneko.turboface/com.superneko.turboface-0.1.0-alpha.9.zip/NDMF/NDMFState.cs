namespace com.superneko.TurboFace.NDMF
{
    class NDMFState
    {
        public bool IsSetupExists = false;
    }
}
