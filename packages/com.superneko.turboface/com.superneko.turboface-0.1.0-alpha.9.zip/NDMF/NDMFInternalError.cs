using nadena.dev.ndmf;
using UnityEngine;

namespace com.superneko.TurboFace.NDMF
{
    using Editor;

    class NDMFIntrenalError : NDMFError
    {
        public override ErrorSeverity Severity => ErrorSeverity.InternalError;

        public NDMFIntrenalError(MessageKey messageKey, GameObject gameObject) : base(messageKey, gameObject) {}
    }
}
