using nadena.dev.ndmf;
using UnityEngine;

namespace com.superneko.TurboFace.NDMF
{
    using Editor;

    class NDMFUserWarning : NDMFError
    {
        public override ErrorSeverity Severity => ErrorSeverity.Information;

        public NDMFUserWarning(MessageKey messageKey, GameObject gameObject) : base(messageKey, gameObject) {}
    }
}
