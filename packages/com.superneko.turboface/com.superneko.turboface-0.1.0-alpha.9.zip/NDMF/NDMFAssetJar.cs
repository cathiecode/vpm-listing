using nadena.dev.ndmf;
using UnityEngine;

namespace com.superneko.TurboFace.NDMF
{
    using Editor;

    class NDMFAssetJar : IAssetJar
    {
        IAssetSaver assetSaver;

        public NDMFAssetJar(IAssetSaver assetSaver)
        {
            this.assetSaver = assetSaver;
        }

        public void AddAsset(Object asset)
        {
            assetSaver.SaveAsset(asset);
        }
    }
}
