using System.Linq;
using com.superneko.TurboFace.Editor.Setup.Processor;
using com.superneko.TurboFace.Runtime.Setup;
using nadena.dev.ndmf;
using UnityEngine;

namespace com.superneko.TurboFace.NDMF
{
    using Editor;

    class GenerateMAComponentsPass : TurboFaceSetupPass<GenerateMAComponentsPass>
    {
        protected override void WhenSetupExists(BuildContext context)
        {
            var components = context.AvatarRootTransform.GetComponentsInChildren<TurboFaceSetupComponent>();

            var component = components.LastOrDefault();

            if (component == null)
            {
                return;
            }

            if (components.Count() > 1)
            {
                ErrorReport.ReportError(new NDMFUserWarning(MessageKey.Get("warn.multiple-components"), components.First().gameObject));
            }

            var assetJar = new NDMFAssetJar(context.AssetSaver);
            Generator.Generate(component, assetJar);

            foreach (var foundComponent in components)
            {
                Object.DestroyImmediate(foundComponent);
            }
        }
    }
}
