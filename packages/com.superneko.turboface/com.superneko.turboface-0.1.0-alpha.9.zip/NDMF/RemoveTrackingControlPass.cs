using System.Collections.Immutable;
using System.Data;
using System.Linq;
using nadena.dev.ndmf;
using nadena.dev.ndmf.animator;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace com.superneko.TurboFace.NDMF
{
    class RemoveTrackingControlPass : TurboFaceSetupPass<RemoveTrackingControlPass>
    {
        protected override void WhenSetupExists(BuildContext context)
        {
            context.ActivateExtensionContext<VirtualControllerContext>();

            var virtualControllerContext = context.Extension<VirtualControllerContext>();

            var controllers = virtualControllerContext.GetAllControllers();

            foreach (var controller in controllers)
            {
                Logging.Trace(() => $"Processing controller: {controller}");

                foreach (var layer in controller.Layers)
                {
                    ProcessStateMachine(layer.StateMachine);
                }
            }

            context.DeactivateExtensionContext<VirtualControllerContext>();
        }

        static void ProcessStateMachine(VirtualStateMachine stateMachine)
        {
            // NOTE: Reassining immutablelist results in duplicated behaviour(s) so we need to modify them directly
            ProcessBehaviours(stateMachine.Behaviours);

            foreach (var childState in stateMachine.States)
            {
                ProcessBehaviours(childState.State.Behaviours);
            }

            foreach (var childStateMachine in stateMachine.StateMachines)
            {
                ProcessStateMachine(childStateMachine.StateMachine);
            }
        }

        static void ProcessBehaviours(ImmutableList<StateMachineBehaviour> immutableBehaviours)
        {
            // NOTE: NDMF internally clones behaviours so we can modify them directly
            foreach (var behaviour in immutableBehaviours)
            {
                switch (behaviour)
                {
                    case VRCAnimatorTrackingControl trackingControl:
                        if (trackingControl.trackingEyes != VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.NoChange || trackingControl.trackingMouth != VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.NoChange)
                        {
                            trackingControl.trackingEyes = VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.NoChange;
                            trackingControl.trackingMouth = VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.NoChange;
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
