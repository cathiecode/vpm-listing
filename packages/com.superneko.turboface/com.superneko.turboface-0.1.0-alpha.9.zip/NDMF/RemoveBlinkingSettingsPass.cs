using nadena.dev.ndmf;
using VRC.SDK3.Avatars.Components;

namespace com.superneko.TurboFace.NDMF
{
    class RemoveBlinkingSettingsPass : TurboFaceSetupPass<RemoveBlinkingSettingsPass>
    {
        protected override void WhenSetupExists(BuildContext context)
        {
            var descriptor = context.AvatarRootObject.GetComponent<VRCAvatarDescriptor>();

            if (descriptor == null)
            {
                Logging.Warn("Avatar root object does not have VRCAvatarDescriptor component");
                return;
            }

            // TODO: In future, we may want to add an option to disable blinking-related features
            if (descriptor.customEyeLookSettings.eyelidsBlendshapes.Length > 0)
            {
                descriptor.customEyeLookSettings.eyelidsBlendshapes[0] = -1;
            }
        }
    }
}
