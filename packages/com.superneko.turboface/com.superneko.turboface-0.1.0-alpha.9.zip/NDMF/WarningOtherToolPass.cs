using System.Linq;
using nadena.dev.ndmf;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.NDMF
{
    using Editor;

    class WarningOtherToolPass : TurboFaceSetupPass<WarningOtherToolPass>
    {
        public override string DisplayName => "Warning about other tools";

        protected override void WhenSetupExists(BuildContext context)
        {
            // likely-FaceEmo
            var faceEmo = context.AvatarRootObject.transform.Find("FaceEmoPrefab");

            if (faceEmo != null)
            {
                ErrorReport.ReportError(new NDMFUserError(MessageKey.Get("warn.othertool"), faceEmo.gameObject));
            }

            // likely-lilemo
            var lilEmo = context.AvatarRootObject.transform
                .GetComponentsInChildren<Transform>(true)
                .FirstOrDefault(transform => transform.GetComponent("Emo") != null);
            
            if (lilEmo != null)
            {
                ErrorReport.ReportError(new NDMFUserError(MessageKey.Get("warn.othertool"), lilEmo.gameObject));
            }

            // likely-Generated TurboFace Setup
            var generatedSetup = context.AvatarRootObject.transform.Find("TurboFace Setup (Generated)");

            if (generatedSetup != null)
            {
                ErrorReport.ReportError(new NDMFUserError(MessageKey.Get("warn.othertool"), generatedSetup.gameObject));
            }
        }
    }
}
