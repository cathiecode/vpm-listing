using nadena.dev.ndmf;

[assembly: ExportsPlugin(typeof(com.superneko.TurboFace.NDMF.TurboFaceSetupPlugin))]
namespace com.superneko.TurboFace.NDMF
{
    public class TurboFaceSetupPlugin : Plugin<TurboFaceSetupPlugin>
    {
        public override string DisplayName => "TurboFace Setup";

        protected override void Configure()
        {   
            InPhase(BuildPhase.Resolving)
                .Run(new CollectDataPass())
                .Then.Run(new WarningOtherToolPass());

            InPhase(BuildPhase.Generating)
                .Run(new GenerateMAComponentsPass());

            InPhase(BuildPhase.Transforming)
                .Run(new RemoveBlinkingSettingsPass())
                .Then.Run(new RemoveTrackingControlPass())
                .BeforePlugin("nadena.dev.modular-avatar");
        }
    }
}
