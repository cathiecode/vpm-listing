using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace Anatawa12.AnimatorControllerAsACode.Framework
{
    public sealed class Acc : IACCParameterHolder
    {
        private readonly string _layerBaseName;
        public readonly AccConfig Config;
        public readonly AnimatorController Controller;
        private readonly List<AccLayer> _addingLayers = new List<AccLayer>();
        private readonly IAssetSaver _assetSaver;

        public Acc(string layerBaseName, AnimatorController controller, AccConfig config, IAssetSaver assetSaver)
        {
            _layerBaseName = layerBaseName;
            Config = config;
            Controller = controller;
            _assetSaver = assetSaver;
        }

        public AccLayer AddMainLayer() => DoAddLayer(_layerBaseName);
        public AccLayer AddLayer(string name) => DoAddLayer($"{_layerBaseName}_{name}");

        private AccLayer DoAddLayer(string layerName)
        {
            var layer = new AccLayer(new AnimatorControllerLayer
            {
                name = layerName,
                defaultWeight = 1,
                stateMachine = new AnimatorStateMachine
                {
                    name = layerName,
                    hideFlags = HideFlags.HideInHierarchy
                }
            }, this, _assetSaver);
            _addingLayers.Add(layer);
            _assetSaver.Save(layer.Layer.stateMachine);

            return layer;
        }

        public AccParameter<float> FloatParameter(string name, float defaultValue = 0f) => Parameter<float>(name, AnimatorControllerParameterType.Float, defaultValue);
        public AccParameter<int> IntParameter(string name, int defaultValue = 0) => Parameter<int>(name, AnimatorControllerParameterType.Int, defaultValue);
        public AccParameter<bool> BoolParameter(string name, bool defaultValue = false) => Parameter<bool>(name, AnimatorControllerParameterType.Bool, defaultValue ? 1f : 0f);

        public AccParameter<T> EnumParameter<T>(string name)
            where T : unmanaged, Enum =>
            Parameter<T>(name, AnimatorControllerParameterType.Int);

        private AccParameter<T> Parameter<T>(string name, AnimatorControllerParameterType type, float defaultValue = default)
            where T : unmanaged
        {
            var found = Controller.parameters.FirstOrDefault(x => x.name == name);
            if (found != null)
            {
                if (found.type != type)
                    throw new InvalidOperationException(
                        $"Parameter named {name} found but type is {found.type} which is not expected type, {type}");
                return new AccParameter<T>(found);
            }

            // add
            var parameter = new AnimatorControllerParameter
            {
                name = name,
                type = type,
                defaultFloat = type == AnimatorControllerParameterType.Float ? defaultValue : 0f,
                defaultInt = type == AnimatorControllerParameterType.Int ? (int)defaultValue : 0,
                defaultBool = type == AnimatorControllerParameterType.Bool ? defaultValue != 0f : false,
            };
            Controller.AddParameter(parameter);
            return new AccParameter<T>(parameter);
        }

        public AccClip NewClip()
        {
            var clip = new AnimationClip
            {
                hideFlags = HideFlags.HideInHierarchy
            };

            _assetSaver.Save(clip);

            return new AccClip(clip, Config);
        }

        public void SaveToAsset()
        {
            foreach (var layer in _addingLayers) layer.SaveToAsset();
            Controller.layers = Utils.JoinArray(Controller.layers, _addingLayers, x => x.Layer);
        }
    }

    public interface IACCParameterHolder
    {
        AccParameter<float> FloatParameter(string name, float defaultValue = 0f);
        AccParameter<int> IntParameter(string name, int defaultValue = 0);
        AccParameter<bool> BoolParameter(string name, bool defaultValue = false);
        AccParameter<T> EnumParameter<T>(string name)
            where T : unmanaged, Enum;
    }
}
