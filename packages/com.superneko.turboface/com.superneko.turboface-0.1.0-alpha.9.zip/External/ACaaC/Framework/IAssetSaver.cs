namespace Anatawa12.AnimatorControllerAsACode.Framework
{
    public interface IAssetSaver
    {
        void Save(UnityEngine.Object asset);
    }
}
