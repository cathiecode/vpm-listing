using System;
using UnityEditor.Animations;
using UnityEngine;

namespace Anatawa12.AnimatorControllerAsACode.Framework
{
    public sealed class AccLayer : IAccStateMachine, IACCParameterHolder
    {
        public readonly AnimatorControllerLayer Layer;
        private readonly AccStateMachineBase _machine;
        private readonly Acc _acc;

        public AccLayer(AnimatorControllerLayer layer, Acc acc, IAssetSaver assetSaver)
        {
            Layer = layer;
            _machine = new AccStateMachineBase(layer.stateMachine, acc.Config, assetSaver);
            _acc = acc;
        }

        public AccLayer WithMask(AvatarMask mask)
        {
            Layer.avatarMask = mask;
            return this;
        }

        #region IACCStateMachine delegateion
        public AccState NewState(string name) => _machine.NewState(name);
        public AccStateMachine NewSubStateMachine(string name) => _machine.NewSubStateMachine(name);
        public AccStateMachine ExistingSubStateMachine(AnimatorStateMachine stateMachine) => _machine.ExistingSubStateMachine(stateMachine);
        public AccEntryTransition EntryTransitionsTo(AccStateMachineMember state) => _machine.EntryTransitionsTo(state);
        public AccTransition AnyTransitionsTo(AccStateMachineMember state) => _machine.AnyTransitionsTo(state);
        #endregion

        public AccParameter<float> FloatParameter(string name, float defaultValue = 0f) => _acc.FloatParameter(name, defaultValue);
        public AccParameter<int> IntParameter(string name, int defaultValue = 0) => _acc.IntParameter(name, defaultValue);
        public AccParameter<bool> BoolParameter(string name, bool defaultValue = false) => _acc.BoolParameter(name, defaultValue);

        public AccParameter<T> EnumParameter<T>(string name)
            where T : unmanaged, Enum =>
            _acc.EnumParameter<T>(name);

        public void SaveToAsset()
        {
            _machine.SaveToAsset();
        }
    }
}
