#!/bin/sh

set -eu

cd "$(dirname "$0")"

# ilasm --version
# Mono IL assembler compiler version 6.12.0.0

ilasm -dll -output="../com.suprneko.turboface.com.anatawa12.animator-controller-as-a-code.unsafe.dll" Anatawa12.AnimatorControllerAsACode.Unsafe.il 
