using System;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    readonly struct RefCount<T> : IDisposable
    {
        class Counter
        {
            public int Count { get; private set; }

            public Counter(int initialCount)
            {
                Count = initialCount;
            }

            public void Increment()
            {
                Count++;
            }

            public void Decrement()
            {
                Count--;
            }
        }

        readonly Counter counter;

        public readonly T Value;
        public int Count => counter.Count;

        public RefCount(T value)
        {
            Value = value;
            counter = new Counter(1);
        }

        RefCount(T value, Counter counter)
        {
            Value = value;
            this.counter = counter;
        }

        public void Dispose()
        {
            counter.Decrement();
        }

        public RefCount<T> Clone()
        {
            counter.Increment();

            return new RefCount<T>(Value, counter);
        }
    }
}
