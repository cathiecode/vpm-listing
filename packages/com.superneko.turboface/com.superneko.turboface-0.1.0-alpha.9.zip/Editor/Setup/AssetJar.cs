using UnityEditor;
using UnityEngine;

namespace com.superneko.TurboFace.Editor.Setup
{
    internal class AssetJar : IAssetJar
    {
        Object addTo;

        public AssetJar(Object addTo)
        {
            this.addTo = addTo;
        }

        public void AddAsset(Object asset)
        {
            AssetDatabase.AddObjectToAsset(asset, addTo);
        }
    }
}
