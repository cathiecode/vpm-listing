using UnityEngine;

namespace com.superneko.TurboFace.Editor.Setup
{
    internal class NullAssetJar : IAssetJar
    {
        public void AddAsset(Object asset)
        {
            
        }
    }
}