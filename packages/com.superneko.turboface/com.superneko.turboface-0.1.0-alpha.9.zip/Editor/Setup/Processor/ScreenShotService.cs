using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UniRx;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    class ScreenShotService
    {
        public class Request
        {
            public Vector3 CameraPosition;
            public Quaternion CameraRotation;
            public int Width;
            public int Height;
            public float OrthoSize;
            public Action? OnPreShot;
            public Action? OnPostShot;
        }

        readonly Queue<(Request, TaskCompletionSource<Texture2D>)> queue = new();

        bool isProcessing = false;

        public Task<Texture2D> RequestScreenShot(Request request)
        {
            var tcs = new TaskCompletionSource<Texture2D>();
            queue.Enqueue((request, tcs));

            Schedule();

            return tcs.Task;
        }

        void Schedule()
        {
            if (isProcessing) return;

            isProcessing = true;

            EditorApplication.delayCall += Process;
        }

        void Process()
        {
            if (queue.Count == 0)
            {
                isProcessing = false;
                return;
            }

            var (request, tcs) = queue.Dequeue();

            try
            {
                request.OnPreShot?.Invoke();

                try
                {
                    var texture = TakeScreenShot(request);
                    tcs.SetResult(texture);
                }
                finally
                {
                    request.OnPostShot?.Invoke();
                }
            }
            catch (System.Exception ex)
            {
                tcs.SetException(ex);
            }

            EditorApplication.delayCall += Process;
        }

        Texture2D TakeScreenShot(Request request)
        {
            using var cameraGO = new GameObject("ScreenShotCamera").AsTemporary();

            var camera = cameraGO.Object.AddComponent<Camera>();
            camera.transform.SetPositionAndRotation(request.CameraPosition, request.CameraRotation);
            camera.orthographic = true;
            camera.orthographicSize = request.OrthoSize;
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = Color.clear;

            using var renderTexture = new RenderTexture(request.Width, request.Height, 24).AsTemporary();
            camera.targetTexture = renderTexture.Object;

            var texture = new Texture2D(request.Width, request.Height, TextureFormat.ARGB32, false);
            camera.Render();

            var prevActive = RenderTexture.active;
            RenderTexture.active = renderTexture;
            texture.ReadPixels(new Rect(0, 0, request.Width, request.Height), 0, 0);
            texture.Apply();
            RenderTexture.active = prevActive;

            camera.targetTexture = null;

            return texture;
        }
    }
}
