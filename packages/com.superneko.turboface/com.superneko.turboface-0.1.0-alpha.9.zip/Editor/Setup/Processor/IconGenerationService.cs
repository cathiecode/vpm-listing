using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using com.superneko.TurboFace.Editor.Setup;
using com.superneko.TurboFace.Editor.Setup.Processor;
using NUnit.Framework;
using UniRx;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Processor
{
    internal class IconGenerationService
    {
        struct IconGenerationRequest
        {
            readonly public Vector3 HeadOffset;
            readonly public Vector3 HeadForward;
            readonly public AnimationClip?[] AnimationClipSequence;
            readonly public Transform RootTransform;

            public IconGenerationRequest(AvatarData avatarData, AnimationClip?[] animationClipSequence)
            {
                HeadOffset = avatarData.HeadOffset;
                HeadForward = avatarData.HeadForward;
                AnimationClipSequence = animationClipSequence;
                RootTransform = avatarData.RootTransform;
            }

            public readonly override int GetHashCode()
            {
                var hashCode = System.HashCode.Combine(HeadOffset.GetHashCode(), HeadForward.GetHashCode(), RootTransform.GetHashCode());

                foreach (var clip in AnimationClipSequence)
                {
                    if (clip != null)
                    {
                        hashCode = System.HashCode.Combine(hashCode, clip.GetHashCode());
                    }
                }

                return hashCode;
            }

            public readonly override bool Equals(object other)
            {
                if (other is not IconGenerationRequest otherRequest)
                {
                    return false;
                }

                return HeadOffset == otherRequest.HeadOffset
                    && HeadForward == otherRequest.HeadForward
                    && RootTransform == otherRequest.RootTransform
                    && AnimationClipSequence.Length == otherRequest.AnimationClipSequence.Length
                    && AnimationClipSequence.Zip(otherRequest.AnimationClipSequence, (a, b) => a == b).EverythingTrue();
            }
        }

        static IconGenerationService? instance;

        public static IconGenerationService Instance
        {
            get
            {
                instance ??= new IconGenerationService();

                return instance;
            }
        }

        readonly ScreenShotService screenShotService = new();

        readonly Dictionary<IconGenerationRequest, RefCount<ReactiveProperty<Texture2D?>>> cache = new();

        public RefCount<ReactiveProperty<Texture2D?>> GetIcon(AvatarData avatarData, AnimationClip?[] animationClipSequence)
        {
            var request = new IconGenerationRequest(avatarData, animationClipSequence);

            CleanupUnusedIcons();

            if (cache.TryGetValue(request, out var refCount))
            {
                return refCount.Clone();
            }

            var reactiveProperty = new ReactiveProperty<Texture2D?>(null);

            var newRefCount = new RefCount<ReactiveProperty<Texture2D?>>(reactiveProperty);
            cache[request] = newRefCount;

            ScheduleGeneration(request, reactiveProperty);

            return newRefCount;
        }

        void ScheduleGeneration(IconGenerationRequest request, ReactiveProperty<Texture2D?> reactiveProperty)
        {
            screenShotService.RequestScreenShot(new ScreenShotService.Request
            {
                CameraPosition = OFFSET + request.HeadOffset + request.HeadForward,
                CameraRotation = Quaternion.LookRotation(-request.HeadForward, Vector3.up),
                Width = 128,
                Height = 128,
                OrthoSize = 0.1f,
                OnPreShot = () =>
                {
                    SetupAvatar(request);
                },
                OnPostShot = () =>
                {
                    Cleanup();
                }
            }).ContinueWith(t =>
            {
                EditorApplication.delayCall += () =>
                {
                    var result = t.GetAwaiter().GetResult();

                    reactiveProperty.Value = result;
                };
            });

        }

        public GameObject DuplicateAvatar(GameObject avatar, Vector3 position)
        {
            var duplicated = Object.Instantiate(avatar, position, avatar.transform.rotation);
            duplicated.hideFlags = HideFlags.HideAndDontSave;
            duplicated.name = avatar.name + "_IconGeneration";

            return duplicated;
        }

        Vector3 OFFSET = Vector3.up * 10.0f;

        GameObject? duplicatedAvatar;

        public void CleanupUnusedIcons()
        {
            if (cache.Count < 100)
            {
                return;
            }

            Logging.Debug($"Cleaning up icon cache. Current count: {cache.Count}");

            var keysToRemove = new List<IconGenerationRequest>();

            foreach (var kvp in cache)
            {
                var reference = kvp.Value;

                if (reference.Count == 0)
                {
                    Object.DestroyImmediate(reference.Value.Value);
                    reference.Value.Value = null;
                    keysToRemove.Add(kvp.Key);
                }
            }

            foreach (var key in keysToRemove)
            {
                cache.Remove(key);
            }
        }

        public void RegenerateAll()
        {
            CleanupUnusedIcons();

            foreach (var kvp in cache)
            {
                var request = kvp.Key;
                var reactiveProperty = kvp.Value.Value;

                reactiveProperty.Value = null;

                ScheduleGeneration(request, reactiveProperty);
            }
        }

        void SetupAvatar(IconGenerationRequest request)
        {
            if (duplicatedAvatar != null)
            {
                Object.DestroyImmediate(duplicatedAvatar);
            }

            // NOTE: I attempted to skip duplicating by reusing duplicated avatar from previous generation, but it didn't work.
            // > Why when sampling an animation ... with both the animation clip and the avatar set to humanoid, ... and offset but
            // > failing to match it’s true motion?
            // > *drumroll*
            // > Instantiate a new gameobject for each frame you’re capturing!
            // https://discussions.unity.com/t/animationmode-sampleanimationclip-editor-quirk/1691754
            // I hate this.
            // Someday I need to replace animation sampling with direct manipulation but not for now...
            duplicatedAvatar = DuplicateAvatar(request.RootTransform.gameObject, OFFSET);

            var tpose = TurboFaceUtils.LoadAssetByGUID<AnimationClip>("5f14aa9e48a9689428b50facd77cc87f");

            if (tpose == null)
            {
                Logging.Error("Failed to load T-pose animation clip.");
                return;
            }

            try
            {
                var animator = duplicatedAvatar.GetComponent<Animator>();

                foreach (var clip in request.AnimationClipSequence)
                {
                    if (clip != null)
                    {
                        clip.SampleAnimation(duplicatedAvatar, 0);
                    }
                }

                tpose.SampleAnimation(duplicatedAvatar, 0);
                duplicatedAvatar.transform.position = OFFSET;
            }
            catch (System.Exception ex)
            {
                Debug.LogException(ex);
            }
        }

        void Cleanup()
        {
            if (duplicatedAvatar != null)
            {
                Object.DestroyImmediate(duplicatedAvatar);
                duplicatedAvatar = null;
            }
        }
    }
}
