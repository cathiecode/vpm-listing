using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.ShaderKeywordFilter;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    /// <summary>
    /// Duplicates Unity object and all its references.
    /// Please note that this is not a general purpose duplication, but rather for a TurboFace internal use,
    /// so it only supports types that are relevant to TurboFace and may not work correctly with other types.
    /// To avoid infinite recursion, it keeps track of duplicated objects and returns the same reference if
    /// the same object is encountered again.
    /// </summary>
    internal class UnityObjectDuplicateContext
    {
        IAssetJar? assetJar;
        System.Func<object, object> duplicationMiddleware;
        readonly HashSet<System.Type> skipTypes = new();
        readonly Dictionary<object, object?> duplicatedObjects = new();

        public UnityObjectDuplicateContext()
        {
            duplicationMiddleware = (obj) => DuplicateInternal(obj);
        }

        public UnityObjectDuplicateContext AddSkipType(System.Type type)
        {
            skipTypes.Add(type);

            return this;
        }

        public T? StartDuplication<T>(T? root) where T : class
        {
            var duplicated = Duplicate(root);

            return duplicated;
        }

        public UnityObjectDuplicateContext AddDuplicatedObjectsTo(IAssetJar assetJar)
        {
            this.assetJar = assetJar;

            return this;
        }

        public UnityObjectDuplicateContext WrapDuplicationMiddleware(System.Func<object, System.Func<object, object>, object> newMiddleware)
        {
            var nextMiddleware = duplicationMiddleware;

            duplicationMiddleware = (obj) => newMiddleware(obj, nextMiddleware);

            return this;
        }

        T? Duplicate<T>(T? original) where T : class
        {
            if (original == null) return default;

            Logging.Trace(() => $"Duplicating {original} of type {original.GetType()}");

            if (duplicatedObjects.TryGetValue(original, out var existing))
            {
                return (T?)existing;
            }

            if (skipTypes.Contains(original.GetType()))
            {
                Logging.Trace(() => $"Skipping duplication of {original} of type {original.GetType()}");
                return original;
            }

            var duplicated = duplicationMiddleware(original);

            if (duplicated == null)
            {
                return null;
            }

            if (duplicated is not T typedDuplicated)
            {
                throw new System.InvalidCastException($"Duplication middleware returned object of type {duplicated.GetType()}, but expected {typeof(T)}");
            }

            if (duplicated != original && duplicated is Object unityObject)
            {
                assetJar?.AddAsset(unityObject);
            }

            return typedDuplicated;
        }

        T DuplicateInternal<T>(T original)
        {
            switch (original)
            {
                case AnimatorController controller:
                    AnimatorController newController = new();
                    duplicatedObjects[original] = newController;

                    newController.layers = DuplicateArray(controller.layers);
                    newController.parameters = DuplicateArray(controller.parameters);
                    // newController.hideFlags = controller.hideFlags;
                    newController.name = controller.name;

                    return AssertType<AnimatorController, T>(newController);

                case AnimatorControllerLayer layer:
                    var newLayer = new AnimatorControllerLayer();
                    duplicatedObjects[original] = newLayer;

                    newLayer.avatarMask = Duplicate(layer.avatarMask);
                    newLayer.blendingMode = layer.blendingMode;
                    newLayer.defaultWeight = layer.defaultWeight;
                    newLayer.iKPass = layer.iKPass;
                    newLayer.name = layer.name;
                    newLayer.stateMachine = Duplicate(layer.stateMachine);
                    newLayer.syncedLayerAffectsTiming = layer.syncedLayerAffectsTiming;
                    newLayer.syncedLayerIndex = layer.syncedLayerIndex;

                    return AssertType<AnimatorControllerLayer, T>(newLayer);

                case AnimatorStateMachine stateMachine:
                    var newStateMachine = new AnimatorStateMachine();
                    duplicatedObjects[original] = newStateMachine;

                    newStateMachine.anyStatePosition = stateMachine.anyStatePosition;
                    newStateMachine.anyStateTransitions = DuplicateArray(stateMachine.anyStateTransitions);
                    newStateMachine.behaviours = DuplicateArray(stateMachine.behaviours);
                    // newStateMachine.defaultState = Duplicate(stateMachine.defaultState);
                    newStateMachine.entryPosition = stateMachine.entryPosition;
                    newStateMachine.entryTransitions = DuplicateArray(stateMachine.entryTransitions);
                    newStateMachine.exitPosition = stateMachine.exitPosition;
                    newStateMachine.parentStateMachinePosition = stateMachine.parentStateMachinePosition;
                    newStateMachine.stateMachines = stateMachine.stateMachines.Select(sm => new ChildAnimatorStateMachine() { position = sm.position, stateMachine = Duplicate(sm.stateMachine), }).ToArray();
                    newStateMachine.states = stateMachine.states.Select(s => new ChildAnimatorState() { position = s.position, state = Duplicate(s.state), }).ToArray();
                    newStateMachine.defaultState = Duplicate(stateMachine.defaultState); // NOTE: Setting default state before states causing invalid state

                    foreach (var subStateMachine in stateMachine.stateMachines)
                    {
                        var duplicatedSubStateMachine = Duplicate(subStateMachine.stateMachine);

                        var newSubStateMachineTransitions = stateMachine.GetStateMachineTransitions(subStateMachine.stateMachine).Select(Duplicate);

                        newStateMachine.SetStateMachineTransitions(duplicatedSubStateMachine, newSubStateMachineTransitions.ToArray());
                    }

                    // newStateMachine.hideFlags = stateMachine.hideFlags;
                    newStateMachine.name = stateMachine.name;

                    return AssertType<AnimatorStateMachine, T>(newStateMachine);

                case AnimatorState state:
                    var newState = new AnimatorState();
                    duplicatedObjects[original] = newState;

                    newState.behaviours = DuplicateArray(state.behaviours);
                    newState.cycleOffset = state.cycleOffset;
                    newState.cycleOffsetParameter = state.cycleOffsetParameter;
                    newState.cycleOffsetParameterActive = state.cycleOffsetParameterActive;
                    newState.iKOnFeet = state.iKOnFeet;
                    newState.mirror = state.mirror;
                    newState.mirrorParameter = state.mirrorParameter;
                    newState.mirrorParameterActive = state.mirrorParameterActive;
                    newState.motion = Duplicate(state.motion);
                    newState.speed = state.speed;
                    newState.speedParameter = state.speedParameter;
                    newState.speedParameterActive = state.speedParameterActive;
                    newState.tag = state.tag;
                    newState.timeParameter = state.timeParameter;
                    newState.timeParameterActive = state.timeParameterActive;
                    newState.transitions = DuplicateArray(state.transitions);
                    newState.writeDefaultValues = state.writeDefaultValues;
                    // newState.hideFlags = state.hideFlags;
                    newState.name = state.name;

                    return AssertType<AnimatorState, T>(newState);

                case AnimatorStateTransition transition2:
                    var newTransition2 = new AnimatorStateTransition();
                    duplicatedObjects[original] = newTransition2;

                    newTransition2.canTransitionToSelf = transition2.canTransitionToSelf;
                    newTransition2.duration = transition2.duration;
                    newTransition2.exitTime = transition2.exitTime;
                    newTransition2.hasExitTime = transition2.hasExitTime;
                    newTransition2.hasFixedDuration = transition2.hasFixedDuration;
                    newTransition2.interruptionSource = transition2.interruptionSource;
                    newTransition2.offset = transition2.offset;
                    newTransition2.orderedInterruption = transition2.orderedInterruption;

                    newTransition2.conditions = transition2.conditions.Select(c => new AnimatorCondition() { mode = c.mode, parameter = c.parameter, threshold = c.threshold, }).ToArray();
                    newTransition2.destinationState = Duplicate(transition2.destinationState);
                    newTransition2.destinationStateMachine = Duplicate(transition2.destinationStateMachine);
                    newTransition2.isExit = transition2.isExit;
                    newTransition2.mute = transition2.mute;
                    newTransition2.solo = transition2.solo;
                    // newTransition2.hideFlags = transition2.hideFlags;
                    newTransition2.name = transition2.name;

                    return AssertType<AnimatorStateTransition, T>(newTransition2);

                case AnimatorTransition transition:
                    var newTransition = new AnimatorTransition();
                    duplicatedObjects[original] = newTransition;

                    newTransition.destinationState = Duplicate(transition.destinationState);
                    newTransition.destinationStateMachine = Duplicate(transition.destinationStateMachine);
                    newTransition.isExit = transition.isExit;
                    newTransition.mute = transition.mute;
                    newTransition.solo = transition.solo;
                    // newTransition.hideFlags = transition.hideFlags;
                    newTransition.name = transition.name;
                    newTransition.conditions = transition.conditions.Select(c => new AnimatorCondition() { mode = c.mode, parameter = c.parameter, threshold = c.threshold, }).ToArray();

                    return AssertType<AnimatorTransition, T>(newTransition);

                case AnimatorControllerParameter parameter:
                    var newParameter = new AnimatorControllerParameter();
                    duplicatedObjects[original] = newParameter;

                    newParameter.name = parameter.name;
                    newParameter.type = parameter.type;
                    newParameter.defaultBool = parameter.defaultBool;
                    newParameter.defaultFloat = parameter.defaultFloat;
                    newParameter.defaultInt = parameter.defaultInt;

                    return AssertType<AnimatorControllerParameter, T>(newParameter);

                case AnimationClip clip:
                    var newClip = Object.Instantiate(clip);
                    duplicatedObjects[original] = newClip;

                    return AssertType<AnimationClip, T>(newClip);

                case StateMachineBehaviour behaviour:
                    var newBehaviour = Object.Instantiate(behaviour);
                    duplicatedObjects[original] = newBehaviour;

                    return AssertType<StateMachineBehaviour, T>(newBehaviour);

                case Motion motion:
                    var newMotion = Object.Instantiate(motion);
                    duplicatedObjects[original] = newMotion;

                    return AssertType<Motion, T>(newMotion);

                case AvatarMask mask:
                    var newMask = Object.Instantiate(mask);
                    duplicatedObjects[original] = newMask;

                    return AssertType<AvatarMask, T>(newMask);

                case VRCExpressionsMenu menu:
                    var newMenu = Object.Instantiate(menu);
                    duplicatedObjects[original] = newMenu;

                    newMenu.controls = DuplicateList(menu.controls);

                    return AssertType<VRCExpressionsMenu, T>(newMenu);

                case VRCExpressionsMenu.Control control:
                    var newControl = new VRCExpressionsMenu.Control();
                    duplicatedObjects[original] = newControl;

                    newControl.name = control.name;
                    newControl.type = control.type;
                    newControl.parameter = Duplicate(control.parameter);
                    newControl.icon = Duplicate(control.icon);

                    if (newControl.labels != null)
                    {
                        for (int i = 0; i < newControl.labels.Length; i++)
                        {
                            newControl.labels[i].icon = Duplicate(control.labels[i].icon);
                        }
                    }

                    newControl.subMenu = Duplicate(control.subMenu);

                    return AssertType<VRCExpressionsMenu.Control, T>(newControl);
            }

            Logging.Trace(() => $"Don't know how to duplicate {original}. Returning original reference.");

            return original;
        }

        U AssertType<T, U>(T obj)
        {
            if (obj is U u)
            {
                return u;
            }
            else
            {
                throw new System.InvalidCastException($"Expected type {typeof(U)}, but got {obj?.GetType()}");
            }
        }

        T?[] DuplicateArray<T>(T?[] original) where T : class
        {
            var copy = new T?[original.Length];

            for (int i = 0; i < original.Length; i++)
            {
                if (original[i] == null)
                {
                    copy[i] = default;
                }
                else
                {
                    copy[i] = Duplicate(original[i]);
                }
            }

            return copy;
        }

        List<T?> DuplicateList<T>(List<T?> original) where T : class
        {
            var copy = new List<T?>(original.Count);

            for (int i = 0; i < original.Count; i++)
            {
                if (original[i] == null)
                {
                    copy.Add(default);
                }
                else
                {
                    copy.Add(Duplicate(original[i]));
                }
            }

            return copy;
        }
    }
}
