using System.Collections.Generic;

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    public static class Parameters
    {
        public enum ParameterType
        {
            Bool,
            Float,
            Int,
            AnimatorOnly,
        }

        public record ParameterDefinition
        {
            public string Name = "";
            public float DefaultValue = 0f;
            public bool Saved = false;
            public bool Synced = false;
            public ParameterType Type = ParameterType.AnimatorOnly;
        }

        public const float FALSE = 0f;

        #region constants

        public static ParameterDefinition Dummy = new()
        {
            Name = "Dummy",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        public static ParameterDefinition One = new()
        {
            Name = "One",
            DefaultValue = 1f,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        #endregion

        #region Gesture

        // From menu
        public static ParameterDefinition CN_CONTROLLER_TYPE_INDEX = new()
        {
            Name = "CN_CONTROLLER_TYPE_INDEX",
            DefaultValue = FALSE,
            Saved = true,
            Synced = false,
            Type = ParameterType.Bool,
        };

        // From menu
        public static ParameterDefinition CN_CONTROLLER_TYPE_QUEST = new()
        {
            Name = "CN_CONTROLLER_TYPE_QUEST",
            DefaultValue = FALSE,
            Saved = true,
            Synced = false,
            Type = ParameterType.Bool,
        };

        // From menu
        public static ParameterDefinition EM_EMOTE_SWAP_LR = new()
        {
            Name = "EM_EMOTE_SWAP_LR",
            DefaultValue = FALSE,
            Saved = true,
            Synced = false,
            Type = ParameterType.Bool,
        };

        // From menu
        public static ParameterDefinition CN_EMOTE_SELECT_DISABLE_LEFT = new()
        {
            Name = "CN_EMOTE_SELECT_DISABLE_LEFT",
            DefaultValue = FALSE,
            Saved = true,
            Synced = false,
            Type = ParameterType.Bool,
        };

        // From menu
        public static ParameterDefinition CN_EMOTE_SELECT_DISABLE_RIGHT = new()
        {
            Name = "CN_EMOTE_SELECT_DISABLE_RIGHT",
            DefaultValue = FALSE,
            Saved = true,
            Synced = false,
            Type = ParameterType.Bool,
        };

        // Calculated
        public static ParameterDefinition EM_EMOTE_SELECT_L = new()
        {
            Name = "EM_EMOTE_SELECT_L",
            DefaultValue = 0f,
            Saved = false,
            Synced = false,
            Type = ParameterType.Int,
        };

        // Calculated
        public static ParameterDefinition EM_EMOTE_SELECT_R = new()
        {
            Name = "EM_EMOTE_SELECT_R",
            DefaultValue = 0f,
            Saved = false,
            Synced = false,
            Type = ParameterType.Int,
        };

        #endregion

        #region Expression Set

        // From other subsystems (e.g. Menu)
        public static ParameterDefinition EM_EMOTE_PRESELECT = new()
        {
            Name = "EM_EMOTE_PRESELECT",
            DefaultValue = 0f,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        // From menu
        public static ParameterDefinition EM_EMOTE_PATTERN = new()
        {
            Name = "EM_EMOTE_PATTERN",
            DefaultValue = 0f,
            Saved = false,
            Synced = true, // FIXME: Could be false...?
            Type = ParameterType.Int,
        };

        #endregion

        #region Expression

        // Set from other subsystems (e.g. Expression Set) or from menu
        public static ParameterDefinition SYNC_EM_EMOTE = new()
        {
            Name = "SYNC_EM_EMOTE",
            DefaultValue = 0f,
            Saved = false,
            Synced = true,
            Type = ParameterType.Int,
        };

        #endregion

        #region Blink

        // From menu
        public static ParameterDefinition SYNC_CN_FORCE_BLINK_DISABLE = new()
        {
            Name = "SYNC_CN_FORCE_BLINK_DISABLE",
            DefaultValue = FALSE,
            Saved = false,
            Synced = true,
            Type = ParameterType.Bool,
        };

        // From other subsystems (e.g. Expression, Expression Override)
        public static ParameterDefinition CN_BLINK_ENABLE = new()
        {
            Name = "CN_BLINK_ENABLE",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        #endregion

        #region Mouth morph cancel

        // From other subsystems (e.g. Expression, Expression Override)
        public static ParameterDefinition CN_MOUTH_MORPH_CANCEL_ENABLE = new()
        {
            Name = "CN_MOUTH_MORPH_CANCEL_ENABLE",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        #endregion

        #region Tracking Recovery

        // From menu
        public static ParameterDefinition SYNC_CN_TRACKING_RECOVERY_ENABLE = new()
        {
            Name = "SYNC_CN_TRACKING_RECOVERY_ENABLE",
            DefaultValue = FALSE,
            Saved = false,
            Synced = true,
            Type = ParameterType.Bool,
        };

        #endregion

        #region Dance Gimmick

        // From menu
        public static ParameterDefinition SYNC_CN_DANCE_GIMMICK_ENABLE = new()
        {
            Name = "SYNC_CN_DANCE_GIMMICK_ENABLE",
            DefaultValue = FALSE,
            Saved = false,
            Synced = true,
            Type = ParameterType.Bool,
        };

        #endregion

        #region Touch to Lock

        // From Contacts
        public static ParameterDefinition CNST_TOUCH_EMOTE_LOCK_TRIGGER_L = new()
        {
            Name = "CNST_TOUCH_EMOTE_LOCK_TRIGGER_L",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        // From Contacts
        public static ParameterDefinition CNST_TOUCH_EMOTE_LOCK_TRIGGER_R = new()
        {
            Name = "CNST_TOUCH_EMOTE_LOCK_TRIGGER_R",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        #endregion

        #region Lock

        // From Other subsystems (e.g. Expression, Expression Override)
        public static ParameterDefinition CN_EMOTE_PRELOCK_ENABLE = new()
        {
            Name = "CN_EMOTE_PRELOCK_ENABLE",
            DefaultValue = FALSE,
            Saved = false,
            Synced = true,
            Type = ParameterType.Bool,
        };

        // From menu
        public static ParameterDefinition CN_CONTACT_EMOTE_LOCK_ENABLE = new()
        {
            Name = "CN_CONTACT_EMOTE_LOCK_ENABLE",
            DefaultValue = FALSE,
            Saved = true,
            Synced = false,
            Type = ParameterType.Bool,
        };

        // Calculated
        public static ParameterDefinition CN_EMOTE_LOCK_ENABLE = new()
        {
            Name = "CN_EMOTE_LOCK_ENABLE",
            DefaultValue = FALSE,
            Saved = false,
            Synced = true,
            Type = ParameterType.Bool,
        };

        #endregion

        #region Naderare to Override

        // From Contacts
        public static ParameterDefinition CNST_TOUCH_NADENADE_POINT = new()
        {
            Name = "CNST_TOUCH_NADENADE_POINT",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        #endregion

        #region Override

        // From menu
        public static ParameterDefinition SYNC_CN_EMOTE_OVERRIDE_ENABLE = new()
        {
            Name = "SYNC_CN_EMOTE_OVERRIDE_ENABLE",
            DefaultValue = FALSE,
            Saved = true,
            Synced = true,
            Type = ParameterType.Bool,
        };

        // Calculated (Used for transition in Face emote override layer)
        public static ParameterDefinition CN_EMOTE_OVERRIDE = new()
        {
            Name = "CN_EMOTE_OVERRIDE",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly, // FIXME: Really?
        };

        #endregion

        #region Indicator sound

        // From other subsystems (e.g. Override, Lock)
        public static ParameterDefinition EV_PLAY_INDICATOR_SOUND = new()
        {
            Name = "EV_PLAY_INDICATOR_SOUND",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        #endregion

        // --- FIXME: UNUSED? ---
        public static ParameterDefinition CN_IS_ACTION_ACTIVE = new()
        {
            Name = "CN_IS_ACTION_ACTIVE",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.AnimatorOnly,
        };

        public static ParameterDefinition SYNC_CN_AFK_LOCOMOTION_ENABLE = new() // FIXME: Remove?
        {
            Name = "SYNC_CN_AFK_LOCOMOTION_ENABLE",
            DefaultValue = FALSE,
            Saved = true,
            Synced = true,
            Type = ParameterType.Bool,
        };

        // --- VRChat default parameters ---
        public static ParameterDefinition GestureLeft = new()
        {
            Name = "GestureLeft",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.Int,
        };

        public static ParameterDefinition GestureRight = new()
        {
            Name = "GestureRight",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.Int,
        };

        public static ParameterDefinition GestureLeftWeight = new()
        {
            Name = "GestureLeftWeight",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.Float,
        };

        public static ParameterDefinition GestureRightWeight = new()
        {
            Name = "GestureRightWeight",
            DefaultValue = FALSE,
            Saved = false,
            Synced = false,
            Type = ParameterType.Float,
        };

        public static IEnumerable<ParameterDefinition> EnumerateRegisterableDefinitions()
        {
            yield return SYNC_CN_FORCE_BLINK_DISABLE;
            yield return SYNC_CN_TRACKING_RECOVERY_ENABLE;
            yield return SYNC_CN_DANCE_GIMMICK_ENABLE;
            yield return EM_EMOTE_SELECT_L;
            yield return EM_EMOTE_SELECT_R;
            yield return EM_EMOTE_PRESELECT;
            yield return EM_EMOTE_SWAP_LR;
            yield return CN_EMOTE_SELECT_DISABLE_LEFT;
            yield return CN_EMOTE_SELECT_DISABLE_RIGHT;
            yield return CN_EMOTE_LOCK_ENABLE;
            yield return CN_EMOTE_PRELOCK_ENABLE;
            yield return EM_EMOTE_PATTERN;
            yield return SYNC_EM_EMOTE;
            yield return CN_CONTACT_EMOTE_LOCK_ENABLE;
            yield return CN_BLINK_ENABLE;
            yield return CN_EMOTE_OVERRIDE;
            yield return CN_MOUTH_MORPH_CANCEL_ENABLE;
            yield return CNST_TOUCH_EMOTE_LOCK_TRIGGER_L;
            yield return CNST_TOUCH_EMOTE_LOCK_TRIGGER_R;
            yield return CNST_TOUCH_NADENADE_POINT;
            yield return EV_PLAY_INDICATOR_SOUND;
            yield return SYNC_CN_EMOTE_OVERRIDE_ENABLE;
            yield return CN_IS_ACTION_ACTIVE;
            yield return SYNC_CN_AFK_LOCOMOTION_ENABLE;
            yield return CN_CONTROLLER_TYPE_INDEX;
            yield return CN_CONTROLLER_TYPE_QUEST;
            yield return Dummy;
            yield return One;
        }
    }
}
