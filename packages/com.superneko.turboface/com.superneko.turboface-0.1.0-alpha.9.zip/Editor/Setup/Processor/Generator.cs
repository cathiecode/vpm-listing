using UnityEngine;
using UnityEditor;
using com.superneko.TurboFace.Runtime.Setup;
using nadena.dev.modular_avatar.core;
using VRC.SDK3.Avatars.Components;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    public static class Generator
    {
        public static void Generate(TurboFaceSetupComponent component, IAssetJar assetJar)
        {
            var setupObject = new GameObject("TurboFace Setup (Generated)")
            {
                hideFlags = HideFlags.HideAndDontSave
            };

            var avatarDescriptor = component.GetComponentInParent<VRCAvatarDescriptor>();

            var avatarData = AvatarData.FromAvatarDescriptor(avatarDescriptor);

            try
            {
                var setup = new Setup(SetupSerializer.Deserialize(component.SerializedSetupData), null);

                var compiledSetup = CompiledSetup.Compile(avatarData, setup, assetJar);

                var animatorController = new FxGenerator(assetJar).Generate(compiledSetup);

                var maMergeAnimator = setupObject.AddComponent<ModularAvatarMergeAnimator>();
                maMergeAnimator.animator = animatorController;
                maMergeAnimator.matchAvatarWriteDefaults = true;
                maMergeAnimator.pathMode = MergeAnimatorPathMode.Absolute;
                maMergeAnimator.layerPriority = 1000;

                var menu = new MenuGenerator(compiledSetup, assetJar).Generate();

                var maMenuInstaller = setupObject.AddComponent<ModularAvatarMenuInstaller>();
                maMenuInstaller.menuToAppend = menu;

                var maParameters = setupObject.AddComponent<ModularAvatarParameters>();
                maParameters.parameters = Parameters.EnumerateRegisterableDefinitions()
                    .Select(parameterDef => new ParameterConfig
                    {
                        nameOrPrefix = parameterDef.Name,
                        remapTo = "TurboFace_" + parameterDef.Name,
                        internalParameter = true,
                        isPrefix = false,
                        syncType = parameterDef.Type switch
                        {
                            Parameters.ParameterType.Bool => ParameterSyncType.Bool,
                            Parameters.ParameterType.Float => ParameterSyncType.Float,
                            Parameters.ParameterType.Int => ParameterSyncType.Int,
                            Parameters.ParameterType.AnimatorOnly => ParameterSyncType.NotSynced,
                            _ => throw new System.Exception("Unknown parameter type")
                        },
                        localOnly = !parameterDef.Synced,
                        defaultValue = parameterDef.DefaultValue,
                        saved = parameterDef.Saved,
                        hasExplicitDefaultValue = false,
                    })
                    .ToList();
            }
            catch
            {
                Object.DestroyImmediate(setupObject);
                throw;
            }

            setupObject.hideFlags = HideFlags.None;
            setupObject.transform.parent = component.transform;
            AssetDatabase.SaveAssets();
        }
    }
}
