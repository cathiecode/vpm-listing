using System.Collections.Generic;
using UnityEditor.Animations;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    internal class ObjectWalker
    {
        readonly HashSet<System.Type> skipTypes = new();

        readonly HashSet<object> visitedObjects = new();

        public ObjectWalker() { }

        public ObjectWalker AddSkipType(System.Type type)
        {
            skipTypes.Add(type);

            return this;
        }

        public void Walk(object obj, System.Action<object> onVisit)
        {
            if (obj == null) return;

            if (visitedObjects.Contains(obj)) return;

            if (skipTypes.Contains(obj.GetType())) return;

            onVisit(obj);

            visitedObjects.Add(obj);

            Roam(obj, onVisit);
        }

        void Roam(object obj, System.Action<object> onVisit)
        {
            switch (obj)
            {
                case AnimatorController controller:
                    foreach (var layer in controller.layers)
                    {
                        Walk(layer, onVisit);
                    }
                    foreach (var parameter in controller.parameters)
                    {
                        Walk(parameter, onVisit);
                    }
                    break;

                case AnimatorControllerLayer layer:
                    Walk(layer.stateMachine, onVisit);
                    break;

                case AnimatorStateMachine stateMachine:
                    foreach (var state in stateMachine.states)
                    {
                        Walk(state.state, onVisit);
                    }
                    foreach (var subStateMachine in stateMachine.stateMachines)
                    {
                        Walk(subStateMachine.stateMachine, onVisit);
                    }
                    break;
                case AnimatorState state:
                    Walk(state.motion, onVisit);
                    Walk(state.behaviours, onVisit);
                    Walk(state.transitions, onVisit);
                    break;
                case AnimatorTransition transition:
                    Walk(transition.destinationState, onVisit);
                    Walk(transition.conditions, onVisit);
                    break;
                default:
                    Logging.Trace(() => $"No roaming implemented for type {obj.GetType()}");
                    break;
            }
        }
    }
}