using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    internal class MenuGenerator
    {
        readonly CompiledSetup setup;
        readonly IAssetJar assetJar;

        public MenuGenerator(CompiledSetup setup, IAssetJar assetJar)
        {
            this.setup = setup;
            this.assetJar = assetJar;
        }
        public VRCExpressionsMenu Generate()
        {
            var menu = TurboFaceUtils.LoadAssetByGUID<VRCExpressionsMenu>("806402e749d3ce346b3cc4ec5fa5f829");

            var duplicatedMenu = new UnityObjectDuplicateContext()
                .AddDuplicatedObjectsTo(assetJar)
                .WrapDuplicationMiddleware(ReplaceMiddleware)
                .StartDuplication(menu);

            if (duplicatedMenu == null)
            {
                throw new System.InvalidOperationException("Failed to duplicate menu");
            }

            return duplicatedMenu;
        }

        public object ReplaceMiddleware(object original, System.Func<object, object> next)
        {
            var duplicated = next(original);
            switch (duplicated)
            {
                case VRCExpressionsMenu.Control control:
                    // FIXME: Hardcoded control name
                    if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.name == "表情パターン切り替え")
                    {
                        control.subMenu = GeneratePatternSwitchingMenu(setup.EnumerateExpressionSet().ToArray());
                    }
                    if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.name == "表情指定")
                    {
                        GenerateFaceEmoteSelectMenu(control.subMenu, setup.EnumerateExpressionSet().ToArray());
                    }
                    break;
            }

            return duplicated;
        }

        public VRCExpressionsMenu GeneratePatternSwitchingMenu(CompiledSetup.ExpressionSet[] expressionSets)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();

            assetJar.AddAsset(menu);

            for (var i = 0; i < expressionSets.Length; i++)
            {
                // NOTE: Menu is limited to 8 controls
                if (i == 7 && expressionSets.Length > 8)
                {
                    var nextControl = new VRCExpressionsMenu.Control()
                    {
                        name = "Next",
                        type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                        subMenu = GeneratePatternSwitchingMenu(expressionSets[i..]),
                    };

                    menu.controls.Add(nextControl);

                    break;
                }

                var set = expressionSets[i];

                var control = new VRCExpressionsMenu.Control()
                {
                    name = set.Name,
                    type = VRCExpressionsMenu.Control.ControlType.Toggle,
                    parameter = new VRCExpressionsMenu.Control.Parameter()
                    {
                        name = Parameters.EM_EMOTE_PATTERN.Name,
                    },
                    value = set.Index,
                };

                menu.controls.Add(control);
            }

            return menu;
        }

        public void GenerateFaceEmoteSelectMenu(VRCExpressionsMenu menu, CompiledSetup.ExpressionSet[] sets)
        {
            for (int i = 0; i < sets.Length; i++)
            {
                var remainingCount = sets.Length - 1;

                if (menu.controls.Count == 7 && remainingCount >= 2)
                {
                    var nextMenu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
                    GenerateFaceEmoteSelectMenu(nextMenu, sets[i..]);

                    assetJar.AddAsset(nextMenu);

                    var nextControl = new VRCExpressionsMenu.Control()
                    {
                        name = "Next",
                        type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                        subMenu = nextMenu,
                    };

                    menu.controls.Add(nextControl);

                    break;
                }

                var set = sets[i];

                var control = new VRCExpressionsMenu.Control()
                {
                    name = set.Name,
                    type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                    subMenu = GenerateFaceEmoteSelectSubMenu(set.EnumerateExpressions().ToArray()),
                };

                menu.controls.Add(control);
            }
        }


        public VRCExpressionsMenu GenerateFaceEmoteSelectSubMenu(CompiledSetup.Expression[] expressions)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();

            assetJar.AddAsset(menu);

            for (int i = 0; i < expressions.Length; i++)
            {
                if (i == 7 && expressions.Length > 8)
                {
                    var nextControl = new VRCExpressionsMenu.Control()
                    {
                        name = "Next",
                        type = VRCExpressionsMenu.Control.ControlType.SubMenu,
                        subMenu = GenerateFaceEmoteSelectSubMenu(expressions[i..]),
                    };

                    menu.controls.Add(nextControl);

                    break;
                }

                var expression = expressions[i];

                var control = new VRCExpressionsMenu.Control()
                {
                    name = expression.Name,
                    type = VRCExpressionsMenu.Control.ControlType.Toggle,
                    parameter = new VRCExpressionsMenu.Control.Parameter()
                    {
                        name = $"SYNC_EM_EMOTE",
                    },
                    value = expression.InterSetIndex
                };

                menu.controls.Add(control);
            }

            return menu;
        }
    }
}
