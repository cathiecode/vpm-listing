using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using com.superneko.TurobFace.Editor;
using UniRx;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    internal class CompiledSetup
    {
        public interface IBlending
        {

        }

        public class OneVariableBlending : IBlending
        {
            public readonly Parameters.ParameterDefinition Parameter;
            public readonly AnimationClip AnimationClipForFullBlend;

            public OneVariableBlending(Parameters.ParameterDefinition parameter, AnimationClip animationClipForFullBlend)
            {
                Parameter = parameter;
                AnimationClipForFullBlend = animationClipForFullBlend;
            }
        }

        public class TwoVariableBlending : IBlending
        {
            public readonly Parameters.ParameterDefinition ParameterX;
            public readonly Parameters.ParameterDefinition ParameterY;

            public readonly AnimationClip AdditiveAnimationClipX;
            public readonly AnimationClip AdditiveAnimationClipY;

            public TwoVariableBlending(Parameters.ParameterDefinition parameterX, Parameters.ParameterDefinition parameterY, AnimationClip additiveAnimationClipX, AnimationClip additiveAnimationClipY)
            {
                ParameterX = parameterX;
                ParameterY = parameterY;

                AdditiveAnimationClipX = additiveAnimationClipX;
                AdditiveAnimationClipY = additiveAnimationClipY;
            }
        }
        public class Expression
        {
            public ExpressionSet? ExpressionSet;
            readonly public int InterSetIndex;
            readonly public int SetIndex;
            readonly public string Name;
            readonly public Editor.Setup.Expression SourceExpression;

            readonly public bool CompatibleWithEyeMovements;
            readonly public bool CompatibleWithBlinking;
            readonly public bool CompatibleWithLipSync;
            readonly public bool CancelMouthMorphing;

            readonly public AnimationClip AnimationClip;

            readonly public IBlending? Blending;

            public Expression(Editor.Setup.Expression sourceExpression, int interSetIndex, int setIndex, AnimationClip animationClip, IBlending? blending)
            {
                SourceExpression = sourceExpression;
                CompatibleWithBlinking = sourceExpression.CompatibleWithBlinking.Value;
                CompatibleWithEyeMovements = sourceExpression.CompatibleWithEyeMovements.Value;
                CompatibleWithLipSync = sourceExpression.CompatibleWithLipsync.Value;
                CancelMouthMorphing = sourceExpression.ShouldCancelMouthMorphing.Value;
                Blending = blending;

                InterSetIndex = interSetIndex;
                SetIndex = setIndex;
                AnimationClip = animationClip;
                var originalClip = sourceExpression.AnimationClip.Value.Instance;
                Name = originalClip != null ? originalClip.name : "(None)";
            }
        }

        public class ExpressionSet
        {
            public CompiledSetup? setup = null;

            readonly public string Name;
            readonly public int Index;
            int[] expressionInterSetIndexForGestureCombinations;

            public ExpressionSet(string name, int setIndex, int[] expressionInterSetIndexForGestureCombinations)
            {
                this.Name = name;
                this.Index = setIndex;
                this.expressionInterSetIndexForGestureCombinations = expressionInterSetIndexForGestureCombinations;
            }

            public int GetExpressionInterSetIndexForCombination(GestureCombination combination)
            {
                return expressionInterSetIndexForGestureCombinations[combination.Index()];
            }

            public IEnumerable<Expression> EnumerateExpressions()
            {
                return setup?.EnumerateExpression().Where(e => e.SetIndex == Index) ?? Enumerable.Empty<Expression>();
            }
        }

        readonly public AnimationClip DefaultFaceAnimation;
        readonly public AnimationClip BlinkingEnableAnimation;
        readonly Expression[] expressions;
        readonly ExpressionSet[] expressionSets;

        CompiledSetup(AnimationClip defaultFaceAnimation, AnimationClip blinkingEnableAnimation, Expression[] expressions, ExpressionSet[] expressionSets)
        {
            DefaultFaceAnimation = defaultFaceAnimation;
            BlinkingEnableAnimation = blinkingEnableAnimation;
            this.expressions = expressions;
            this.expressionSets = expressionSets;

            foreach (var set in this.expressionSets)
            {
                set.setup = this;
            }
        }

        public IEnumerable<ExpressionSet> EnumerateExpressionSet()
        {
            return expressionSets;
        }

        public IEnumerable<Expression> EnumerateExpression()
        {
            return expressions;
        }

        public Expression? GetCompiledExpressionFor(Editor.Setup.Expression expression)
        {
            return expressions.FirstOrDefault(e => e.SourceExpression == expression);
        }

        public static CompiledSetup Compile(AvatarData avatarData, Setup setup, IAssetJar assetJar)
        {
            List<Expression> compiledExpressions = new();
            List<ExpressionSet> compiledExpressionSets = new();

            var interSetExpressionIndex = 0;

            var defaultValueAnimationClip = AnimationGenerator.GenerateDefaultValueAnimationClip(avatarData, assetJar);

            AnimationClip? blinkingEnableAnimation;
            var builtInBlinkingAnimationClip = TurboFaceUtils.LoadAssetByGUID<AnimationClip>("e7644de8d754d1646a7306131a82e978");

            if (builtInBlinkingAnimationClip == null)
            {
                throw new LogicException("Built-in blinking animation clip is missing. This should never happen. Please report this to the developer.");
            }

            switch (setup.BlinkingSettings.Value.BlinkingAnimationMode)
            {
                case BlinkingAnimationMode.GenerateFromEyeClosingAnimation:
                    var eyeClosingAnimationClip = setup.BlinkingSettings.Value.AnimationClipForBlinking?.Instance;

                    if (eyeClosingAnimationClip == null)
                    {
                        Logging.Warn("Blinking animation clip is not set. Cannot generate blinking animation from eye closing animation. Blinking will be disabled.");
                        blinkingEnableAnimation = builtInBlinkingAnimationClip;
                        break;
                    }

                    blinkingEnableAnimation = AnimationGenerator.GenerateBlinkingAnimationClipFromEyeCloseAnimation(
                        defaultValueAnimationClip,
                        eyeClosingAnimationClip,
                        assetJar
                    );
                    break;
                case BlinkingAnimationMode.UseCustomAnimation:
                    blinkingEnableAnimation = setup.BlinkingSettings.Value.AnimationClipForBlinking?.Instance;
                    break;
                default:
                    blinkingEnableAnimation = builtInBlinkingAnimationClip;
                    break;
            }

            if (blinkingEnableAnimation == null)
            {
                throw new LogicException("Blinking animation clip is null. This should never happen. Please report this to the developer.");
            }

            for (int expressionSetIndex = 0; expressionSetIndex < setup.ExpressionSets.Value.Length; expressionSetIndex++)
            {
                var expressionSet = setup.ExpressionSets.Value[expressionSetIndex];
                var expressions = expressionSet.Expressions.Value;

                var defaultValueAnimationClipForSet = AnimationGenerator.GenerateDefaultValueAnimationClipForSet(
                    avatarData,
                    defaultValueAnimationClip,
                    expressionSet.DefaultExpression.AnimationClip.Value.Instance,
                    assetJar
                );

                var fallbackExpression = new Expression(expressionSet.DefaultExpression, interSetExpressionIndex, expressionSetIndex, defaultValueAnimationClipForSet, null);

                compiledExpressions.Add(fallbackExpression);

                interSetExpressionIndex++;

                var interSetExpressionIndexForGestureCombination = new int[GestureCombination.CombinationCount()];

                foreach (var gestureCombination in GestureCombination.Enumerate())
                {
                    interSetExpressionIndexForGestureCombination[gestureCombination.Index()] = fallbackExpression.InterSetIndex;
                }

                foreach (var expression in expressions)
                {
                    if (interSetExpressionIndex >= 255)
                    {
                        throw new System.Exception("Too many expressions. Inter set expression index exceeded (> 255).");
                    }

                    foreach (var gestureCombination in GestureCombination.Enumerate())
                    {
                        if (expression.WillActiveWhenGestureCombinationIs(gestureCombination))
                        {
                            // Later expression overrides earlier expression
                            interSetExpressionIndexForGestureCombination[gestureCombination.Index()] = interSetExpressionIndex;
                        }
                    }

                    var expressionAnimationClip = expression.AnimationClip.Value.Instance;

                    var expressionAnimationClipWithDefaultValue = AnimationGenerator.GenerateExpressionAnimationClip(
                        avatarData,
                        defaultValueAnimationClip,
                        defaultValueAnimationClipForSet,
                        expressionAnimationClip,
                        assetJar
                    );

                    IBlending? blending = null;

                    if (expression.UseGestureLeftWeight.Value && expression.UseGestureRightWeight.Value)
                    {
                        // Two variable blending
                        var leftWeightAnimationClip = new AnimationClipBuilder()
                            .WithName($"TurboFaceGenerated__GestureLeftWeightAnimationClip_{expression.AnimationClip.Value.Instance}")
                            .SetCurvesFrom(expressionAnimationClipWithDefaultValue)
                            .SetCurvesFromIfNotNull(expression.GestureLeftWeightAnimationClip.Value.Instance)
                            .AdditiveFromFirstFrameValueOf(expressionAnimationClipWithDefaultValue)
                            .ToAnimationClip();

                        assetJar.AddAsset(leftWeightAnimationClip);

                        var rightWeightAnimationClip = new AnimationClipBuilder()
                            .WithName($"TurboFaceGenerated__GestureRightWeightAnimationClip_{expression.AnimationClip.Value.Instance}")
                            .SetCurvesFrom(expressionAnimationClipWithDefaultValue)
                            .SetCurvesFromIfNotNull(expression.GestureRightWeightAnimationClip.Value.Instance)
                            .AdditiveFromFirstFrameValueOf(expressionAnimationClipWithDefaultValue)
                            .ToAnimationClip();

                        assetJar.AddAsset(rightWeightAnimationClip);

                        blending = new TwoVariableBlending(
                            Parameters.GestureLeftWeight,
                            Parameters.GestureRightWeight,
                            leftWeightAnimationClip,
                            rightWeightAnimationClip
                        );
                    }
                    else if (expression.UseGestureLeftWeight.Value)
                    {
                        // One variable blending for left gesture weight
                        var leftWeightAnimationClip = new AnimationClipBuilder()
                            .WithName($"TurboFaceGenerated__GestureLeftWeightAnimationClip_{expression.AnimationClip.Value.Instance}")
                            .SetCurvesFrom(expressionAnimationClipWithDefaultValue)
                            .SetCurvesFromIfNotNull(expression.GestureLeftWeightAnimationClip.Value.Instance)
                            .AdditiveFromFirstFrameValueOf(expressionAnimationClipWithDefaultValue)
                            .ToAnimationClip();

                        assetJar.AddAsset(leftWeightAnimationClip);

                        blending = new OneVariableBlending(
                            Parameters.GestureLeftWeight,
                            leftWeightAnimationClip
                        );
                    }
                    else if (expression.UseGestureRightWeight.Value)
                    {
                        // One variable blending for right gesture weight
                        var rightWeightAnimationClip = new AnimationClipBuilder()
                            .WithName($"TurboFaceGenerated__GestureRightWeightAnimationClip_{expression.AnimationClip.Value.Instance}")
                            .SetCurvesFrom(expressionAnimationClipWithDefaultValue)
                            .SetCurvesFromIfNotNull(expression.GestureRightWeightAnimationClip.Value.Instance)
                            .AdditiveFromFirstFrameValueOf(expressionAnimationClipWithDefaultValue)
                            .ToAnimationClip();

                        assetJar.AddAsset(rightWeightAnimationClip);

                        blending = new OneVariableBlending(
                            Parameters.GestureRightWeight,
                            rightWeightAnimationClip
                        );
                    }

                    compiledExpressions.Add(new Expression(expression, interSetExpressionIndex, expressionSetIndex, expressionAnimationClipWithDefaultValue, blending));

                    interSetExpressionIndex++;
                }

                var compiledExpressionSet = new ExpressionSet(expressionSet.Name.Value, expressionSetIndex, interSetExpressionIndexForGestureCombination);

                compiledExpressionSets.Add(compiledExpressionSet);
            }

            foreach (var expression in compiledExpressions)
            {
                expression.ExpressionSet = compiledExpressionSets[expression.SetIndex];
            }

            return new CompiledSetup(defaultValueAnimationClip, blinkingEnableAnimation, compiledExpressions.ToArray(), compiledExpressionSets.ToArray());
        }
    }
}
