using com.superneko.TurobFace.Editor;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    internal class AnimationGenerator
    {
        public static AnimationClip GenerateDefaultValueAnimationClip(AvatarData avatarData, IAssetJar assetJar)
        {
            var faceSharedMesh = avatarData.FaceSMR.sharedMesh;

            if (faceSharedMesh == null)
            {
                Logging.Warn("Face SkinnedMeshRenderer does not have a shared mesh. Cannot generate default face animation clip.");
                return new AnimationClip();
            }

            var builder = new AnimationClipBuilder()
                .WithName("Generated Default Face Animation");

            FromCurrentBlendShape(avatarData, builder);

            var animationClip = builder.ToAnimationClip();

            assetJar.AddAsset(animationClip);

            return animationClip;
        }

        public static AnimationClip GenerateDefaultValueAnimationClipForSet(AvatarData avatarData, AnimationClip defaultValueAnimationClip, AnimationClip? expressionSetDefaultAnimationClip, IAssetJar assetJar)
        {
            if (expressionSetDefaultAnimationClip == null)
            {
                return defaultValueAnimationClip;
            }

            var builder = new AnimationClipBuilder()
                .WithName($"TurboFaceGenerated__DefaultValueAnimationClip_{expressionSetDefaultAnimationClip.name}");

            builder.SetCurvesFrom(defaultValueAnimationClip);
            builder.SetCurvesFrom(expressionSetDefaultAnimationClip);

            var animationClip = builder.ToAnimationClip();

            assetJar.AddAsset(animationClip);

            return animationClip;
        }

        public static AnimationClip GenerateExpressionAnimationClip(AvatarData avatarData, AnimationClip defaultValueAnimationClip, AnimationClip? defaultValueAnimationClipForSet, AnimationClip? expressionAnimationClip, IAssetJar assetJar)
        {
            if (defaultValueAnimationClipForSet == null && expressionAnimationClip == null)
            {
                return defaultValueAnimationClip;
            }

            if (defaultValueAnimationClipForSet != null && expressionAnimationClip == null)
            {
                return defaultValueAnimationClipForSet;
            }

            // Now either setDefaultAnimationClipWithAllkeys or expressionAnimationClip is not null

            var builder = new AnimationClipBuilder()
                .WithName("TurboFaceGenerated__");

            builder.SetCurvesFrom(defaultValueAnimationClip);

            if (defaultValueAnimationClipForSet != null)
            {
                builder.SetCurvesFrom(defaultValueAnimationClipForSet);
                builder.Name += defaultValueAnimationClipForSet.name + "_";
            }

            if (expressionAnimationClip != null)
            {
                builder.SetCurvesFrom(expressionAnimationClip);
                builder.Name += expressionAnimationClip.name + "_";
            }

            var animationClip = builder.ToAnimationClip();

            assetJar.AddAsset(animationClip);

            return animationClip;
        }

        public static AnimationClip GenerateBlinkingAnimationClipFromEyeCloseAnimation(AnimationClip defaultValueAnimationClip, AnimationClip eyeCloseAnimationClip, IAssetJar assetJar)
        {
            var builder = new AnimationClipBuilder()
                .WithName("TurboFaceGenerated__BlinkingAnimationClipFromEyeCloseAnimation");

            var bindings = AnimationUtility.GetCurveBindings(eyeCloseAnimationClip);


            foreach (var binding in bindings)
            {
                var curve = AnimationUtility.GetEditorCurve(eyeCloseAnimationClip, binding);

                var defaultValue = AnimationUtility.GetEditorCurve(defaultValueAnimationClip, binding)?.Evaluate(0) ?? 0;
                var blinkValue = curve.Evaluate(0);

                builder
                    .FloatCurve(binding)
                    .KeyFrame(0, defaultValue)
                    .KeyFrame(1f, defaultValue)
                    .KeyFrame(1.15f, blinkValue)
                    .KeyFrame(1.2f, blinkValue)
                    .KeyFrame(1.3f, defaultValue);
            }

            var animationClip = builder.ToAnimationClip();

            assetJar.AddAsset(animationClip);

            return animationClip;
        }

        static AnimationClipBuilder FromCurrentBlendShape(AvatarData avatarData, AnimationClipBuilder animationClipBuilder)
        {
            var faceSharedMesh = avatarData.FaceSMR.sharedMesh;

            if (faceSharedMesh == null)
            {
                Logging.Warn("Face SkinnedMeshRenderer does not have a shared mesh. Cannot generate animation clip from current blend shape values. Returning an empty animation clip.");
                return animationClipBuilder;
            }

            var blendShapeCount = faceSharedMesh.blendShapeCount;

            var smrPath = AnimationUtility.CalculateTransformPath(avatarData.FaceSMR.transform, avatarData.RootTransform);

            var builder = new AnimationClipBuilder();

            for (int i = 0; i < blendShapeCount; i++)
            {
                var blendShapeName = faceSharedMesh.GetBlendShapeName(i);
                var weight = avatarData.FaceSMR.GetBlendShapeWeight(i);

                builder
                    .FloatCurve(typeof(SkinnedMeshRenderer), smrPath, $"blendShape.{blendShapeName}")
                    .KeyFrame(0, weight);
            }

            return animationClipBuilder;
        }
    }
}