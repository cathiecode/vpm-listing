using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor.Animations;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VirtualController
{
    public interface Node
    {
        public VirtualTransition[] InTransitions { get; }
        public VirtualTransition[] OutTransitions { get; }
        public void AddInTransition(VirtualTransition transition);
        public void AddOutTransition(VirtualTransition transition);
    }

    public class VirtualState : Node
    {

        public readonly AnimatorState BaseState;

        readonly VirtualStateMachine parentStateMachine;
        VirtualTransition[] inTransitions = new VirtualTransition[0];
        VirtualTransition[] outTransitions = new VirtualTransition[0];

        public VirtualStateMachine BelongingStateMachine => parentStateMachine;
        public VirtualTransition[] InTransitions => inTransitions;
        public VirtualTransition[] OutTransitions => outTransitions;

        public VirtualState(AnimatorState baseState, VirtualStateMachine parentStateMachine)
        {
            BaseState = baseState;
            this.parentStateMachine = parentStateMachine;
        }

        public void AddInTransition(VirtualTransition transition)
        {
            inTransitions = inTransitions.Added(transition);
        }

        public void AddOutTransition(VirtualTransition transition)
        {
            outTransitions = outTransitions.Added(transition);
        }

        public override string ToString()
        {
            return $"State({BaseState.name})";
        }
    }

    public class VirtualTransition
    {
        public enum Mode
        {
            If,
            IfNot,
            Greater,
            Less,
            Equals,
            NotEqual
        }

        public class Condition
        {
            public Mode Mode;
            public string Parameter;
            public float Threshold { get; private set; }

            public Condition(Mode mode, string parameter, float threshold)
            {
                Mode = mode;
                Parameter = parameter;
                Threshold = threshold;
            }
        }

        public AnimatorTransitionBase BaseTransition { get; private set; }
        public Node From { get; private set; }
        public Node To { get; private set; }
        public Condition[] Conditions { get; private set; }
        public bool CanTransitionToSelf => BaseTransition is AnimatorStateTransition stateTransition && stateTransition.canTransitionToSelf;

        public VirtualTransition(AnimatorTransitionBase baseTransition, Node from, Node to, Condition[] conditions)
        {
            BaseTransition = baseTransition;
            From = from;
            To = to;
            Conditions = conditions;
        }
    }

    public class VirtualStateMachineNode : Node
    {
        public enum NodeType
        {
            Entry,
            Exit,
            Any
        }

        readonly NodeType nodeType;
        readonly VirtualStateMachine stateMachine;

        VirtualTransition[] inTransitions = new VirtualTransition[0];
        VirtualTransition[] outTransitions = new VirtualTransition[0];

        public VirtualStateMachine StateMachine => stateMachine;
        public VirtualStateMachine BaseStateMachine => stateMachine;
        public VirtualTransition[] InTransitions => inTransitions;
        public VirtualTransition[] OutTransitions => outTransitions;

        public VirtualStateMachineNode(VirtualStateMachine parentStateMachine, NodeType nodeType)
        {
            this.stateMachine = parentStateMachine;
            this.nodeType = nodeType;
        }

        public void AddInTransition(VirtualTransition transition)
        {
            inTransitions = inTransitions.Added(transition);
        }

        public void AddOutTransition(VirtualTransition transition)
        {
            outTransitions = outTransitions.Added(transition);
        }

        public override string ToString()
        {
            return $"StateMachineNode({nodeType} of {stateMachine})";
        }
    }

    public class VirtualStateMachine
    {
        public readonly AnimatorStateMachine BaseStateMachine;
        public readonly VirtualStateMachineNode entry;
        public readonly VirtualStateMachineNode exit;
        public readonly VirtualStateMachineNode any;
        public readonly VirtualStateMachine? parentStateMachine;

        public VirtualStateMachine? ParentStateMachine => parentStateMachine;

        public VirtualStateMachine(AnimatorStateMachine baseStateMachine, VirtualStateMachine? parentStateMachine)
        {
            BaseStateMachine = baseStateMachine;
            this.parentStateMachine = parentStateMachine;
            entry = new VirtualStateMachineNode(this, VirtualStateMachineNode.NodeType.Entry);
            exit = new VirtualStateMachineNode(this, VirtualStateMachineNode.NodeType.Exit);
            any = new VirtualStateMachineNode(this, VirtualStateMachineNode.NodeType.Any);
        }

        public void AddInTransition(VirtualTransition transition)
        {
            entry.AddInTransition(transition);
        }

        public void AddOutTransition(VirtualTransition transition)
        {
            exit.AddOutTransition(transition);
        }

        public override string ToString()
        {
            return $"StateMachine({BaseStateMachine.name})";
        }
    }

    public class VirtualLayer
    {
        public float Weight;
        public readonly VirtualStateMachine RootStateMachine;

        public VirtualLayer(float weight, VirtualStateMachine rootStateMachine)
        {
            Weight = weight;
            RootStateMachine = rootStateMachine;
        }
    }

    public class VirtualAnimatorControllerGraph
    {
        readonly List<VirtualLayer> layers = new();

        readonly Dictionary<AnimatorState, VirtualState> nodes = new();
        readonly Dictionary<AnimatorTransitionBase, VirtualTransition> transitions = new();
        readonly Dictionary<AnimatorStateMachine, VirtualStateMachine> stateMachines = new();

        public IEnumerable<VirtualLayer> Layers => layers;
        public IEnumerable<VirtualState> States => nodes.Values;
        public IEnumerable<VirtualTransition> Transitions => transitions.Values;
        public IEnumerable<VirtualStateMachine> StateMachines => stateMachines.Values;

        public VirtualAnimatorControllerGraph(AnimatorController animatorController)
        {
            foreach (var layer in animatorController.layers)
            {
                var layerRootStateMachine = ParseStateMachine(layer.stateMachine, null);

                CreateAndSetTransition(new AnimatorStateTransition() { }, layerRootStateMachine.exit, layerRootStateMachine.entry);

                layers.Add(new VirtualLayer(layer.defaultWeight, layerRootStateMachine));
            }
        }

        VirtualStateMachine ParseStateMachine(AnimatorStateMachine stateMachine, VirtualStateMachine? parentStateMachine)
        {
            var virtualStateMachine = GetOrCreateVirtualStateMachine(stateMachine, parentStateMachine);

            // All States
            foreach (var state in stateMachine.states)
            {
                var virtualState = GetOrCreateVirtualState(state.state, virtualStateMachine);

                foreach (var transition in state.state.transitions)
                {
                    RegisterAnimatorStateTransition(virtualState, transition);
                }
            }

            // Sub State Machines
            foreach (var subStateMachine in stateMachine.stateMachines)
            {
                // Sub State Machine inner
                var virtualSubStateMachine = ParseStateMachine(subStateMachine.stateMachine, virtualStateMachine);

                // Sub State Machine (Exit) => *
                foreach (var transition in stateMachine.GetStateMachineTransitions(subStateMachine.stateMachine))
                {
                    RegisterAnimatorStateTransition(virtualSubStateMachine.exit, transition);
                }
            }

            // Entry => *
            foreach (var entryTransition in stateMachine.entryTransitions)
            {
                RegisterAnimatorStateTransition(virtualStateMachine.entry, entryTransition);
            }

            // Entry => default state
            if (stateMachine.defaultState != null)
            {
                CreateAndSetTransition(new AnimatorStateTransition() { destinationState = stateMachine.defaultState }, virtualStateMachine.entry, GetOrCreateVirtualState(stateMachine.defaultState, virtualStateMachine));
            }

            // Any => *
            foreach (var anyTransition in stateMachine.anyStateTransitions)
            {
                RegisterAnimatorStateTransition(virtualStateMachine.any, anyTransition);
            }

            void RegisterAnimatorStateTransition(Node sourceNode, AnimatorTransitionBase transition)
            {
                if (transition.destinationState != null)
                {
                    CreateAndSetTransition(transition, sourceNode, GetOrCreateVirtualState(transition.destinationState, virtualStateMachine));
                }

                if (transition.destinationStateMachine != null)
                {
                    CreateAndSetTransition(transition, sourceNode, GetOrCreateVirtualStateMachine(transition.destinationStateMachine, virtualStateMachine).entry);
                }

                if (transition.isExit)
                {
                    CreateAndSetTransition(transition, sourceNode, virtualStateMachine.exit);
                }
            }

            return virtualStateMachine;
        }

        void CreateAndSetTransition(AnimatorTransitionBase transitionBase, Node from, Node to)
        {
            var transition = transitions.GetOrCreate(transitionBase, () =>
            {
                var conditions = transitionBase.conditions.Select(cond =>
                {
                    var mode = cond.mode switch
                    {
                        AnimatorConditionMode.If => VirtualTransition.Mode.If,
                        AnimatorConditionMode.IfNot => VirtualTransition.Mode.IfNot,
                        AnimatorConditionMode.Greater => VirtualTransition.Mode.Greater,
                        AnimatorConditionMode.Less => VirtualTransition.Mode.Less,
                        AnimatorConditionMode.Equals => VirtualTransition.Mode.Equals,
                        AnimatorConditionMode.NotEqual => VirtualTransition.Mode.NotEqual,
                        _ => throw new InvalidOperationException("Unknown condition mode")
                    };

                    return new VirtualTransition.Condition(mode, cond.parameter, cond.threshold);
                }).ToArray();

                return new VirtualTransition(transitionBase, from, to, conditions);
            });
            from.AddOutTransition(transition);
            to.AddInTransition(transition);
        }

        Node GetOrCreateVirtualState(AnimatorState state, VirtualStateMachine parentStateMachine)
        {
            return nodes.GetOrCreate(state, () => new VirtualState(state, parentStateMachine));
        }

        VirtualStateMachine GetOrCreateVirtualStateMachine(AnimatorStateMachine stateMachine, VirtualStateMachine? parentStateMachine)
        {
            return stateMachines.GetOrCreate(stateMachine, () => new VirtualStateMachine(stateMachine, parentStateMachine));
        }
    }

    static class Extensions
    {
        public static TValue GetOrCreate<TKey, TValue>(this Dictionary<TKey, TValue> dict, TKey key, Func<TValue> createFunc)
        {
            if (!dict.TryGetValue(key, out var value))
            {
                value = createFunc();
                dict[key] = value;
            }

            return value;
        }
    }
}