using System.Collections.Generic;
using System.Linq;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VirtualController
{
    internal class ParameterRegistry
    {
        public Dictionary<string, float> Parameters { get; private set; } = new();

        public ParameterRegistry() { }

        public virtual float Get(string name)
        {
            if (Parameters.TryGetValue(name, out var floatValue))
            {
                return floatValue;
            }

            return 0f;
        }

        public virtual float Set(string name, float value)
        {
            Parameters[name] = value;
            return value;
        }
    }

    internal class LayerRunner
    {
        public Node CurrentState { get; private set; }
        protected ParameterRegistry parameterRegistry;
        public string LayerName;

        public LayerRunner(ParameterRegistry parameterRegistry, VirtualStateMachine baseStateMachine)
        {
            this.parameterRegistry = parameterRegistry;
            this.CurrentState = baseStateMachine.entry;
            LayerName = baseStateMachine.BaseStateMachine.name;
        }

        public virtual bool Step()
        {
            Logging.Trace(() => $"[{LayerName}] Stepping. Starting state: {CurrentState}");

            var firstActiveTransition = FindActiveTransition(CurrentState);

            if (firstActiveTransition != null)
            {
                var transition = firstActiveTransition;
                Logging.Trace(() => $"[{LayerName}] Transitioning from {CurrentState} to {transition.To}");
                CurrentState = transition.To;
                return true;
            }

            return false;
        }

        VirtualTransition? FindActiveTransition(Node state)
        {
            Node? currentNode = state;

            int count = 0;

            while (currentNode != null)
            {
                for (int i = 0; i < currentNode.OutTransitions.Length; i++)
                {
                    var transition = currentNode.OutTransitions[i];

                    if (!transition.CanTransitionToSelf && transition.To == CurrentState)
                    {
                        // Logging.Trace(() => $"[{LayerName}] Skipping self-transition from {CurrentState} to itself because CanTransitionToSelf is false.");
                        continue;
                    }

                    // Logging.Trace(() => $"[{LayerName}] Found transition from {currentNode} to {transition.To}");

                    if (count++ > 1000)
                    {
                        // Logging.Warn($"[{LayerName}] Collected over 1000 transitions. There might be an infinite loop in the state machine. Stopping collection.");
                        return null;
                    }

                    var allConditionsSatisfied = true;

                    for (int j = 0; j < transition.Conditions.Length; j++)
                    {
                        var condition = transition.Conditions[j];
                        
                        if (!SatisfiesCondition(condition))
                        {
                            allConditionsSatisfied = false;
                            break;
                        }
                    }

                    if (allConditionsSatisfied)
                    {
                        // Logging.Trace(() => $"[{LayerName}] Transition from {currentNode} to {transition.To} satisfies condition.");

                        return transition;
                    }
                }

                // Any state of current parent state machine
                if (currentNode is VirtualState virtualState)
                {
                    currentNode = virtualState.BelongingStateMachine.any;
                    continue;
                }

                if (currentNode is VirtualStateMachineNode virtualStateMachineNode)
                {
                    currentNode = virtualStateMachineNode.StateMachine.ParentStateMachine?.any;
                    continue;
                }

                currentNode = null;
            }

            return null;
        }

        bool SatisfiesCondition(VirtualTransition.Condition condition)
        {
            // Logging.Trace(() => $"[{LayerName}] Checking condition on parameter '{condition.Parameter}' with mode {condition.Mode} and threshold {condition.Threshold}");
            return condition.Mode switch
            {
                VirtualTransition.Mode.If => parameterRegistry.Get(condition.Parameter) > 0.5f,
                VirtualTransition.Mode.IfNot => parameterRegistry.Get(condition.Parameter) <= 0.5f,
                VirtualTransition.Mode.Greater => parameterRegistry.Get(condition.Parameter) > condition.Threshold,
                VirtualTransition.Mode.Less => parameterRegistry.Get(condition.Parameter) < condition.Threshold,
                VirtualTransition.Mode.Equals => Mathf.Approximately(parameterRegistry.Get(condition.Parameter), condition.Threshold),
                VirtualTransition.Mode.NotEqual => !Mathf.Approximately(parameterRegistry.Get(condition.Parameter), condition.Threshold),
                _ => false,
            };
        }
    }

    internal class AnimatorControllerGraphRunner
    {
        protected readonly VirtualAnimatorControllerGraph graph;
        protected readonly List<LayerRunner> layerRunners = new();

        public AnimatorControllerGraphRunner(VirtualAnimatorControllerGraph graph, ParameterRegistry parameterRegistry)
        {
            this.graph = graph;
            foreach (var layer in graph.Layers)
            {
                layerRunners.Add(CreateLayerRunner(layer.RootStateMachine, parameterRegistry));
            }
        }

        protected virtual LayerRunner CreateLayerRunner(VirtualStateMachine baseStateMachine, ParameterRegistry parameterRegistry)
        {
            return new LayerRunner(parameterRegistry, baseStateMachine);
        }

        public bool StepUntilStop(int limit = 20)
        {
            var anyTransitioned = false;

            for (int i = 0; i < limit; i++)
            {
                Logging.Trace(() => $"Step {i + 1}/{limit}");
                if (Step())
                {
                    Logging.Trace("Transition(s) occurred. Continuing to step.");
                    anyTransitioned = true;
                }
                else
                {
                    Logging.Trace("No transition occurred. Stopping.");
                    break;
                }
            }

            return anyTransitioned;
        }

        public virtual bool Step()
        {
            bool anyTransitioned = false;

            foreach (var layerRunner in layerRunners)
            {
                if (layerRunner.Step())
                {
                    anyTransitioned = true;
                }
            }

            return anyTransitioned;
        }

        public IEnumerable<LayerRunner> EnumerateLayerRunners()
        {
            return layerRunners;
        }

        public IEnumerable<Node> EnumerateCurrentNodes()
        {
            return layerRunners.Select(runner => runner.CurrentState);
        }
    }
}
