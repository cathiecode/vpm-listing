using UnityEngine;
using VRC.SDK3.Avatars.Components;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.HeuristicAnimatorControllerParser
{
    using System.Linq;
    using VirtualController;

    class VRCParameterRegistry : ParameterRegistry
    {
        public VRCParameterRegistry(Gesture GestureLeft, Gesture GestureRight) : base()
        {
            Parameters["GestureLeft"] = (float)GestureLeft;
            Parameters["GestureRight"] = (float)GestureRight;
        }

        public override float Get(string name)
        {
            switch (name)
            {
                case "IsLocal":
                    return 1f;
            }

            if (Parameters.TryGetValue(name, out var floatValue))
            {
                return floatValue;
            }

            return 0f;
        }
    }

    class VRCLayerRunner : LayerRunner
    {
        readonly VRCAnimatorControllerGraphRunner runner;
        readonly VirtualAnimatorControllerGraph graph;

        public VRCLayerRunner(VRCAnimatorControllerGraphRunner runner, VirtualAnimatorControllerGraph graph, ParameterRegistry parameterRegistry, VirtualStateMachine baseStateMachine) : base(parameterRegistry, baseStateMachine)
        {
            this.graph = graph;
            this.runner = runner;
        }

        public override bool Step()
        {
            var transitioned = base.Step();

            if (transitioned)
            {
                if (CurrentState is VirtualState virtualState)
                {
                    ExecBehaviours(virtualState.BaseState.behaviours);
                }

                if (CurrentState is VirtualStateMachine virtualStateMachine)
                {
                    ExecBehaviours(virtualStateMachine.BaseStateMachine.behaviours);
                }
            }

            return transitioned;
        }

        void ExecBehaviours(StateMachineBehaviour[] behaviours)
        {
            foreach (var behaviour in behaviours)
            {
                switch (behaviour)
                {
                    case VRCAvatarParameterDriver parameterDriver:
                        ExecParameterDriver(parameterDriver);
                        break;
                    case VRCAnimatorLayerControl layerControl:
                        ExecLayerControl(layerControl);
                        break;
                    case VRCAnimatorTrackingControl trackingControl:
                        ExecTrackingControl(trackingControl);
                        break;
                }
            }
        }

        void ExecParameterDriver(VRCAvatarParameterDriver parameterDriver)
        {
            foreach (var param in parameterDriver.parameters)
            {
                switch (param.type)
                {
                    case VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Add:
                        var currentValue = parameterRegistry.Get(param.name);
                        var newValue = currentValue + param.value;
                        Logging.Trace(() => $"[{LayerName}] Parameter Add {param.name} = {currentValue} + {param.value} -> {newValue}");
                        parameterRegistry.Set(param.name, newValue);
                        break;

                    case VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set:
                        Logging.Trace(() => $"[{LayerName}] Parameter Set {param.name} = {param.value}");
                        parameterRegistry.Set(param.name, param.value);
                        break;
                    default:
                        // Does not care; too complex
                        break;
                }
            }
        }

        void ExecLayerControl(VRCAnimatorLayerControl layerControl)
        {
            if (layerControl.playable != VRC.SDKBase.VRC_AnimatorLayerControl.BlendableLayer.FX)
            {
                // NOTE: We don't care
                return;
            }

            if (layerControl.layer >= graph.Layers.Count())
            {
                // NOTE: Invalid layer index; ignore
                return;
            }

            // NOTE: For simplicity, we directly set the weight to the goal weight.
            // The actual AnimatorController may blend towards it over multiple frames, but simulating that is complex and not worth the effort.
            graph.Layers.ElementAt(layerControl.layer).Weight = layerControl.goalWeight;
        }

        void ExecTrackingControl(VRCAnimatorTrackingControl trackingControl)
        {
            if (trackingControl.trackingEyes != VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.NoChange)
            {
                runner.IsEyeTrackingEnabled= trackingControl.trackingEyes == VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.Tracking;
            }

            if (trackingControl.trackingMouth != VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.NoChange)
            {
                runner.IsMouthTrackingEnabled = trackingControl.trackingMouth == VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.Tracking;
            }
        }
    }

    class VRCAnimatorControllerGraphRunner : AnimatorControllerGraphRunner
    {
        public bool IsEyeTrackingEnabled = true;
        public bool IsMouthTrackingEnabled = true;

        public VRCAnimatorControllerGraphRunner(VirtualAnimatorControllerGraph graph, ParameterRegistry parameterRegistry) : base(graph, parameterRegistry)
        { }

        protected override LayerRunner CreateLayerRunner(VirtualStateMachine baseStateMachine, ParameterRegistry parameterRegistry)
        {
            return new VRCLayerRunner(this, graph, parameterRegistry, baseStateMachine);
        }
    }
}
