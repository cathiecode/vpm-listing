#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.HeuristicAnimatorControllerParser
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using UnityEditor;
    using UnityEditor.Animations;
    using UnityEngine;
    using UnityEngine.Assertions;
    using VirtualController;
    using VRC.SDK3.Avatars.Components;

    class LayerBehaviourData
    {
        public class OutputState
        {
            readonly public Node State;
            readonly public float Weight;

            public OutputState(Node state, float weight)
            {
                State = state;
                Weight = weight;
            }
        }

        public readonly int LayerIndex;
        readonly OutputState[] outputStatesForGestureCombinations;

        public LayerBehaviourData(int layerIndex)
        {
            LayerIndex = layerIndex;
            outputStatesForGestureCombinations = new OutputState[GestureCombination.CombinationCount()];
        }

        public OutputState GetOutputStateForGestureCombination(GestureCombination gestureCombination)
        {
            return outputStatesForGestureCombinations[gestureCombination.Index()];
        }

        public void SetOutputStateForGestureCombination(GestureCombination gestureCombination, OutputState state)
        {
            outputStatesForGestureCombinations[gestureCombination.Index()] = state;
        }

        public bool HasStaticAnimation()
        {
            return outputStatesForGestureCombinations.Select(output => output.State).EverythingIsSame();
        }

        public bool LooksLikeFaceMorphLayer()
        {
            // Heuristic: If there is at least one output state that looks like a face morph animation, the layer is likely to be a face animation layer.
            var hasStatesSeemsMorphingFace = outputStatesForGestureCombinations.Any(output => VRCHeuristicAnimatorControllerParser.LooksLikeFaceMorphState(output.State));

            // NOTE: For avatars with blink locking layers, like Lime.
            // Heuristic: If all output states look like blink-related states, it's likely a blink locking layer, not a face animation layer.
            var allStatesAreBlinkRelated = outputStatesForGestureCombinations.All(output => VRCHeuristicAnimatorControllerParser.LooksLikeBlinkRelatedState(output.State));

            // Heuristic: If all output states look like toggle-related states, it's likely a toggle locking layer, not a face animation layer.
            var allStatesAreToggleRelated = outputStatesForGestureCombinations.All(output => VRCHeuristicAnimatorControllerParser.LooksLikeToggleRelatedState(output.State));

            return hasStatesSeemsMorphingFace && !allStatesAreBlinkRelated && !allStatesAreToggleRelated;
        }
    }

    class BehaviourData
    {
        public readonly LayerBehaviourData[] LayersBehaviourData;
        public readonly Dictionary<string, float>[] parametersForGestureCombinations;
        public readonly bool[] isEyeTrackingEnabledForGestureCombinations;
        public readonly bool[] isMouthTrackingEnabledForGestureCombinations;
        public readonly bool platformBlinkingEnabled = false;

        public BehaviourData(LayerBehaviourData[] layersBehaviourData, Dictionary<string, float>[] parametersForGestureCombinations, bool[] isEyeTrackingEnabledForGestureCombinations, bool[] isMouthTrackingEnabledForGestureCombinations, bool platformBlinkingEnabled)
        {
            this.LayersBehaviourData = layersBehaviourData;
            this.parametersForGestureCombinations = parametersForGestureCombinations;
            this.isEyeTrackingEnabledForGestureCombinations = isEyeTrackingEnabledForGestureCombinations;
            this.isMouthTrackingEnabledForGestureCombinations = isMouthTrackingEnabledForGestureCombinations;
            this.platformBlinkingEnabled = platformBlinkingEnabled;
        }
    }

    class GestureCombinationMap<T>
    {
        readonly T[] values;

        public GestureCombinationMap()
        {
            values = new T[GestureCombination.CombinationCount()];
        }

        public T this[GestureCombination gestureCombination]
        {
            get => values[gestureCombination.Index()];
            set => values[gestureCombination.Index()] = value;
        }

        public IEnumerable<T> EnumerateRightHandWhenLeftHandIs(Gesture leftHand)
        {
            foreach (var rightHand in GestureExt.Enumerate())
            {
                yield return this[new GestureCombination(leftHand, rightHand)];
            }
        }

        public IEnumerable<T> EnumerateLeftHandWhenRightHandIs(Gesture rightHand)
        {
            foreach (var leftHand in GestureExt.Enumerate())
            {
                yield return this[new GestureCombination(leftHand, rightHand)];
            }
        }

        public void AssertFilled()
        {
            for (int i = 0; i < values.Length; i++)
            {
                if (values[i] == null)
                {
                    throw new InvalidOperationException($"GestureCombinationMap is not fully filled. Missing value for gesture combination index {i}.");
                }
            }
        }
    }

    record ExpressionDataWithoutCondition
    {
        public AnimationClip? AnimationClip { private get; set; } = null;
        public bool ShouldCancelMouthMorphing { private get; set; } = false;
        public bool CompatibleWithLipsync { private get; set; } = true;
        public bool CompatibleWithBlinking { private get; set; } = false;
        public bool CompatibleWithEyeMovements { private get; set; } = true;

        public ExpressionData ToExpressionData(GestureRuleData[] gestureRules)
        {
            return new()
            {
                AnimationClip = new AssetReference<AnimationClip>(AnimationClip),
                ShouldCancelMouthMorphing = ShouldCancelMouthMorphing,
                CompatibleWithLipsync = CompatibleWithLipsync,
                CompatibleWithBlinking = CompatibleWithBlinking,
                CompatibleWithEyeMovements = CompatibleWithEyeMovements,
                GestureRules = gestureRules
            };
        }
    }

    internal static class VRCHeuristicAnimatorControllerParser
    {
        public static SetupData Parse(AnimatorController animatorController, VRCAvatarDescriptor descriptor)
        {
            var log = Logging.WithContext($"HeuristicAnimatorControllerParser");

            var graph = new VirtualAnimatorControllerGraph(animatorController);

            var setupData = new SetupData();

            var platformBlinkingEnabled =
                descriptor.enableEyeLook &&
                descriptor.customEyeLookSettings.eyelidType == VRCAvatarDescriptor.EyelidType.Blendshapes &&
                descriptor.customEyeLookSettings.eyelidsBlendshapes != null &&
                descriptor.customEyeLookSettings.eyelidsBlendshapes.Length > 0 &&
                descriptor.customEyeLookSettings.eyelidsBlendshapes[0] >= 0;

            // Collect parameters for expression set
            var parametersForSet = CollectSetParameters(graph, animatorController);

            // First pass: Collect layer metadata, without setting any parameters.
            var baseExpressionSetData = ParseSet(CollectBehaviourData(graph, new Dictionary<string, float>(), platformBlinkingEnabled));

            if (baseExpressionSetData is not null)
            {
                setupData.ExpressionSets = setupData.ExpressionSets.Added(baseExpressionSetData);
            }

            foreach (var combination in ParameterCombinations(parametersForSet))
            {
                log.Info($"Trying parameter combination: {string.Join(", ", combination.Select(kvp => $"{kvp.Key}={kvp.Value}"))}");

                // Second pass: Collect layer metadata for the parameter combination.
                var layerMetadata = CollectBehaviourData(graph, combination, platformBlinkingEnabled);

                // Try to parse expression set data with the new metadata.
                var newExpressionSetData = ParseSet(layerMetadata);

                if (newExpressionSetData is null)
                {
                    log.Warn("Failed to parse ExpressionSetData with the parameter combination.");
                    continue;
                }

                if (baseExpressionSetData is null)
                {
                    baseExpressionSetData = newExpressionSetData;
                    log.Info("Successfully parsed ExpressionSetData with the parameter combination.");
                    continue;
                }

                var exisiting = setupData.ExpressionSets.Any(existingSet => existingSet.Equals(newExpressionSetData));

                if (exisiting)
                {
                    log.Info("The parsed ExpressionSetData with the parameter combination is the same as an existing one, so skip adding.");
                    continue;
                }

                setupData.ExpressionSets = setupData.ExpressionSets.Added(newExpressionSetData);
            }

            return setupData;
        }

        public static ExpressionSetData? ParseSet(BehaviourData behaviourData)
        {
            var log = Logging.WithContext($"HeuristicAnimatorControllerParser.ParseSet");

            var layerMetadata = behaviourData.LayersBehaviourData;

            var staticFaceAnimationLayers = layerMetadata.Where(metadata => metadata.HasStaticAnimation() && metadata.LooksLikeFaceMorphLayer()).ToArray();
            var nonStaticFaceAnimationLayers = layerMetadata.Where(metadata => !metadata.HasStaticAnimation() && metadata.LooksLikeFaceMorphLayer()).ToArray();

            if (!nonStaticFaceAnimationLayers.Any())
            {
                log.Info("No non-static face animation layer found.");
                return null;
            }

            var firstNonStaticFaceAnimationLayer = nonStaticFaceAnimationLayers.FirstOrDefault();
            Assert.IsNotNull(firstNonStaticFaceAnimationLayer);
            log.Debug($"First Non-Static Face Animation Layer: {firstNonStaticFaceAnimationLayer.LayerIndex.ToString() ?? "None"}");

            var defaultFaceAnimationLayer = staticFaceAnimationLayers.FirstOrDefault(layer => layer.LayerIndex < firstNonStaticFaceAnimationLayer.LayerIndex && layer.GetOutputStateForGestureCombination(new GestureCombination(Gesture.Neutral, Gesture.Neutral)).Weight > 0.5f);
            var defaultFaceAnimationState = defaultFaceAnimationLayer?.GetOutputStateForGestureCombination(new GestureCombination(Gesture.Neutral, Gesture.Neutral)).State;
            log.Debug($"Default Face Animation: {defaultFaceAnimationState?.ToString() ?? "None"}");

            AnimationClip? defaultFaceAnimationClip = null;

            if (defaultFaceAnimationState is VirtualState state && state.BaseState.motion is AnimationClip clip)
            {
                defaultFaceAnimationClip = clip;
            }

            GestureCombinationMap<ExpressionDataWithoutCondition> expressionForGestureCombinations = new();

            foreach (var gestureCombination in GestureCombination.Enumerate())
            {
                var faceAnimation = nonStaticFaceAnimationLayers
                    .Select(layer => layer.GetOutputStateForGestureCombination(gestureCombination).State)
                    .LastOrDefault(LooksLikeFaceMorphState);

                log.Trace(() => $"Gesture Combination: {gestureCombination}, Candidate Face Animations: {string.Join(", ", nonStaticFaceAnimationLayers.Select(layer => layer.GetOutputStateForGestureCombination(gestureCombination).State.ToString()))}, Selected Face Animation: {faceAnimation?.ToString() ?? "None"}");

                if (faceAnimation is not VirtualState faceState)
                {
                    log.Trace(() => $"Gesture Combination: {gestureCombination}, No face animation state found.");

                    expressionForGestureCombinations[gestureCombination] = new()
                    {
                        AnimationClip = null,
                        ShouldCancelMouthMorphing = false,
                        CompatibleWithLipsync = true,
                        CompatibleWithBlinking = false,
                        CompatibleWithEyeMovements = true
                    };
                }
                else
                {
                    log.Trace(() => $"Gesture Combination: {gestureCombination}, Face Animation: {faceState} of {faceState.BelongingStateMachine}");

                    expressionForGestureCombinations[gestureCombination] = new()
                    {
                        AnimationClip = faceState.BaseState.motion as AnimationClip,
                        ShouldCancelMouthMorphing = false, // TODO: CAC-style mouth morphing cancellation detection
                        CompatibleWithLipsync = behaviourData.isMouthTrackingEnabledForGestureCombinations[gestureCombination.Index()],
                        CompatibleWithBlinking = behaviourData.platformBlinkingEnabled && behaviourData.isEyeTrackingEnabledForGestureCombinations[gestureCombination.Index()], // TODO: CAC-style eye blinking detection
                        CompatibleWithEyeMovements = behaviourData.isEyeTrackingEnabledForGestureCombinations[gestureCombination.Index()]
                    };
                }
            }

            expressionForGestureCombinations.AssertFilled();

            if (TryCreateExpressionSetWithStandardTemplate(expressionForGestureCombinations, HandData.Left, out ExpressionSetData? expressionSetData))
            {
                log.Info("Successfully created ExpressionSetData with prefer-left template.");
                expressionSetData!.DefaultExpression = new ExpressionData
                {
                    AnimationClip = new AssetReference<AnimationClip>(defaultFaceAnimationClip),
                    ShouldCancelMouthMorphing = false,
                    CompatibleWithLipsync = true,
                    CompatibleWithBlinking = false,
                    CompatibleWithEyeMovements = true
                };
                return expressionSetData;
            }

            if (TryCreateExpressionSetWithStandardTemplate(expressionForGestureCombinations, HandData.Right, out expressionSetData))
            {
                log.Info("Successfully created ExpressionSetData with prefer-right template.");
                expressionSetData!.DefaultExpression = new ExpressionData
                {
                    AnimationClip = new AssetReference<AnimationClip>(defaultFaceAnimationClip),
                    ShouldCancelMouthMorphing = false,
                    CompatibleWithLipsync = true,
                    CompatibleWithBlinking = false,
                    CompatibleWithEyeMovements = true
                };
                return expressionSetData;
            }

            expressionSetData = CreateExpressionSetWithComboTemplate(expressionForGestureCombinations);
            log.Warn("Failed to create ExpressionSetData with prefer-left and prefer-right templates, so created with combo template as fallback.");
            expressionSetData.DefaultExpression = new ExpressionData
            {
                AnimationClip = new AssetReference<AnimationClip>(defaultFaceAnimationClip),
                ShouldCancelMouthMorphing = false,
                CompatibleWithLipsync = true,
                CompatibleWithBlinking = false,
                CompatibleWithEyeMovements = true
            };

            return expressionSetData;
        }

        public static Dictionary<string, float[]> CollectSetParameters(VirtualAnimatorControllerGraph graph, AnimatorController animatorController)
        {
            // Heuristic: If a parameter which contains "set" in its name is used in "Equals" conditions in the animator controller,
            // it's likely to be a parameter for controlling face expressions.
            var conditionsForSetParameters = graph.Transitions
                .SelectMany(transition =>
                    transition.Conditions
                        .Where(condition =>
                            condition.Parameter.Contains("set", StringComparison.OrdinalIgnoreCase) ||
                            condition.Parameter.Contains("pattern", StringComparison.OrdinalIgnoreCase)
                        )
                )
                .Where(condition => condition.Mode == VirtualTransition.Mode.Equals)
                .Select(condition => (condition.Parameter, condition.Threshold))
                .Distinct();

            var collectedParametersAndPossibleValue = new Dictionary<string, float[]>();

            foreach (var (parameterName, parameterValue) in conditionsForSetParameters)
            {
                if (!collectedParametersAndPossibleValue.ContainsKey(parameterName))
                {
                    collectedParametersAndPossibleValue[parameterName] = new float[] { parameterValue };
                }
                else
                {
                    var existingValues = collectedParametersAndPossibleValue[parameterName];
                    if (!existingValues.Contains(parameterValue))
                    {
                        collectedParametersAndPossibleValue[parameterName] = existingValues.Added(parameterValue);
                    }
                }
            }

            foreach (var possibleValues in collectedParametersAndPossibleValue.Values)
            {
                Array.Sort(possibleValues);
            }

            return collectedParametersAndPossibleValue;
        }

        public static BehaviourData CollectBehaviourData(VirtualAnimatorControllerGraph graph, Dictionary<string, float> initialParameters, bool platformBlinkingEnabled)
        {
            LayerBehaviourData[] layerMetadata = new LayerBehaviourData[graph.Layers.Count()];
            bool[] isEyeTrackingEnabledForGestureCombinations = new bool[GestureCombination.CombinationCount()];
            bool[] isMouthTrackingEnabledForGestureCombinations = new bool[GestureCombination.CombinationCount()];
            Dictionary<string, float>[] parametersForGestureCombinations = new Dictionary<string, float>[GestureCombination.CombinationCount()];

            for (int i = 0; i < layerMetadata.Length; i++)
            {
                layerMetadata[i] = new LayerBehaviourData(i);
            }

            foreach (var gestureCombination in GestureCombination.Enumerate())
            {
                Logging.Trace(() => $"Simulating for Gesture Combination: {gestureCombination}");

                var parameterRegistry = new VRCParameterRegistry(gestureCombination.LeftHand, gestureCombination.RightHand);

                foreach (var kvp in initialParameters)
                {
                    parameterRegistry.Set(kvp.Key, kvp.Value);
                }

                var runner = new VRCAnimatorControllerGraphRunner(graph, parameterRegistry);
                runner.StepUntilStop();

                Assert.AreEqual(runner.EnumerateLayerRunners().Count(), graph.Layers.Count());

                for (int i = 0; i < layerMetadata.Length; i++)
                {
                    var layerRunner = runner.EnumerateLayerRunners().ElementAt(i);
                    var currentState = layerRunner.CurrentState;

                    layerMetadata[i].SetOutputStateForGestureCombination(gestureCombination, new LayerBehaviourData.OutputState(currentState, graph.Layers.ElementAt(i).Weight));
                }

                isEyeTrackingEnabledForGestureCombinations[gestureCombination.Index()] = runner.IsEyeTrackingEnabled;
                isMouthTrackingEnabledForGestureCombinations[gestureCombination.Index()] = runner.IsMouthTrackingEnabled;
                parametersForGestureCombinations[gestureCombination.Index()] = parameterRegistry.Parameters;
            }

            // Debug Dump
            Logging.Trace(() =>
            {
                var builder = new StringBuilder();

                builder.AppendLine("Collected Layer Metadata:");

                foreach (var layerMeta in layerMetadata)
                {
                    builder.AppendLine($"Layer {layerMeta.LayerIndex}:");

                    foreach (var gestureCombination in GestureCombination.Enumerate())
                    {
                        var outputState = layerMeta.GetOutputStateForGestureCombination(gestureCombination).State;
                        builder.AppendLine($"  Gesture Combination: {gestureCombination}, Output State: {outputState}");
                    }
                }

                return builder.ToString();
            });

            Assert.IsTrue(layerMetadata.EverythingFilled());

            return new BehaviourData(layerMetadata, parametersForGestureCombinations, isEyeTrackingEnabledForGestureCombinations, isMouthTrackingEnabledForGestureCombinations, platformBlinkingEnabled);
        }

        public static Dictionary<T, U>[] ParameterCombinations<T, U>(Dictionary<T, U[]> table)
        {
            // Cartesian product of parameter values
            IEnumerable<Dictionary<T, U>> CartesianProduct(IEnumerable<KeyValuePair<T, U[]>> sequences)
            {
                IEnumerable<Dictionary<T, U>> emptyProduct = new[] { new Dictionary<T, U>() };

                return sequences.Aggregate(emptyProduct, (accumulator, sequence) =>
                    from acc in accumulator
                    from value in sequence.Value
                    select new Dictionary<T, U>(acc) { [sequence.Key] = value });
            }

            return CartesianProduct(table).ToArray();
        }

        public static bool TryCreateExpressionSetWithStandardTemplate(
            GestureCombinationMap<ExpressionDataWithoutCondition> faceAnimationForGestureCombinations,
            HandData preferHand,
            out ExpressionSetData? expressionSetData
        )
        {
            List<(Gesture, ExpressionDataWithoutCondition[])> exceptionalLines = new();

            foreach (var preferredHand in GestureExt.Enumerate())
            {
                var lesserHandExpressions = preferHand == HandData.Left ?
                    faceAnimationForGestureCombinations.EnumerateRightHandWhenLeftHandIs(preferredHand) :
                    faceAnimationForGestureCombinations.EnumerateLeftHandWhenRightHandIs(preferredHand);

                if (!lesserHandExpressions.EverythingIsSame())
                {
                    exceptionalLines.Add((preferredHand, lesserHandExpressions.ToArray()));
                }
            }

            if (exceptionalLines.Count > 1)
            {
                var firstExceptionalLine = exceptionalLines.First();

                foreach (var line in exceptionalLines.Skip(1))
                {
                    if (!line.Item2.SequenceEqual(firstExceptionalLine.Item2))
                    {
                        // Multiple variations in exceptional lines
                        expressionSetData = null;
                        return false;
                    }
                }
            }

            expressionSetData = CreateExpressionSetWithPreferHandTemplate(faceAnimationForGestureCombinations, preferHand, exceptionalLines.Select(item => item.Item1).ToArray());

            expressionSetData.Name = Localization.GetTranslated(MessageKey.Get(preferHand == HandData.Left ? "setup.expression-set.template.prefer-left.name" : "setup.expression-set.template.prefer-right.name"));

            return true;
        }

        public static ExpressionSetData CreateExpressionSetWithPreferHandTemplate(GestureCombinationMap<ExpressionDataWithoutCondition> faceAnimationForGestureCombinations, HandData preferHand, Gesture[] passThroughGestures)
        {
            var expressions = new List<ExpressionData>();

            void GenerateHalf(HandData handToEnumerate, bool isPreferHand = false)
            {
                foreach (var gesture in GestureExt.Enumerate())
                {
                    if (isPreferHand && passThroughGestures.Contains(gesture))
                    {
                        // Pass-through gesture for the prefer hand, so use the default expression.
                        continue;
                    }

                    var gestureCombination = handToEnumerate switch
                    {
                        HandData.Left => new GestureCombination(gesture, Gesture.Neutral),
                        HandData.Right => new GestureCombination(Gesture.Neutral, gesture),
                        _ => throw new InvalidOperationException("Unknown hand data")
                    };

                    var expression = faceAnimationForGestureCombinations[gestureCombination];

                    var expressionData = expression.ToExpressionData(new GestureRuleData[]
                        {
                            new() {
                                Hand = handToEnumerate,
                                Gesture = (GestureData)gesture.Index(),
                            }
                        });

                    Logging.Trace(() => $"Generated ExpressionData for {handToEnumerate} {gesture}: AnimationClip = {expressionData.AnimationClip}");

                    expressions.Add(expressionData);
                }
            }

            if (preferHand == HandData.Left)
            {
                GenerateHalf(HandData.Right);
                GenerateHalf(HandData.Left, true);
            }
            else
            {
                GenerateHalf(HandData.Left);
                GenerateHalf(HandData.Right, true);
            }

            return new ExpressionSetData
            {
                Expressions = expressions.ToArray()
            };
        }

        public static ExpressionSetData CreateExpressionSetWithComboTemplate(GestureCombinationMap<ExpressionDataWithoutCondition> faceAnimationForGestureCombinations)
        {
            var expressions = new List<ExpressionData>();

            foreach (var gestureCombination in GestureCombination.Enumerate())
            {
                var expression = faceAnimationForGestureCombinations[gestureCombination];

                var expressionData = expression.ToExpressionData(new GestureRuleData[]
                    {
                        new() {
                            Hand = HandData.Left,
                            Gesture = (GestureData)gestureCombination.LeftHand.Index(),
                        },
                        new() {
                            Hand = HandData.Right,
                            Gesture = (GestureData)gestureCombination.RightHand.Index(),
                        }
                    });

                expressions.Add(expressionData);
            }

            return new ExpressionSetData
            {
                Expressions = expressions.ToArray(),
                Name = Localization.GetTranslated(MessageKey.Get("setup.expression-set.template.combo.name"))
            };
        }

        public static bool LooksLikeFaceMorphState(Node node)
        {
            if (node is not VirtualState state)
            {
                return false;
            }

            if (state.BaseState.motion is not AnimationClip clip)
            {
                // TODO: Blend tree?
                return false;
            }

            var bindings = AnimationUtility.GetCurveBindings(clip);

            // Heuristic: If the animation clip has blend shape bindings on "body", it's likely to be a face morph animation.
            return bindings.Any(binding => binding.path.Equals("body", StringComparison.OrdinalIgnoreCase) && binding.propertyName.StartsWith("blendShape.", StringComparison.OrdinalIgnoreCase));
        }

        public static bool LooksLikeBlinkRelatedState(Node node)
        {
            if (node is not VirtualState state)
            {
                return false;
            }

            if (state.BaseState.motion is UnityEngine.Object unityObject)
            {
                if (unityObject.name.Contains("blink", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return state.BaseState.name.Contains("blink", StringComparison.OrdinalIgnoreCase);
        }

        public static bool LooksLikeToggleRelatedState(Node node)
        {
            if (node is not VirtualState state)
            {
                return false;
            }

            if (state.BaseState.motion is UnityEngine.Object unityObject)
            {
                if (unityObject.name.Contains("enable", StringComparison.OrdinalIgnoreCase) || unityObject.name.Contains("disable", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return state.BaseState.name.Contains("enable", StringComparison.OrdinalIgnoreCase) || state.BaseState.name.Contains("disable", StringComparison.OrdinalIgnoreCase);
        }
    }
}
