using System;
using UniRx;

namespace com.superneko.TurboFace.Editor.Setup
{
    public class BackedReactiveProperty<T> : ReactiveProperty<T>
    {
        Func<T> loader;

        public BackedReactiveProperty(Func<T> loader) : base(loader())
        {
            this.loader = loader;
        }

        public void Reload()
        {
            Value = loader();
        }
    }
}
