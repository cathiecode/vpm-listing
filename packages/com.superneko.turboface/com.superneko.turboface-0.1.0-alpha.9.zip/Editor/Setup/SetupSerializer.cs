using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using com.superneko.TurboFace.MiniJSON;
using com.superneko.TurboFace.Runtime.Setup;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    static class SetupSerializer
    {
        readonly struct GUIDAssetReference<T> : IAssetReference<T> where T : UnityEngine.Object
        {
            public string? GUID { get; }
            public T? Instance { get; }

            public GUIDAssetReference(T? instance, string? guid)
            {
                Instance = instance;
                GUID = guid;
            }
        }

        const int CurrentVersion = 6;

        public static SerializedDataWrapper Serialize(SetupData data)
        {
            return new SerializedDataWrapper()
            {
                Version = CurrentVersion,
                Body = Json.Serialize(SerializeSetupData(data))
            };
        }

        public static SetupData Deserialize(SerializedDataWrapper wrapper)
        {
            // NOTE: We can treat empty body + version 0 as an empty setup, because
            // there's no release which uses serialization version 0
            if (wrapper.Version == 0)
            {
                if (string.IsNullOrEmpty(wrapper.Body))
                {
                    return new SetupData();
                }
                else
                {
                    throw new System.Exception("Cannot deserialize setup data with version 0 and non-empty body.");
                }
            }

            var upgraded = Upgrade(wrapper);

            if (upgraded.Version != CurrentVersion)
            {
                Logging.Error($"Upgraded setup data is at version {upgraded.Version}, but the current version is {CurrentVersion}. This should not happen.");
            }

            return DeserializeSetupData(Json.Deserialize(upgraded.Body));
        }

        public static SerializedDataWrapper Upgrade(SerializedDataWrapper wrapperReadOnly)
        {
            var newWrapper = wrapperReadOnly;

            for (int i = 0; i < 100; i++)
            {
                var (upgraded, upgradedWrapper) = StepUpgrade(newWrapper);

                if (!upgraded)
                {
                    if (newWrapper.Version != CurrentVersion)
                    {
                        Logging.Warn($"Setup data is at version {newWrapper.Version}, but the current version is {CurrentVersion}. Consider upgrading the setup data.");
                    }

                    return newWrapper;
                }

                newWrapper = upgradedWrapper;
            }

            throw new System.InvalidOperationException("Failed to upgrade setup data after 100 iterations.");
        }

        static (bool, SerializedDataWrapper) StepUpgrade(SerializedDataWrapper wrapper)
        {
            return wrapper.Version switch
            {
                1 => (true, UpgradeV1(wrapper)),
                2 => (true, UpgradeV2(wrapper)),
                3 => (true, UpgradeV3(wrapper)),
                4 => (true, UpgradeV4(wrapper)),
                5 => (true, UpgradeV5(wrapper)),
                CurrentVersion => (false, wrapper),
                _ => throw new System.NotImplementedException(),
            };
        }

        static SerializedDataWrapper UpgradeV1(SerializedDataWrapper wrapper)
        {
            // Version 1 => 2
            // Added ShouldCancelMouthMorphing, CompatibleWithLipsync, CompatibleWithBlinking, CompatibleWithEyeMovements to ExpressionData

            var deserialized = AssertType<Dictionary<string, object>>(Json.Deserialize(wrapper.Body));

            var setsObjectList = AssertType<List<object>>(deserialized["ExpressionSets"]);

            foreach (var setObject in setsObjectList)
            {
                var setDict = AssertType<Dictionary<string, object>>(setObject);

                var expressions = AssertType<List<object>>(setDict["Expressions"]);

                foreach (var expression in expressions)
                {
                    var expressionDict = AssertType<Dictionary<string, object>>(expression);

                    expressionDict["ShouldCancelMouthMorphing"] = false;
                    expressionDict["CompatibleWithLipsync"] = true;
                    expressionDict["CompatibleWithBlinking"] = true;
                    expressionDict["CompatibleWithEyeMovements"] = true;
                }
            }

            wrapper.Version = 2;
            wrapper.Body = Json.Serialize(deserialized);

            return wrapper;
        }

        static SerializedDataWrapper UpgradeV2(SerializedDataWrapper wrapper)
        {
            // Version 2 => 3
            // Added BlinkingAnimationMode and AnimationClipForBlinking to ExpressionSetData

            var deserialized = AssertType<Dictionary<string, object>>(Json.Deserialize(wrapper.Body));

            foreach (var setObject in AssertType<List<object>>(deserialized["ExpressionSets"]))
            {
                var setDict = AssertType<Dictionary<string, object?>>(setObject);
                setDict["BlinkingAnimationMode"] = (int)BlinkingAnimationMode.UseBuiltInAnimation;
                setDict["AnimationClipForBlinking"] = null;
            }

            wrapper.Version = 3;
            wrapper.Body = Json.Serialize(deserialized);

            return wrapper;
        }

        static SerializedDataWrapper UpgradeV3(SerializedDataWrapper wrapper)
        {
            // Version 3 => 4
            // Moved BlinkingAnimationMode and AnimationClipForBlinking from ExpressionSetData to SetupData

            var deserialized = AssertType<Dictionary<string, object?>>(Json.Deserialize(wrapper.Body));

            var blinkingAnimationMode = BlinkingAnimationMode.UseBuiltInAnimation;
            string? animationClipForBlinking = null;

            var setList = AssertType<List<object>>(deserialized["ExpressionSets"]!);

            if (setList.Count != 0)
            {
                var firstSet = setList[0];
                var firstSetDict = AssertType<Dictionary<string, object?>>(firstSet);

                blinkingAnimationMode = (BlinkingAnimationMode)AssertType<int>(firstSetDict["BlinkingAnimationMode"]!);
                animationClipForBlinking = AssertNullableType<string>(firstSetDict["AnimationClipForBlinking"]!);
            }

            foreach (var setObject in AssertType<List<object>>(deserialized["ExpressionSets"]!))
            {
                var setDict = AssertType<Dictionary<string, object?>>(setObject);

                setDict.Remove("BlinkingAnimationMode");
                setDict.Remove("AnimationClipForBlinking");
            }

            deserialized["BlinkingAnimationMode"] = (int)blinkingAnimationMode;
            deserialized["AnimationClipForBlinking"] = animationClipForBlinking;

            wrapper.Version = 4;
            wrapper.Body = Json.Serialize(deserialized);

            return wrapper;
        }

        static SerializedDataWrapper UpgradeV4(SerializedDataWrapper wrapper)
        {
            // Version 4 => 5
            // DefaultFaceAnimationClip is replaced with DefaultExpression
            var deserialized = AssertType<Dictionary<string, object?>>(Json.Deserialize(wrapper.Body));

            foreach (var setObject in AssertType<List<object>>(deserialized["ExpressionSets"]!))
            {
                var setDict = AssertType<Dictionary<string, object?>>(setObject);

                var defaultFaceAnimationClip = AssertNullableType<string>(setDict["DefaultFaceAnimationClip"]!);

                var defaultExpressionDict = new Dictionary<string, object?>()
                {
                    { "AnimationClip", defaultFaceAnimationClip },
                    { "GestureRules", new List<object>() },
                    { "ShouldCancelMouthMorphing", false },
                    { "CompatibleWithLipsync", true },
                    { "CompatibleWithBlinking", true },
                    { "CompatibleWithEyeMovements", true }
                };

                setDict["DefaultExpression"] = defaultExpressionDict;
                setDict.Remove("DefaultFaceAnimationClip");
            }

            wrapper.Version = 5;
            wrapper.Body = Json.Serialize(deserialized);

            return wrapper;
        }

        static SerializedDataWrapper UpgradeV5(SerializedDataWrapper wrapper)
        {
            // Version 5 => 6
            // Added GestureLeftWeightAnimationClip, GestureRightWeightAnimationClip, UseGestureLeftWeight, UseGestureRightWeight to ExpressionData

            var deserialized = AssertType<Dictionary<string, object?>>(Json.Deserialize(wrapper.Body));

            foreach (var setObject in AssertType<List<object>>(deserialized["ExpressionSets"]!))
            {
                var setDict = AssertType<Dictionary<string, object?>>(setObject);

                var expressions = AssertType<List<object>>(setDict["Expressions"]!);

                foreach (var expression in expressions)
                {
                    var expressionDict = AssertType<Dictionary<string, object?>>(expression);

                    expressionDict["GestureLeftWeightAnimationClip"] = null;
                    expressionDict["GestureRightWeightAnimationClip"] = null;
                    expressionDict["UseGestureLeftWeight"] = false;
                    expressionDict["UseGestureRightWeight"] = false;
                }

                var defaultFaceExpressionDict = AssertType<Dictionary<string, object?>>(setDict["DefaultExpression"]!);

                defaultFaceExpressionDict["GestureLeftWeightAnimationClip"] = null;
                defaultFaceExpressionDict["GestureRightWeightAnimationClip"] = null;
                defaultFaceExpressionDict["UseGestureLeftWeight"] = false;
                defaultFaceExpressionDict["UseGestureRightWeight"] = false;
            }

            wrapper.Version = 6;
            wrapper.Body = Json.Serialize(deserialized);

            return wrapper;
        }

        static object SerializeSetupData(SetupData data)
        {
            return new Dictionary<string, object?>()
            {
                { "ExpressionSets", data.ExpressionSets.Select(SerializeExpressionSet).ToList() },
                { "BlinkingAnimationMode", (int)data.BlinkingSettings.BlinkingAnimationMode },
                { "AnimationClipForBlinking", AssetReferenceToGUID(data.BlinkingSettings.AnimationClipForBlinking) }
            };
        }

        static object SerializeExpressionSet(ExpressionSetData data)
        {
            return new Dictionary<string, object?>()
            {
                { "Name", data.Name },
                { "DefaultExpression", SerializeExpression(data.DefaultExpression) },
                { "Expressions", data.Expressions.Select(SerializeExpression).ToList() }
            };
        }

        static object SerializeExpression(ExpressionData data)
        {
            return new Dictionary<string, object?>()
            {
                { "AnimationClip", AssetReferenceToGUID(data.AnimationClip) },
                { "GestureRules", data.GestureRules.Select(SerializeGestureRule).ToList() },
                { "ShouldCancelMouthMorphing", data.ShouldCancelMouthMorphing },
                { "CompatibleWithLipsync", data.CompatibleWithLipsync },
                { "CompatibleWithBlinking", data.CompatibleWithBlinking },
                { "CompatibleWithEyeMovements", data.CompatibleWithEyeMovements },
                { "GestureLeftWeightAnimationClip", AssetReferenceToGUID(data.GestureLeftWeightAnimationClip) },
                { "GestureRightWeightAnimationClip", AssetReferenceToGUID(data.GestureRightWeightAnimationClip) },
                { "UseGestureLeftWeight", data.UseGestureLeftWeight },
                { "UseGestureRightWeight", data.UseGestureRightWeight }
            };
        }

        static object SerializeGestureRule(GestureRuleData data)
        {
            return new Dictionary<string, object>()
            {
                { "Hand", SerializeHandData(data.Hand) },
                { "Gesture", SerializeGestureData(data.Gesture) }
            };
        }

        static object SerializeGestureData(GestureData data)
        {
            return data.ToString();
        }

        static object SerializeHandData(HandData data)
        {
            return data.ToString();
        }

        static SetupData DeserializeSetupData(object obj)
        {
            var dict = AssertType<Dictionary<string, object>>(obj);

            return new SetupData()
            {
                ExpressionSets = AssertType<List<object>>(dict["ExpressionSets"]).Select(DeserializeExpressionSet).ToArray(),
                BlinkingSettings = new(
                    (BlinkingAnimationMode)AssertType<int>(dict["BlinkingAnimationMode"]),
                    GUIDToAssetReference<AnimationClip>(AssertNullableType<string>(dict["AnimationClipForBlinking"]))
                )
            };
        }

        static ExpressionSetData DeserializeExpressionSet(object obj)
        {
            var dict = AssertType<Dictionary<string, object>>(obj);

            return new ExpressionSetData()
            {
                Name = AssertType<string>(dict["Name"]),
                DefaultExpression = DeserializeExpression(dict["DefaultExpression"]),
                Expressions = AssertType<List<object>>(dict["Expressions"]).Select(DeserializeExpression).ToArray(),
            };
        }

        static ExpressionData DeserializeExpression(object obj)
        {
            var dict = AssertType<Dictionary<string, object>>(obj);

            return new ExpressionData()
            {
                AnimationClip = GUIDToAssetReference<AnimationClip>(AssertNullableType<string>(dict["AnimationClip"])),
                GestureRules = AssertType<List<object>>(dict["GestureRules"]).Select(DeserializeGestureRule).ToArray(),
                ShouldCancelMouthMorphing = AssertType<bool>(dict["ShouldCancelMouthMorphing"]),
                CompatibleWithLipsync = AssertType<bool>(dict["CompatibleWithLipsync"]),
                CompatibleWithBlinking = AssertType<bool>(dict["CompatibleWithBlinking"]),
                CompatibleWithEyeMovements = AssertType<bool>(dict["CompatibleWithEyeMovements"]),
                GestureLeftWeightAnimationClip = GUIDToAssetReference<AnimationClip>(AssertNullableType<string>(dict["GestureLeftWeightAnimationClip"])),
                GestureRightWeightAnimationClip = GUIDToAssetReference<AnimationClip>(AssertNullableType<string>(dict["GestureRightWeightAnimationClip"])),
                UseGestureLeftWeight = AssertType<bool>(dict["UseGestureLeftWeight"]),
                UseGestureRightWeight = AssertType<bool>(dict["UseGestureRightWeight"])
            };
        }

        static GestureRuleData DeserializeGestureRule(object obj)
        {
            var dict = AssertType<Dictionary<string, object>>(obj);

            return new GestureRuleData()
            {
                Hand = DeserializeHandData(dict["Hand"]),
                Gesture = DeserializeGestureData(dict["Gesture"])
            };
        }

        static GestureData DeserializeGestureData(object obj)
        {
            return (GestureData)System.Enum.Parse(typeof(GestureData), AssertType<string>(obj));
        }

        static HandData DeserializeHandData(object obj)
        {
            return (HandData)System.Enum.Parse(typeof(HandData), AssertType<string>(obj));
        }

        static T AssertType<T>(object obj)
        {
            var numericTypes = new System.Type[] {
                typeof(int),
                typeof(float),
                typeof(double),
                typeof(long),
                typeof(short),
                typeof(byte)
            };

            // numeric types is casted
            if (numericTypes.Contains(typeof(T)) && numericTypes.Contains(obj.GetType()))
            {
                return (T)System.Convert.ChangeType(obj, typeof(T));
            }

            if (obj is not T casted)
            {
                throw new System.Exception($"Expected object to be of type {typeof(T).Name}.");
            }

            return casted;
        }

        static T? AssertNullableType<T>(object obj)
        {
            if (obj == null)
            {
                return default;
            }

            var casted = AssertType<T>(obj);

            return casted;
        }

        static GUIDAssetReference<T> GUIDToAssetReference<T>(string? guid) where T : UnityEngine.Object
        {
            if (guid == null)
            {
                return new GUIDAssetReference<T>(null, null);
            }

            var assetPath = AssetDatabase.GUIDToAssetPath(guid);

            var asset = AssetDatabase.LoadAssetAtPath<T>(assetPath);

            if (asset == null)
            {
                return new GUIDAssetReference<T>(null, guid);
            }

            return new GUIDAssetReference<T>(asset, guid);
        }

        static string? AssetReferenceToGUID<T>(IAssetReference<T> obj) where T : UnityEngine.Object
        {
            if (obj is GUIDAssetReference<T> guidAssetReference)
            {
                return guidAssetReference.GUID;
            }

            if (obj.Instance == null)
            {
                return null;
            }

            if (AssetDatabase.TryGetGUIDAndLocalFileIdentifier(obj.Instance, out string guid, out long _))
            {
                return guid;
            }
            else
            {
                Logging.Warn($"Failed to get GUID for asset {obj.Instance.name}. This asset reference will not be saved correctly.");
                return null;
            }
        }
    }
}
