using System;
using System.Linq;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    public interface IAssetReference<T> where T : UnityEngine.Object?
    {
        public T? Instance { get; }
    }

    public readonly struct AssetReference<T> : IAssetReference<T> where T : UnityEngine.Object?
    {
        public T? Instance { get; }

        public AssetReference(T? instance)
        {
            Instance = instance;
        }

        public static readonly AssetReference<T> Empty = new(null);
    }

    [Serializable]
    public enum GestureData
    {
        Neutral = 0,
        Fist = 1,
        HandOpen = 2,
        FingerPoint = 3,
        Victory = 4,
        RockNRoll = 5,
        HandGun = 6,
        ThumbsUp = 7
    }

    [Serializable]
    public enum HandData
    {
        Left = 0,
        Right = 1
    }

    [Serializable]
    public class GestureRuleData
    {
        public HandData Hand = HandData.Left;
        public GestureData Gesture = GestureData.Neutral;

        public override bool Equals(object obj)
        {
            if (obj is not GestureRuleData other)
            {
                return false;
            }

            return Hand == other.Hand && Gesture == other.Gesture;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Hand, Gesture);
        }
    }

    [Serializable]
    public class ExpressionData
    {
        public IAssetReference<AnimationClip> AnimationClip = AssetReference<AnimationClip>.Empty;
        public GestureRuleData[] GestureRules = Array.Empty<GestureRuleData>();
        public bool ShouldCancelMouthMorphing = false;
        public bool CompatibleWithLipsync = true;
        public bool CompatibleWithBlinking = false;
        public bool CompatibleWithEyeMovements = true;

        public IAssetReference<AnimationClip> GestureLeftWeightAnimationClip = AssetReference<AnimationClip>.Empty;
        public IAssetReference<AnimationClip> GestureRightWeightAnimationClip = AssetReference<AnimationClip>.Empty;
        public bool UseGestureLeftWeight = false;
        public bool UseGestureRightWeight = false;

        public override bool Equals(object obj)
        {
            if (obj is not ExpressionData other)
            {
                return false;
            }

            return AnimationClip.Instance == other.AnimationClip.Instance
                   && ShouldCancelMouthMorphing == other.ShouldCancelMouthMorphing
                   && CompatibleWithLipsync == other.CompatibleWithLipsync
                   && CompatibleWithBlinking == other.CompatibleWithBlinking
                   && CompatibleWithEyeMovements == other.CompatibleWithEyeMovements
                   && GestureRules.AsEnumerable().SequenceEqual(other.GestureRules);
        }

        public override int GetHashCode()
        {
            var hashCode = new HashCode();
            hashCode.Add(AnimationClip.Instance);
            hashCode.Add(ShouldCancelMouthMorphing);
            hashCode.Add(CompatibleWithLipsync);
            hashCode.Add(CompatibleWithBlinking);
            hashCode.Add(CompatibleWithEyeMovements);

            foreach (var gestureRule in GestureRules)
            {
                hashCode.Add(gestureRule);
            }

            return hashCode.ToHashCode();
        }
    }

    public enum BlinkingAnimationMode
    {
        UseBuiltInAnimation = 0,
        GenerateFromEyeClosingAnimation = 1,
        UseCustomAnimation = 2
    }

    [Serializable]
    public class ExpressionSetData
    {
        public string Name = "";
        public ExpressionData DefaultExpression = new();
        public ExpressionData[] Expressions = Array.Empty<ExpressionData>();

        public override bool Equals(object obj)
        {
            if (obj is not ExpressionSetData other)
            {
                return false;
            }

            return Name == other.Name
                    && DefaultExpression.Equals(other.DefaultExpression)
                    && Expressions.AsEnumerable().SequenceEqual(other.Expressions);
        }

        public override int GetHashCode()
        {
            var hashCode = new HashCode();
            hashCode.Add(Name);
            hashCode.Add(DefaultExpression);
            foreach (var expression in Expressions)
            {
                hashCode.Add(expression);
            }

            return hashCode.ToHashCode();
        }
    }

    [Serializable]
    public class BlinkingSettingsData
    {
        public readonly BlinkingAnimationMode BlinkingAnimationMode = BlinkingAnimationMode.UseBuiltInAnimation;
        public readonly IAssetReference<AnimationClip> AnimationClipForBlinking = AssetReference<AnimationClip>.Empty;

        public BlinkingSettingsData(BlinkingAnimationMode blinkingAnimationMode, IAssetReference<AnimationClip> animationClipForBlinking)
        {
            BlinkingAnimationMode = blinkingAnimationMode;
            AnimationClipForBlinking = animationClipForBlinking;
        }

        public override bool Equals(object obj)
        {
            if (obj is not BlinkingSettingsData other)
            {
                return false;
            }

            return BlinkingAnimationMode == other.BlinkingAnimationMode
                    && AnimationClipForBlinking.Instance == other.AnimationClipForBlinking.Instance;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(BlinkingAnimationMode, AnimationClipForBlinking.Instance);
        }
    }

    [Serializable]
    public class SetupData
    {
        public ExpressionSetData[] ExpressionSets = Array.Empty<ExpressionSetData>();

        public BlinkingSettingsData BlinkingSettings = new(BlinkingAnimationMode.UseBuiltInAnimation, AssetReference<AnimationClip>.Empty);

        public override bool Equals(object obj)
        {
            if (obj is not SetupData other)
            {
                return false;
            }

            if (!BlinkingSettings.Equals(other.BlinkingSettings))
            {
                return false;
            }

            return ExpressionSets.AsEnumerable().SequenceEqual(other.ExpressionSets);
        }

        public override int GetHashCode()
        {
            var hashCode = new HashCode();
            hashCode.Add(BlinkingSettings);

            foreach (var expressionSet in ExpressionSets)
            {
                hashCode.Add(expressionSet);
            }

            return hashCode.ToHashCode();
        }
    }
}
