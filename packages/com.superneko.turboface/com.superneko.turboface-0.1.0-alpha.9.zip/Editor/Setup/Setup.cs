#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    using System;
    using System.Linq;
    using UniRx;
    using UnityEditor;
    using UnityEngine;

    interface DataChangeCallback
    {
        void OnBeforeChange();
        void OnChange();
    }

    internal class GestureRule : DataChangeCallback
    {
        internal GestureRuleData handRuleData;
        DataChangeCallback dataChangeCallback;

        public BackedReactiveProperty<HandData> Hand;
        public BackedReactiveProperty<GestureData> Gesture;

        public GestureRule(GestureRuleData handRuleData, DataChangeCallback dataChangeCallback)
        {
            this.handRuleData = handRuleData;
            this.dataChangeCallback = dataChangeCallback;

            Hand = new BackedReactiveProperty<HandData>(() => handRuleData.Hand);
            Gesture = new BackedReactiveProperty<GestureData>(() => handRuleData.Gesture);

            Hand.Skip(1).Subscribe(h =>
            {
                OnBeforeChange();
                handRuleData.Hand = h;
                OnChange();
            });

            Gesture.Skip(1).Subscribe(g =>
            {
                OnBeforeChange();
                handRuleData.Gesture = g;
                OnChange();
            });
        }

        public void OnBeforeChange()
        {
            dataChangeCallback.OnBeforeChange();
        }

        public void OnChange()
        {
            dataChangeCallback.OnChange();
        }

        public void ForceReload()
        {
            Hand.Reload();
            Gesture.Reload();
        }
    }

    internal class Expression : DataChangeCallback
    {
        internal ExpressionData expressionData;
        public ExpressionSet ParentSet { get; private set; }

        public BackedReactiveProperty<IAssetReference<AnimationClip>> AnimationClip;
        public BackedReactiveProperty<GestureRule[]> GestureRules;

        public BackedReactiveProperty<bool> ShouldCancelMouthMorphing;
        public BackedReactiveProperty<bool> CompatibleWithLipsync;
        public BackedReactiveProperty<bool> CompatibleWithBlinking;
        public BackedReactiveProperty<bool> CompatibleWithEyeMovements;
        public BackedReactiveProperty<IAssetReference<AnimationClip>> GestureLeftWeightAnimationClip;
        public BackedReactiveProperty<IAssetReference<AnimationClip>> GestureRightWeightAnimationClip;
        public BackedReactiveProperty<bool> UseGestureLeftWeight;
        public BackedReactiveProperty<bool> UseGestureRightWeight;

        public Expression(ExpressionData expressionData, ExpressionSet parentSet)
        {
            this.expressionData = expressionData;
            this.ParentSet = parentSet;

            AnimationClip = new BackedReactiveProperty<IAssetReference<AnimationClip>>(() => expressionData.AnimationClip);
            AnimationClip.Skip(1).Subscribe(ac =>
            {
                OnBeforeChange();
                expressionData.AnimationClip = ac;
                OnChange();
            });

            GestureRules = new BackedReactiveProperty<GestureRule[]>(() => expressionData.GestureRules.Select(hr => new GestureRule(hr, this)).ToArray());
            GestureRules.Skip(1).Subscribe(hrs =>
            {
                OnBeforeChange();
                expressionData.GestureRules = hrs.Select(hr => hr.handRuleData).ToArray();
                OnChange();
            });

            ShouldCancelMouthMorphing = new BackedReactiveProperty<bool>(() => expressionData.ShouldCancelMouthMorphing);
            ShouldCancelMouthMorphing.Skip(1).Subscribe(v =>
            {
                OnBeforeChange();
                expressionData.ShouldCancelMouthMorphing = v;
                OnChange();
            });

            CompatibleWithLipsync = new BackedReactiveProperty<bool>(() => expressionData.CompatibleWithLipsync);
            CompatibleWithLipsync.Skip(1).Subscribe(v =>
            {
                OnBeforeChange();
                expressionData.CompatibleWithLipsync = v;
                OnChange();
            });

            CompatibleWithBlinking = new BackedReactiveProperty<bool>(() => expressionData.CompatibleWithBlinking);
            CompatibleWithBlinking.Skip(1).Subscribe(v =>
            {
                OnBeforeChange();
                expressionData.CompatibleWithBlinking = v;
                OnChange();
            });

            CompatibleWithEyeMovements = new BackedReactiveProperty<bool>(() => expressionData.CompatibleWithEyeMovements);
            CompatibleWithEyeMovements.Skip(1).Subscribe(v =>
            {
                OnBeforeChange();
                expressionData.CompatibleWithEyeMovements = v;
                OnChange();
            });

            GestureLeftWeightAnimationClip = new BackedReactiveProperty<IAssetReference<AnimationClip>>(() => expressionData.GestureLeftWeightAnimationClip);
            GestureLeftWeightAnimationClip.Skip(1).Subscribe(ac =>
            {
                OnBeforeChange();
                expressionData.GestureLeftWeightAnimationClip = ac;
                OnChange();
            });

            GestureRightWeightAnimationClip = new BackedReactiveProperty<IAssetReference<AnimationClip>>(() => expressionData.GestureRightWeightAnimationClip);
            GestureRightWeightAnimationClip.Skip(1).Subscribe(ac =>
            {
                OnBeforeChange();
                expressionData.GestureRightWeightAnimationClip = ac;
                OnChange();
            });

            UseGestureLeftWeight = new BackedReactiveProperty<bool>(() => expressionData.UseGestureLeftWeight);
            UseGestureLeftWeight.Skip(1).Subscribe(v =>
            {
                OnBeforeChange();
                expressionData.UseGestureLeftWeight = v;
                OnChange();
            });

            UseGestureRightWeight = new BackedReactiveProperty<bool>(() => expressionData.UseGestureRightWeight);
            UseGestureRightWeight.Skip(1).Subscribe(v =>
            {
                OnBeforeChange();
                expressionData.UseGestureRightWeight = v;
                OnChange();
            });
        }

        public void AddGestureRuleAt(int index)
        {
            OnBeforeChange();
            GestureRules.Value = GestureRules.Value.AddedAt(index, new GestureRule(new GestureRuleData(), this));
            OnChange();
        }

        public void RemoveGestureRuleAt(int index)
        {
            OnBeforeChange();
            GestureRules.Value = GestureRules.Value.RemovedAt(index);
            OnChange();
        }

        public bool WillActiveWhenGestureCombinationIs(GestureCombination gestureCombination)
        {
            foreach (var gestureRule in GestureRules.Value)
            {
                var conditionHand = gestureRule.Hand.Value;
                var conditionGesture = GestureExt.FromData(gestureRule.Gesture.Value);
                var actualGesture = conditionHand == HandData.Left ? gestureCombination.LeftHand : gestureCombination.RightHand;

                // TODO: Not operator?
                if (conditionGesture != actualGesture)
                {
                    return false;
                }
            }

            return true;
        }

        public void OnBeforeChange()
        {
            ParentSet.OnBeforeChange();
        }

        public void OnChange()
        {
            ParentSet.OnChange();
        }

        public void ForceReload()
        {
            AnimationClip.Reload();
            GestureRules.Reload();
            ShouldCancelMouthMorphing.Reload();
            CompatibleWithLipsync.Reload();
            CompatibleWithBlinking.Reload();
            CompatibleWithEyeMovements.Reload();
            GestureLeftWeightAnimationClip.Reload();
            GestureRightWeightAnimationClip.Reload();
            UseGestureLeftWeight.Reload();
            UseGestureRightWeight.Reload();

            foreach (var gestureRule in GestureRules.Value)
            {
                gestureRule.ForceReload();
            }
        }
    }

    internal class ExpressionSet : DataChangeCallback
    {
        internal ExpressionSetData expressionSetData;
        internal DataChangeCallback dataChangeCallback;

        public BackedReactiveProperty<string> Name;
        public BackedReactiveProperty<Expression[]> Expressions;
        public Expression DefaultExpression;

        public ExpressionSet(ExpressionSetData expressionSetData, DataChangeCallback dataChangeCallback)
        {
            this.expressionSetData = expressionSetData;
            this.dataChangeCallback = dataChangeCallback;

            Name = new BackedReactiveProperty<string>(() => expressionSetData.Name);
            Expressions = new BackedReactiveProperty<Expression[]>(() => expressionSetData.Expressions.Select(e => new Expression(e, this)).ToArray());
            DefaultExpression = new Expression(expressionSetData.DefaultExpression, this);

            Expressions.Skip(1).Subscribe(e =>
            {
                OnBeforeChange();
                expressionSetData.Expressions = e.Select(e => e.expressionData).ToArray();
                OnChange();
            });

            Name.Skip(1).Subscribe(n =>
            {
                OnBeforeChange();
                expressionSetData.Name = n;
                OnChange();
            });
        }

        public void AddExpressionAt(int index)
        {
            OnBeforeChange();
            Expressions.Value = Expressions.Value.AddedAt(index, new Expression(new ExpressionData(), this));
            OnChange();
        }

        public void RemoveExpressionAt(int index)
        {
            OnBeforeChange();
            Expressions.Value = Expressions.Value.RemovedAt(index);
            OnChange();
        }

        public void OnBeforeChange()
        {
            dataChangeCallback.OnBeforeChange();
        }

        public void OnChange()
        {
            dataChangeCallback.OnChange();
        }

        public void ForceReload()
        {
            Name.Reload();
            Expressions.Reload();
            DefaultExpression.ForceReload();

            foreach (var expression in Expressions.Value)
            {
                expression.ForceReload();
            }
        }
    }

    internal class Setup : DataChangeCallback
    {
        SetupData setupData;
        DataChangeCallback? dataChangeCallback;

        public SetupData SetupData => setupData;

        public BackedReactiveProperty<ExpressionSet[]> ExpressionSets;
        public BackedReactiveProperty<BlinkingSettingsData> BlinkingSettings;

        public IObservable<bool> AnimationClipForBlinkingActive;

        public Setup(SetupData setupData, DataChangeCallback? dataChangeCallback = null)
        {
            this.setupData = setupData;
            this.dataChangeCallback = dataChangeCallback;

            ExpressionSets = new BackedReactiveProperty<ExpressionSet[]>(() => setupData.ExpressionSets.Select(s => new ExpressionSet(s, this)).ToArray());
            ExpressionSets.Skip(1).Subscribe(sets =>
            {
                OnBeforeChange();
                setupData.ExpressionSets = sets.Select(s => s.expressionSetData).ToArray();
                OnChange();
            });

            BlinkingSettings = new BackedReactiveProperty<BlinkingSettingsData>(() => setupData.BlinkingSettings);
            BlinkingSettings.Skip(1).Subscribe(bs =>
            {
                OnBeforeChange();
                setupData.BlinkingSettings = bs;
                OnChange();
            });

            AnimationClipForBlinkingActive = BlinkingSettings.Select(bs => bs.BlinkingAnimationMode != BlinkingAnimationMode.UseBuiltInAnimation);
        }

        public void AddExpressionSet()
        {
            OnBeforeChange();
            ExpressionSets.Value = ExpressionSets.Value.Added(new ExpressionSet(new ExpressionSetData(), this));
            OnChange();
        }

        public void RemoveExpressionSetAt(int index)
        {
            OnBeforeChange();
            ExpressionSets.Value = ExpressionSets.Value.RemovedAt(index);
            OnChange();
        }

        public void SwapExpressionSet(int fromIndex, int toIndex)
        {
            OnBeforeChange();
            ExpressionSets.Value = ExpressionSets.Value.Swapped(fromIndex, toIndex);
            OnChange();
        }

        public void OnBeforeChange()
        {
            dataChangeCallback?.OnBeforeChange();
        }

        public void OnChange()
        {
            dataChangeCallback?.OnChange();
        }

        public void ForceReload()
        {
            ExpressionSets.Reload();
            BlinkingSettings.Reload();

            foreach (var set in ExpressionSets.Value)
            {
                set.ForceReload();
            }
        }
    }
}
