using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.FaceEmoImporter
{
    internal static class FaceEmoSetupDataImporter
    {
        const string FaceEmoLauncherTypeName = "Suzuryg.FaceEmo.Components.FaceEmoLauncherComponent";
        const string MenuRepositoryComponentTypeName = "Suzuryg.FaceEmo.Components.Data.MenuRepositoryComponent";

        sealed class SerializableModeEntry
        {
            public readonly string Id;
            public readonly string Path;
            public readonly object Mode;

            public SerializableModeEntry(string id, string path, object mode)
            {
                Id = id;
                Path = path;
                Mode = mode;
            }
        }

        public static bool TryImportFromAvatar(VRCAvatarDescriptor descriptor, out SetupData setupData, out string[] warnings, out string? error)
        {
            var log = Logging.WithContext("FaceEmoSetupDataImporter");
            var warningList = new List<string>();

            setupData = new SetupData();
            warnings = Array.Empty<string>();
            error = null;

            if (descriptor == null)
            {
                error = "Avatar descriptor is null.";
                return false;
            }

            var menuRepositoryComponentType = ResolveType(MenuRepositoryComponentTypeName);

            if (menuRepositoryComponentType == null)
            {
                error = "FaceEmo runtime type is not available.";
                return false;
            }

            if (!TryFindMenuRepositoryComponent(descriptor, menuRepositoryComponentType, out var launcherComponent, out var menuRepositoryComponent, warningList))
            {
                error = "MenuRepositoryComponent was not found for the avatar.";
                warnings = warningList.ToArray();
                return false;
            }

            var serializableMenu = GetFieldValue(menuRepositoryComponent!, "SerializableMenu");
            if (serializableMenu == null)
            {
                error = "SerializableMenu is null.";
                warnings = warningList.ToArray();
                return false;
            }

            var registered = GetFieldValue(serializableMenu, "Registered");
            if (registered == null)
            {
                error = "SerializableMenu.Registered is null.";
                warnings = warningList.ToArray();
                return false;
            }

            var defaultSelection = GetFieldValue(serializableMenu, "DefaultSelection") as string ?? string.Empty;
            var modeEntries = new List<SerializableModeEntry>();
            CollectModeEntriesRecursive(registered, string.Empty, modeEntries, warningList);

            if (!modeEntries.Any())
            {
                error = "No registered FaceEmo mode was found.";
                warnings = warningList.ToArray();
                return false;
            }

            var convertedExpressionSets = new List<ExpressionSetData>(modeEntries.Count);

            foreach (var entry in modeEntries)
            {
                convertedExpressionSets.Add(ConvertModeToExpressionSet(entry, warningList));
            }

            if (!string.IsNullOrEmpty(defaultSelection))
            {
                var defaultSetIndex = modeEntries.FindIndex(m => m.Id == defaultSelection);
                if (defaultSetIndex > 0)
                {
                    var defaultSet = convertedExpressionSets[defaultSetIndex];
                    convertedExpressionSets.RemoveAt(defaultSetIndex);
                    convertedExpressionSets.Insert(0, defaultSet);
                }
            }

            setupData.ExpressionSets = convertedExpressionSets.ToArray();
            setupData.BlinkingSettings = ResolveBlinkingSettings(launcherComponent, warningList);

            warnings = warningList.ToArray();
            log.Info($"Imported {setupData.ExpressionSets.Length} expression set(s) from FaceEmo.");
            return true;
        }

        static ExpressionSetData ConvertModeToExpressionSet(SerializableModeEntry entry, List<string> warnings)
        {
            var mode = entry.Mode;
            var displayName = (GetFieldValue(mode, "DisplayName") as string) ?? entry.Id;
            var modeName = string.IsNullOrWhiteSpace(displayName) ? entry.Id : displayName;
            var setName = string.IsNullOrEmpty(entry.Path) ? modeName : $"{entry.Path}/{modeName}";

            var modeEyeTracking = IsTrackingMode(GetFieldValue(mode, "EyeTrackingControl"));
            var modeMouthTracking = IsTrackingMode(GetFieldValue(mode, "MouthTrackingControl"));
            var modeBlinkEnabled = GetFieldBool(mode, "BlinkEnabled");
            var modeMouthMorphCancelEnabled = GetFieldBool(mode, "MouthMorphCancelerEnabled");

            var modeDefaultClip = ResolveAnimationClip(GetFieldValue(mode, "Animation"), warnings, $"{setName}.Mode.Animation");

            var defaultExpression = new ExpressionData
            {
                AnimationClip = new AssetReference<AnimationClip>(modeDefaultClip),
                ShouldCancelMouthMorphing = modeMouthMorphCancelEnabled && modeMouthTracking,
                CompatibleWithLipsync = modeMouthTracking,
                CompatibleWithBlinking = modeBlinkEnabled,
                CompatibleWithEyeMovements = modeEyeTracking,
            };

            var expressions = new List<ExpressionData>();
            var branches = GetFieldValue(mode, "Branches") as IList;

            if (branches != null)
            {
                // FaceEmo uses first-match priority while TurboFace's later expressions override earlier ones.
                // Reverse order to preserve behavior.
                for (var i = branches.Count - 1; i >= 0; i--)
                {
                    var branch = branches[i];
                    if (branch == null)
                    {
                        continue;
                    }

                    if (TryConvertBranch(branch, warnings, $"{setName}.Branch[{i}]", out var expression, out var skipReason))
                    {
                        expressions.Add(expression);
                    }
                    else
                    {
                        warnings.Add($"{setName}.Branch[{i}] skipped: {skipReason}");
                    }
                }
            }

            return new ExpressionSetData
            {
                Name = setName,
                DefaultExpression = defaultExpression,
                Expressions = expressions.ToArray(),
            };
        }

        static bool TryConvertBranch(object branch, List<string> warnings, string context, out ExpressionData expressionData, out string reason)
        {
            expressionData = new ExpressionData();
            reason = "";

            var conditions = GetFieldValue(branch, "Conditions") as IList;
            var gestureRules = new List<GestureRuleData>();

            if (conditions != null)
            {
                for (var i = 0; i < conditions.Count; i++)
                {
                    var condition = conditions[i];
                    if (condition == null)
                    {
                        continue;
                    }

                    var comparisonOperator = GetFieldValue(condition, "ComparisonOperator");
                    if (!string.Equals(comparisonOperator?.ToString(), "Equals", StringComparison.Ordinal))
                    {
                        reason = "unsupported comparison operator (only Equals is supported).";
                        return false;
                    }

                    var hand = GetFieldValue(condition, "Hand")?.ToString();
                    var handData = hand switch
                    {
                        "Left" => HandData.Left,
                        "Right" => HandData.Right,
                        _ => (HandData?)null,
                    };

                    if (handData == null)
                    {
                        reason = "unsupported hand condition (only Left/Right are supported).";
                        return false;
                    }

                    var gestureInt = ToInt(GetFieldValue(condition, "HandGesture"));
                    if (gestureInt < 0 || gestureInt >= 8)
                    {
                        reason = $"unsupported gesture index: {gestureInt}.";
                        return false;
                    }

                    gestureRules.Add(new GestureRuleData
                    {
                        Hand = handData.Value,
                        Gesture = (GestureData)gestureInt,
                    });
                }
            }

            var eyeTracking = IsTrackingMode(GetFieldValue(branch, "EyeTrackingControl"));
            var mouthTracking = IsTrackingMode(GetFieldValue(branch, "MouthTrackingControl"));
            var blinkEnabled = GetFieldBool(branch, "BlinkEnabled");
            var mouthMorphCancelEnabled = GetFieldBool(branch, "MouthMorphCancelerEnabled");

            var baseAnimation = ResolveAnimationClip(GetFieldValue(branch, "BaseAnimation"), warnings, $"{context}.BaseAnimation");
            var leftAnimation = ResolveAnimationClip(GetFieldValue(branch, "LeftHandAnimation"), warnings, $"{context}.LeftHandAnimation");
            var rightAnimation = ResolveAnimationClip(GetFieldValue(branch, "RightHandAnimation"), warnings, $"{context}.RightHandAnimation");
            var bothAnimation = ResolveAnimationClip(GetFieldValue(branch, "BothHandsAnimation"), warnings, $"{context}.BothHandsAnimation");

            if (bothAnimation != null)
            {
                warnings.Add($"{context}.BothHandsAnimation is not supported by TurboFace importer and will be ignored.");
            }

            expressionData = new ExpressionData
            {
                AnimationClip = new AssetReference<AnimationClip>(baseAnimation),
                GestureRules = gestureRules.ToArray(),
                ShouldCancelMouthMorphing = mouthMorphCancelEnabled && mouthTracking,
                CompatibleWithLipsync = mouthTracking,
                CompatibleWithBlinking = blinkEnabled,
                CompatibleWithEyeMovements = eyeTracking,
                UseGestureLeftWeight = GetFieldBool(branch, "IsLeftTriggerUsed") && leftAnimation != null,
                UseGestureRightWeight = GetFieldBool(branch, "IsRightTriggerUsed") && rightAnimation != null,
                GestureLeftWeightAnimationClip = new AssetReference<AnimationClip>(leftAnimation),
                GestureRightWeightAnimationClip = new AssetReference<AnimationClip>(rightAnimation),
            };

            return true;
        }

        static void CollectModeEntriesRecursive(object menuItemList, string parentPath, List<SerializableModeEntry> destination, List<string> warnings)
        {
            var types = GetFieldValue(menuItemList, "Types") as IList;
            var ids = GetFieldValue(menuItemList, "Ids") as IList;
            var modes = GetFieldValue(menuItemList, "Modes") as IList;
            var groups = GetFieldValue(menuItemList, "Groups") as IList;

            if (types == null || ids == null || modes == null || groups == null)
            {
                warnings.Add("Serializable menu structure is incomplete and could not be fully imported.");
                return;
            }

            var modeQueue = new Queue<object>(modes.Cast<object>().Where(m => m != null));
            var groupQueue = new Queue<object>(groups.Cast<object>().Where(g => g != null));

            for (var i = 0; i < types.Count; i++)
            {
                var typeName = types[i]?.ToString();
                var id = i < ids.Count ? (ids[i] as string ?? $"UnknownId_{i}") : $"UnknownId_{i}";

                if (string.Equals(typeName, "Mode", StringComparison.Ordinal))
                {
                    if (!modeQueue.Any())
                    {
                        warnings.Add($"Serializable mode queue underflow at index {i}.");
                        continue;
                    }

                    destination.Add(new SerializableModeEntry(id, parentPath, modeQueue.Dequeue()));
                    continue;
                }

                if (string.Equals(typeName, "Group", StringComparison.Ordinal))
                {
                    if (!groupQueue.Any())
                    {
                        warnings.Add($"Serializable group queue underflow at index {i}.");
                        continue;
                    }

                    var group = groupQueue.Dequeue();
                    var displayName = (GetFieldValue(group, "DisplayName") as string) ?? id;
                    var groupName = string.IsNullOrWhiteSpace(displayName) ? id : displayName;
                    var nextPath = string.IsNullOrEmpty(parentPath) ? groupName : $"{parentPath}/{groupName}";
                    CollectModeEntriesRecursive(group, nextPath, destination, warnings);
                    continue;
                }

                warnings.Add($"Unknown menu item type '{typeName ?? "(null)"}' at index {i}.");
            }
        }

        static bool TryFindMenuRepositoryComponent(
            VRCAvatarDescriptor descriptor,
            Type menuRepositoryType,
            out Component? launcherComponent,
            out Component? menuRepositoryComponent,
            List<string> warnings
        )
        {
            launcherComponent = FindFaceEmoLauncherForAvatar(descriptor);
            if (launcherComponent != null)
            {
                menuRepositoryComponent = launcherComponent.gameObject.GetComponent(menuRepositoryType);
                if (menuRepositoryComponent != null)
                {
                    return true;
                }
            }

            var candidates = descriptor.gameObject.GetComponentsInChildren(menuRepositoryType, true);
            if (candidates != null && candidates.Length > 0)
            {
                if (candidates.Length > 1)
                {
                    warnings.Add($"Found multiple MenuRepositoryComponent instances under avatar. The first one ({candidates[0].name}) will be used.");
                }

                menuRepositoryComponent = candidates[0];
                return true;
            }

            menuRepositoryComponent = null;
            return false;
        }

        static Component? FindFaceEmoLauncherForAvatar(VRCAvatarDescriptor descriptor)
        {
            var launcherType = ResolveType(FaceEmoLauncherTypeName);
            if (launcherType == null)
            {
                return null;
            }

            var launchers = UnityEngine.Object.FindObjectsOfType(launcherType, true);
            foreach (var launcherObject in launchers)
            {
                if (launcherObject is not Component launcherComponent)
                {
                    continue;
                }

                var av3Setting = GetFieldValue(launcherComponent, "AV3Setting");
                if (av3Setting == null)
                {
                    continue;
                }

                var targetAvatar = GetFieldValue(av3Setting, "TargetAvatar");
                if (ReferenceEquals(targetAvatar, descriptor))
                {
                    return launcherComponent;
                }
            }

            return null;
        }

        static BlinkingSettingsData ResolveBlinkingSettings(Component? launcherComponent, List<string> warnings)
        {
            if (launcherComponent == null)
            {
                return new BlinkingSettingsData(BlinkingAnimationMode.UseBuiltInAnimation, AssetReference<AnimationClip>.Empty);
            }

            var av3Setting = GetFieldValue(launcherComponent, "AV3Setting");
            if (av3Setting == null)
            {
                return new BlinkingSettingsData(BlinkingAnimationMode.UseBuiltInAnimation, AssetReference<AnimationClip>.Empty);
            }

            var useBlinkClip = GetFieldBool(av3Setting, "UseBlinkClip");
            var blinkClip = GetFieldValue(av3Setting, "BlinkClip") as AnimationClip;

            if (useBlinkClip && blinkClip != null)
            {
                return new BlinkingSettingsData(BlinkingAnimationMode.UseCustomAnimation, new AssetReference<AnimationClip>(blinkClip));
            }

            if (useBlinkClip && blinkClip == null)
            {
                warnings.Add("AV3Setting.UseBlinkClip is true, but AV3Setting.BlinkClip is null. Using built-in blinking.");
            }

            return new BlinkingSettingsData(BlinkingAnimationMode.UseBuiltInAnimation, AssetReference<AnimationClip>.Empty);
        }

        static AnimationClip? ResolveAnimationClip(object? serializableAnimation, List<string> warnings, string context)
        {
            if (serializableAnimation == null)
            {
                return null;
            }

            var guid = GetFieldValue(serializableAnimation, "GUID") as string;
            if (string.IsNullOrWhiteSpace(guid))
            {
                warnings.Add($"{context}: animation GUID is empty.");
                return null;
            }

            var path = AssetDatabase.GUIDToAssetPath(guid);
            if (string.IsNullOrWhiteSpace(path))
            {
                warnings.Add($"{context}: animation asset path was not found for GUID '{guid}'.");
                return null;
            }

            var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(path);
            if (clip == null)
            {
                warnings.Add($"{context}: failed to load AnimationClip from '{path}'.");
                return null;
            }

            return clip;
        }

        static bool IsTrackingMode(object? enumValue)
        {
            return string.Equals(enumValue?.ToString(), "Tracking", StringComparison.Ordinal);
        }

        static bool GetFieldBool(object obj, string fieldName)
        {
            return GetFieldValue(obj, fieldName) switch
            {
                bool b => b,
                _ => false,
            };
        }

        static int ToInt(object? value)
        {
            if (value == null)
            {
                return -1;
            }

            try
            {
                return Convert.ToInt32(value, CultureInfo.InvariantCulture);
            }
            catch
            {
                return -1;
            }
        }

        static object? GetFieldValue(object? obj, string fieldName)
        {
            if (obj == null)
            {
                return null;
            }

            var field = obj.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            return field?.GetValue(obj);
        }

        static Type? ResolveType(string fullName)
        {
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                var type = assembly.GetType(fullName, false);
                if (type != null)
                {
                    return type;
                }
            }

            return null;
        }
    }
}
