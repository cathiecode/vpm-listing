using System;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace com.superneko.TurboFace.Editor
{
    [Serializable]
    internal struct AvatarData
    {
        public readonly string Name;
        public readonly Transform RootTransform;
        public readonly SkinnedMeshRenderer FaceSMR;
        public readonly string[] LipSyncBlendShapeNames;
        public readonly Vector3 HeadOffset;
        public readonly Vector3 HeadForward;

        readonly int lipSyncBlendShapeNamesHashCode;

        public AvatarData(string name, Transform rootTransform, SkinnedMeshRenderer faceSMR, string[] lipSyncBlendShapeNames, Vector3 headOffset, Vector3 headForward)
        {
            Name = name;
            RootTransform = rootTransform;
            FaceSMR = faceSMR;
            LipSyncBlendShapeNames = lipSyncBlendShapeNames;
            HeadOffset = headOffset;
            HeadForward = headForward;
            lipSyncBlendShapeNamesHashCode = string.Join(",", lipSyncBlendShapeNames).GetHashCode();
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Name, RootTransform, FaceSMR, lipSyncBlendShapeNamesHashCode, HeadOffset, HeadForward);
        }

        public static AvatarData FromAvatarDescriptor(VRCAvatarDescriptor descriptor)
        {
            if (descriptor == null)
            {
                throw new System.Exception("AvatarDescriptor is null.");
            }

            var faceSMR = descriptor.VisemeSkinnedMesh;
            var lipSyncBlendShapeNames = descriptor.VisemeBlendShapes;

            if (faceSMR == null)
            {
                throw new System.Exception("Avatar does not have a viseme skinned mesh renderer assigned.");
            }

            if (lipSyncBlendShapeNames == null)
            {
                throw new System.Exception("Avatar does not have viseme blend shape names assigned.");
            }

            var animator = descriptor.GetComponent<Animator>();

            var headOffset = Vector3.zero;
            var headForward = Vector3.forward;

            if (animator != null)
            {
                var headBone = animator.GetBoneTransform(HumanBodyBones.Head);

                if (headBone != null)
                {
                    headOffset = (headBone.position - descriptor.transform.position) * 1.05f;
                    headForward = Vector3.forward; // TODO: Calculate front from left/right hand?
                }
            }

            return new AvatarData(descriptor.gameObject.name, descriptor.transform, faceSMR, lipSyncBlendShapeNames, headOffset, headForward);
        }
    }
}
