using System;

namespace com.superneko.TurboFace.Editor
{
    internal class TemporaryObject<T> : IDisposable where T: UnityEngine.Object
    {
        T obj;

        public T Object => obj;

        public TemporaryObject(T obj)
        {
            this.obj = obj;
            this.obj.hideFlags |= UnityEngine.HideFlags.HideAndDontSave;
        }

        public void Dispose()
        {
            if (obj != null)
            {
                UnityEngine.Object.DestroyImmediate(obj);
                obj = null;
            }
        }

        public static implicit operator T(TemporaryObject<T> temporaryObject)
        {
            return temporaryObject.obj;
        }
    }

    internal static class TemporaryObject
    {
        public static TemporaryObject<T> Create<T>(T obj) where T : UnityEngine.Object
        {
            return new TemporaryObject<T>(obj);
        }

        public static TemporaryObject<T> AsTemporary<T>(this T obj) where T : UnityEngine.Object
        {
            return new TemporaryObject<T>(obj);
        }
    }
}
