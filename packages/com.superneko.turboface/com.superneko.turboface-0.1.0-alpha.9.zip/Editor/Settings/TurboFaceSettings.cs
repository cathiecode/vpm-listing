using UnityEditor;

namespace com.superneko.TurboFace.Editor.Settings
{
    [FilePath("TurboFaceGlobalSettings.asset", FilePathAttribute.Location.PreferencesFolder)]
    public class TurboFaceSettings : ScriptableSingleton<TurboFaceSettings>
    {
        string lang = "ja-JP";
        public string Language
        {
            get => lang;
            set {
                lang = value;
                Localization.SetLanguage(lang);
            }
        }

        public void Save()
        {
            Save(true);
        }
    }
}