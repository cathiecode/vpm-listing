#nullable enable

using System;

namespace com.superneko.TurboFace
{
    internal class Result
    {
        public static Result<T> Success<T>(T value) => Result<T>.Success(value);
        public static Result<T> Failure<T>(Exception error) => Result<T>.Failure(error);
        public static Result<T> Catch<T>(Func<T> func)
        {
            try
            {
                return Success(func());
            }
            catch (Exception ex)
            {
                return Failure<T>(ex);
            }
        }
    }

    internal class Result<T>
    {
        public T? Value { get; }
        public Exception? Error { get; }
        public bool IsSuccess => Error == null;

        Result(T? value, Exception? error)
        {
            Value = value;
            Error = error;
        }

        public T Unwrap()
        {
            if (Error != null)
            {
                throw new InvalidOperationException($"Tried to unwrap a Result that contains an error: {Error}");
            }

            return Value!;
        }

        public Exception UnwrapError()
        {
            if (Error == null)
            {
                throw new InvalidOperationException("Tried to unwrap an error from a Result that contains a value");
            }

            return Error!;
        }

        public Result<U> Map<U>(Func<T, U> mapper)
        {
            if (IsSuccess)
            {
                return Result<U>.Success(mapper(Value!));
            }
            else
            {
                return Result<U>.Failure(Error!);
            }
        }

        public static implicit operator Result<T>(T value)
        {
            return Success(value);
        }

        public static implicit operator Result<T>(Exception error)
        {
            return Failure(error);
        }

        public static Result<T> Success(T value)
        {
            return new Result<T>(value, default);
        }

        public static Result<T> Failure(Exception error)
        {
            return new Result<T>(default, error);
        }
    }
}