using System.Collections.Generic;
using System.Linq;
using com.superneko.TurboFace;
using com.superneko.TurboFace.Editor;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurobFace.Editor
{
    internal class ACBCurve
    {
        readonly public AnimationClipBuilder parent;
        readonly public System.Type targetType;
        readonly Dictionary<float, Keyframe> keyframes = new();

        public ACBCurve(AnimationClipBuilder parent, System.Type targetType)
        {
            this.parent = parent;
            this.targetType = targetType;
        }

        public ACBCurve KeyFrame(float time, float value)
        {
            keyframes[time] = new Keyframe(time, value);
            return this;
        }

        public ACBCurve KeyFrame(Keyframe keyframe)
        {
            keyframes[keyframe.time] = keyframe;
            return this;
        }

        public ACBCurve SubtractByFirstFrameValueOf(AnimationCurve baseCurve)
        {
            var baseValue = baseCurve.Evaluate(0f);

            var thisKeyframeTimes = keyframes.Keys.ToList();

            foreach (var time in thisKeyframeTimes)
            {
                var keyframe = keyframes[time];
                keyframe.value -= baseValue;
                keyframes[time] = keyframe;
            }

            return this;
        }

        public AnimationClip ToAnimationClip()
        {
            return parent.ToAnimationClip();
        }

        public void SetCurveTo(AnimationClip clip, string path, string propertyName)
        {
            clip.SetCurve(path, targetType, propertyName, ToAnimationCurve());
        }

        AnimationCurve ToAnimationCurve()
        {
            var curve = new AnimationCurve();

            foreach (var keyframe in keyframes.Values)
            {
                curve.AddKey(keyframe);
            }

            return curve;
        }

        public ACBCurve Clone()
        {
            var newCurve = new ACBCurve(parent, targetType);

            foreach (var key in keyframes)
            {
                newCurve.KeyFrame(key.Value);
            }

            return newCurve;
        }
    }

    internal class AnimationClipBuilder
    {
        public string Name = "New Animation Clip";

        readonly Dictionary<(string path, string propertyName), ACBCurve> floatCurves = new();

        public AnimationClipBuilder() { }

        public AnimationClipBuilder WithName(string name)
        {
            Name = name;
            return this;
        }

        public ACBCurve FloatCurve(System.Type targetType, string path, string propertyName)
        {
            return floatCurves.GetOrCreate((path, propertyName), () => new ACBCurve(this, targetType));
        }

        public ACBCurve FloatCurve(EditorCurveBinding binding)
        {
            return FloatCurve(binding.type, binding.path, binding.propertyName);
        }

        public void ApplyTo(AnimationClip clip)
        {
            clip.name = Name;

            foreach (var kvp in floatCurves)
            {
                var path = kvp.Key.path;
                var propertyName = kvp.Key.propertyName;
                var curve = kvp.Value;

                curve.SetCurveTo(clip, path, propertyName);
            }
        }

        public AnimationClip ToAnimationClip()
        {
            var clip = new AnimationClip();
            ApplyTo(clip);
            return clip;
        }

        public AnimationClipBuilder SetCurvesFrom(AnimationClipBuilder other)
        {
            foreach (var kvp in other.floatCurves)
            {
                var key = kvp.Key;
                var curve = kvp.Value;

                if (floatCurves.ContainsKey(key))
                {
                    floatCurves[key] = curve.Clone();
                }
                else
                {
                    floatCurves.Add(key, curve.Clone());
                }
            }

            return this;
        }

        public AnimationClipBuilder AdditiveFromFirstFrameValueOf(AnimationClip baseClip)
        {
            var bindings = AnimationUtility.GetCurveBindings(baseClip);

            foreach (var binding in bindings)
            {
                var baseCurve = AnimationUtility.GetEditorCurve(baseClip, binding);

                FloatCurve(binding).SubtractByFirstFrameValueOf(baseCurve);
            }

            return this;
        }

        public AnimationClipBuilder SetCurvesFrom(AnimationClip clip)
        {
            var other = FromAnimationClip(clip);

            return SetCurvesFrom(other);
        }

        public AnimationClipBuilder SetCurvesFromIfNotNull(AnimationClip? clip)
        {
            if (clip != null)
            {
                SetCurvesFrom(clip);
            }

            return this;
        }

        public static AnimationClipBuilder FromAnimationClip(AnimationClip clip)
        {
            var builder = new AnimationClipBuilder();

            var bindings = AnimationUtility.GetCurveBindings(clip);

            foreach (var binding in bindings)
            {
                var curve = AnimationUtility.GetEditorCurve(clip, binding);
                var acbCurve = builder.FloatCurve(binding.type, binding.path, binding.propertyName);

                foreach (var key in curve.keys)
                {
                    acbCurve.KeyFrame(key.time, key.value);
                }
            }

            return builder;
        }
    }
}
