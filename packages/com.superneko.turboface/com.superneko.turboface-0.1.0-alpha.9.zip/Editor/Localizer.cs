using System.Collections.Generic;
using System.Linq;
using com.superneko.TurboFace.MiniJSON;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor
{
    public class Localizer
    {
        const string LANGS_GUID = "19c6f04de40c42040b0e011e1aee678d";
        const string LANGS_DIR_PATH = "Packages/com.superneko.turboface/Assets/Localization";

        public readonly string Lang;
        readonly Dictionary<string, string> translations;

        Localizer(string lang, Dictionary<string, string> translations)
        {
            this.Lang = lang;
            this.translations = translations;
        }

        static string[]? availableLanguages = null;

        public static string[] AvailableLanguages
        {
            get
            {
                availableLanguages ??= LoadAvailableLanguages().ToArray();

                return availableLanguages;
            }
        }

        public string GetTranslated(MessageKey messageKey)
        {
            if (translations.TryGetValue(messageKey.Key, out var value))
            {
                return value;
            }

            Logging.Error($"Missing translation for message key: {messageKey.Key} in language: {Lang}");

            return messageKey.Key;
        }

        public string GetTranslated(MessageKey messageKey, params object[] args)
        {
            var formatString = GetTranslated(messageKey);

            try
            {
                return string.Format(formatString, args);
            }
            catch (System.Exception e)
            {
                Logging.Warn($"Failed to format string for message key: {messageKey.Key} with args: {string.Join(", ", args)}. Error: {e.Message}");
                return formatString;
            }
        }

        public static Localizer Load(string lang)
        {
            if (!AvailableLanguages.Contains(lang))
            {
                Logging.Error($"Language not supported: {lang}");
                return new Localizer("ja-JP", LoadLanguage("ja-JP"));
            }

            var translations = LoadLanguage(lang);

            return new Localizer(lang, translations);
        }

        static string[] LoadAvailableLanguages()
        {
            var langsPath = AssetDatabase.GUIDToAssetPath(LANGS_GUID);

            if (string.IsNullOrEmpty(langsPath))
            {
                Logging.Warn("Language folder not found. Using default path.");
                langsPath = LANGS_DIR_PATH;
            }

            if (!AssetDatabase.IsValidFolder(langsPath))
            {
                Logging.Warn($"Language folder not found: {langsPath}");
                return new string[0];
            }

            var languageFileGuids = AssetDatabase.FindAssets("", new[] { langsPath });

            return languageFileGuids.Select(guid =>
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var fileName = System.IO.Path.GetFileNameWithoutExtension(path);
                return fileName;
            }).ToArray();
        }

        static Dictionary<string, string> LoadLanguage(string lang)
        {
            var langsPath = AssetDatabase.GUIDToAssetPath(LANGS_GUID);

            if (string.IsNullOrEmpty(langsPath))
            {
                Logging.Warn("Language folder not found. Using default path.");
                langsPath = LANGS_DIR_PATH;
            }

            if (!AssetDatabase.IsValidFolder(langsPath))
            {
                Logging.Warn($"Language folder not found: {langsPath}");
                return new Dictionary<string, string>();
            }


            var languageFileGuids = AssetDatabase.FindAssets("", new[] { langsPath });

            var guid = languageFileGuids.Where(guid =>
               AssetDatabase.GUIDToAssetPath(guid).EndsWith($"{lang}.json")
            );

            if (!guid.Any())
            {
                Logging.Warn($"Language file not found: {lang} in folder: {langsPath}");
                return new Dictionary<string, string>();
            }

            return LoadAndParseJson(guid.First());
        }

        static Dictionary<string, string> LoadAndParseJson(string guid)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);

            if (string.IsNullOrEmpty(path))
            {
                throw new LogicException("Invalid GUID: " + guid);
            }

            TextAsset textAsset = AssetDatabase.LoadAssetAtPath<TextAsset>(path);

            if (textAsset == null)
            {
                throw new LogicException("Failed to Load language: " + path);
            }

            try
            {
                var data = (Dictionary<string, object>)Json.Deserialize(textAsset.text);

                var convertedData = new Dictionary<string, string>();

                foreach (var key in data.Keys.ToList())
                {
                    convertedData[key] = data[key].ToString();
                }

                return convertedData;
            }
            catch (System.Exception e)
            {
                throw new LogicException("Failed to parse JSON: " + e.Message);
            }
        }
    }
}
