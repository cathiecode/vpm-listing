using System;

namespace com.superneko.TurboFace
{
    internal class PreconditionException : ApplicationException
    {
        public PreconditionException(string message) : base(message)
        {
            
        }
    }
}
