using System.Linq;
using UnityEditor;
using UnityEngine;

namespace com.superneko.TurboFace.Editor
{
    internal static class AnimationClipTraitsExt
    {
        public static bool IsConstantAnimation(this AnimationClip clip)
        {
            return AnimationUtility.GetCurveBindings(clip)
                .Select(binding => AnimationUtility.GetEditorCurve(clip, binding))
                .All(curve => curve.IsConstantCurve());
        }

        public static bool IsConstantCurve(this AnimationCurve curve)
        {
            return curve.keys.Length <= 1 || curve.keys.Select(k => k.value).EverythingIsSame();
        }
    }
}
