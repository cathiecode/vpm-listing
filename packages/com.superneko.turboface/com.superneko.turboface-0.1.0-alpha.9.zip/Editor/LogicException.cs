using System;

namespace com.superneko.TurboFace.Editor
{
    internal class LogicException : ApplicationException
    {
        public LogicException(string message) : base(message)
        {

        }
    }
}
