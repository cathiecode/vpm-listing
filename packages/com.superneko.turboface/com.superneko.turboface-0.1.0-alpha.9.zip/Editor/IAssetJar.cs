namespace com.superneko.TurboFace.Editor
{
    public interface IAssetJar
    {
        public void AddAsset(UnityEngine.Object asset);
    }
}
