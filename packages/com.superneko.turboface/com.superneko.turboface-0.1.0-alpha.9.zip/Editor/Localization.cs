using com.superneko.TurboFace.Editor.Settings;

namespace com.superneko.TurboFace.Editor
{
    public static class Localization
    {
        static Localizer current;

        public static Localizer Current
        {
            get
            {
                current ??= Localizer.Load(TurboFaceSettings.instance.Language);

                return current;
            }
        }

        public static void SetLanguage(string lang)
        {
            if (current.Lang == lang)
            {
                return;
            }

            current = Localizer.Load(lang);
        }

        public static string GetTranslated(MessageKey messageKey)
        {
            return Current.GetTranslated(messageKey);
        }

        public static string GetTranslated(MessageKey key, params object[] args)
        {
            return Current.GetTranslated(key, args);
        }
    }
}
