namespace com.superneko.TurboFace.Editor
{
    public record MessageKey
    {
        public readonly string Key;

        MessageKey(string key)
        {
            Key = key;
        }

        public static implicit operator string(MessageKey messageKey) => messageKey.Key;
        public override string ToString() => Key;

        public static MessageKey Get(string key) => new(key);
    }
}
