namespace com.superneko.TurboFace
{
    internal struct Unit
    {
        public static readonly Unit Value = new();
    }
}
