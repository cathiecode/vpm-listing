using System;

namespace com.superneko.TurboFace
{
    public interface ILogger
    {
        void Trace(string message);
        void Trace(Func<string> messageFunc);
        void Debug(string message);
        void Info(string message);
        void Warn(string message);
        void Error(string message);

        ILogger WithContext(string context);
    }

    enum LogLevel
    {
        Trace,
        Debug,
        Info,
        Warn,
        Error
    }

    public class ConsoleLogger : ILogger
    {
        string context = "[TurboFace]";

        int currentLogLevel = (int)LogLevel.Trace;

        void ILogger.Trace(string message)
        {
            if (currentLogLevel > (int)LogLevel.Trace) return;
            UnityEngine.Debug.Log($"[Trace] {context} {message}");
        }

        // NOTE: Func<string> overload is used to avoid unnecessary string concatenation when the log level is higher than Trace
        void ILogger.Trace(Func<string> messageFunc)
        {
            if (currentLogLevel > (int)LogLevel.Trace) return;
            UnityEngine.Debug.Log($"[Trace] {context} {messageFunc()}");
        }

        void ILogger.Debug(string message)
        {
            if (currentLogLevel > (int)LogLevel.Debug) return;
            UnityEngine.Debug.Log($"[Debug] {context} {message}");
        }

        void ILogger.Info(string message)
        {
            if (currentLogLevel > (int)LogLevel.Info) return;
            UnityEngine.Debug.Log($"[Info] {context} {message}");
        }

        void ILogger.Warn(string message)
        {
            if (currentLogLevel > (int)LogLevel.Warn) return;
            UnityEngine.Debug.LogWarning($"[Warn] {context} {message}");
        }

        void ILogger.Error(string message)
        {
            if (currentLogLevel > (int)LogLevel.Error) return;
            UnityEngine.Debug.LogError($"[Error] {context} {message}");
        }

        ILogger ILogger.WithContext(string newContext)
        {
            return new ConsoleLogger { currentLogLevel = currentLogLevel, context = $"{context} [{newContext}]" };
        }
    }


    public static class Logging
    {
        public static ILogger Logger { get; set; } = new ConsoleLogger();

        public static void Trace(string message) => Logger.Trace(message);
        public static void Trace(Func<string> messageFunc) => Logger.Trace(messageFunc);
        public static void Debug(string message) => Logger.Debug(message);
        public static void Info(string message) => Logger.Info(message);
        public static void Warn(string message) => Logger.Warn(message);
        public static void Error(string message) => Logger.Error(message);
        public static ILogger WithContext(string context) => Logger.WithContext(context);
    }
}
