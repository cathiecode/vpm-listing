using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    public static class TurboFaceUtils
    {
        public static bool IsChildOf(Transform? transform, Transform? potentialParent)
        {
            if (transform == null || potentialParent == null)
            {
                return false;
            }

            var current = transform.parent;

            while (current != null)
            {
                if (current == potentialParent)
                {
                    return true;
                }

                current = current.parent;
            }

            return false;
        }

        public static string GetPathFromRoot(Transform transform)
        {
            var path = transform.name;
            var current = transform.parent;

            while (current != null)
            {
                path = current.name + "/" + path;
                current = current.parent;
            }

            return path;
        }

        public static T? LoadAssetByGUID<T>(string guid) where T : Object
        {
            var path = UnityEditor.AssetDatabase.GUIDToAssetPath(guid);

            if (string.IsNullOrEmpty(path))
            {
                return null;
            }

            return UnityEditor.AssetDatabase.LoadAssetAtPath<T>(path);
        }

        public static IEnumerable<string> Ngram(string str, int n)
        {
            if (str.Length < n)
            {
                yield break;
            }

            for (int i = 0; i <= str.Length - n; i++)
            {
                yield return str.Substring(i, n);
            }
        }

        public static char CounterPart(this char c)
        {
            switch (c)
            {
                case '(': return ')';
                case ')': return '(';
                case '[': return ']';
                case ']': return '[';
                case '{': return '}';
                case '}': return '{';
                case '<': return '>';
                case '>': return '<';
                default: return c;
            }
        }

        public static U GetOrCreate<T, U>(this Dictionary<T, U> dict, T key, System.Func<U> defaultValue)
        {
            if (!dict.TryGetValue(key, out var value))
            {
                value = defaultValue();
                dict[key] = value;
            }

            return value;
        }

        public static T[] Added<T>(this T[] array, T newValue)
        {
            var newArray = new T[array.Length + 1];

            System.Array.Copy(array, newArray, array.Length);
            
            newArray[array.Length] = newValue;

            return newArray;
        }

        public static T[] AddedAt<T>(this T[] array, int index, T newValue)
        {
            var newArray = new T[array.Length + 1];

            System.Array.Copy(array, newArray, index);

            newArray[index] = newValue;

            System.Array.Copy(array, index, newArray, index + 1, array.Length - index);

            return newArray;
        }

        public static T[] RemovedAt<T>(this T[] array, int index)
        {
            var newArray = new T[array.Length - 1];

            System.Array.Copy(array, newArray, index);

            System.Array.Copy(array, index + 1, newArray, index, array.Length - index - 1);

            return newArray;
        }

        public static T[] Swapped<T>(this T[] array, int indexA, int indexB)
        {
            var newArray = new T[array.Length];

            System.Array.Copy(array, newArray, array.Length);

            var temp = newArray[indexA];
            newArray[indexA] = newArray[indexB];
            newArray[indexB] = temp;

            return newArray;
        }

        public static bool EverythingIsSame<T>(this IEnumerable<T> enumerable)
        {
            if (enumerable.FirstOrDefault() is T first)
            {
                return enumerable.All(item => EqualityComparer<T>.Default.Equals(item, first));
            }

            return true;
        }

        public static bool EverythingFilled<T>(this IEnumerable<T> enumerable)
        {
            return enumerable.All(item => item != null);
        }

        public static float TrueRatio(this IEnumerable<bool> enumerable)
        {
            return enumerable.Average(b => b ? 1f : 0f);
        }

        public static bool EverythingTrue(this IEnumerable<bool> enumerable)
        {
            return enumerable.All(b => b);
        }

        public static Task DelayCall(System.Action exec)
        {
            var tcs = new TaskCompletionSource<bool>();

            UnityEditor.EditorApplication.delayCall += () =>
            {
                try
                {
                    exec();
                    tcs.SetResult(true);
                }
                catch (System.Exception ex)
                {
                    tcs.SetException(ex);
                }
            };

            return tcs.Task;
        }

        public static Task<T> DelayCall<T>(System.Func<T> exec)
        {
            var tcs = new TaskCompletionSource<T>();

            UnityEditor.EditorApplication.delayCall += () =>
            {
                try
                {
                    var result = exec();
                    tcs.SetResult(result);
                }
                catch (System.Exception ex)
                {
                    tcs.SetException(ex);
                }
            };

            return tcs.Task;
        }

        public static void ThrowsWhenTooManyStacks(int threshold = 100)
        {
            var stackTrace = new StackTrace();

            if (stackTrace.FrameCount > threshold)
            {
                Logging.Error($"Stack trace has {stackTrace.FrameCount} frames, which is above the threshold of {threshold}. This likely indicates an infinite loop or excessive recursion.");
                throw new System.Exception("Too many stacks");
            }
        }
    }

    class AlwaysFalseEqualityComparer<T> : IEqualityComparer<T>
    {
        public bool Equals(T? x, T? y) => false;
        public int GetHashCode(T obj) => 0;
    }

    class FastStack<T> where T : class
    {
        T?[] array;
        int count;
        T? top;

        public FastStack(int capacity)
        {
            array = new T[capacity];
            count = 0;
            top = null;
        }

        public void Push(T item)
        {
            if (count >= array.Length)
            {
                System.Array.Resize(ref array, array.Length * 2);
            }

            array[count] = item;
            count++;
            UpdateTop();
        }

        public T Pop()
        {
            count--;
            UpdateTop();
            return array[count]!;
        }

        public T Peek()
        {
            return top!;
        }

        public bool TryPeek(out T? value)
        {
            if (count == 0)
            {
                value = null;
                return false;
            }

            value = top!;
            return true;
        }

        public bool IsEmpty => count == 0;

        void UpdateTop()
        {
            if (count == 0)
            {
                top = null;
            }
            else
            {
                top = array[count - 1];
            }
        }
    }
}
