using Anatawa12.AnimatorControllerAsACode.Framework;
using UnityEngine;

namespace com.superneko.TurboFace.Editor
{
    internal class AacAssetSaver : IAssetSaver
    {
        IAssetJar assetJar;

        public AacAssetSaver(IAssetJar assetJar)
        {
            this.assetJar = assetJar;
        }

        public void Save(Object asset)
        {
            assetJar.AddAsset(asset);
        }
    }

    internal static class AssetJarExtensions
    {
        public static IAssetSaver AsAacAssetSaver(this IAssetJar assetJar)
        {
            return new AacAssetSaver(assetJar);
        }
    }
}
