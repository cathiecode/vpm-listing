using System;
using System.Linq;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Profiling;

#nullable enable

namespace com.superneko.TurboFace.Edit
{
    public class BlendShapeInfluenceData
    {

        // (BlendShape1, BlendShape2, ...) x VertexCount
        NativeArray<byte> data;
        readonly int blendShapeCount;
        readonly int vertexCount;
        readonly NativeArray<float> avgblendShapeOffset;
        readonly NativeArray<float> bleandShapeOffsetSD;
        readonly Mesh? mesh;

        public Mesh? Mesh => mesh;

        public BlendShapeInfluenceData(Mesh mesh, float threshold)
        {
            Profiler.BeginSample("BlendShapeInfluenceData.FromSkinnedMeshRenderer");

            blendShapeCount = mesh.blendShapeCount;
            vertexCount = mesh.vertexCount;
            this.mesh = mesh;

            var bitSize = vertexCount * blendShapeCount;
            var binarySize = (bitSize + 7) >> 3;

            data = new NativeArray<byte>(binarySize, Allocator.Persistent);
            avgblendShapeOffset = new NativeArray<float>(blendShapeCount, Allocator.Persistent);
            bleandShapeOffsetSD = new NativeArray<float>(blendShapeCount, Allocator.Persistent);

            var blendShapeVertices = new Vector3[vertexCount];
            var blendShapeVerticesNative = new NativeArray<float3>(vertexCount, Allocator.Temp);

            for (int i = 0; i < blendShapeCount; i++)
            {
                Profiler.BeginSample("BlendShapeInfluenceData.FromSkinnedMeshRenderer GetBlendShapeFrameVertices");
                mesh.GetBlendShapeFrameVertices(i, mesh.GetBlendShapeFrameCount(i) - 1, blendShapeVertices, null, null);
                blendShapeVerticesNative.Reinterpret<Vector3>().CopyFrom(blendShapeVertices);
                Profiler.EndSample();

                Profiler.BeginSample("BlendShapeInfluenceData.FromSkinnedMeshRenderer BlendShape Loop");
                BlendShapeInfluenceDataBurst.BlendShapeLoop(
                    threshold,
                    blendShapeCount,
                    ref data,
                    ref blendShapeVerticesNative,
                    ref avgblendShapeOffset,
                    ref bleandShapeOffsetSD,
                    i
                );
                Profiler.EndSample();
            }

            Profiler.EndSample();
        }

        ~BlendShapeInfluenceData()
        {
            if (avgblendShapeOffset.IsCreated)
            {
                avgblendShapeOffset.Dispose();
            }

            if (bleandShapeOffsetSD.IsCreated)
            {
                bleandShapeOffsetSD.Dispose();
            }

            if (data.IsCreated)
            {
                data.Dispose();
            }
        }

        public float[]? GetBlendShapeInfluenceScores(int vertexIndex)
        {
            if (mesh == null)
            {
                return null;
            }

            Profiler.BeginSample("BlendShapeInfluenceData.GetBlendShapeInfluenceScores");

            var scoreForBlendShape = new float[blendShapeCount];
            var blendShapeVertices = new Vector3[vertexCount];

            for (int i = 0; i < blendShapeCount; i++)
            {
                mesh.GetBlendShapeFrameVertices(i, mesh.GetBlendShapeFrameCount(i) - 1, blendShapeVertices, null, null);

                var vertexOffset = math.length(blendShapeVertices[vertexIndex]);
                var avgOffset = avgblendShapeOffset[i];

                scoreForBlendShape[i] = (vertexOffset - avgOffset) / bleandShapeOffsetSD[i];

                if (float.IsNaN(scoreForBlendShape[i]) || float.IsInfinity(scoreForBlendShape[i]))
                {
                    scoreForBlendShape[i] = -100.0f;
                }
            }

            Profiler.EndSample();

            return scoreForBlendShape;
        }

        public int[] GetInfluencingBlendShapesForVertex(int vertexIndex)
        {
            var t0 = Time.realtimeSinceStartup;

            var influences = new int[blendShapeCount];

            for (int i = 0; i < blendShapeCount; i++)
            {
                influences[i] = BlendShapeInfluenceDataBurst.Get(ref data, blendShapeCount, vertexIndex, i);
            }

            // Sort BlendShape by Vertex count
            influences = influences
                .Select((value, index) => new { InfluencingVerticeCount = value, BlendShapeIndex = index })
                .Where(x => x.InfluencingVerticeCount != 0)
                /*.OrderBy(x => VertexCountForBlendShape[x.BlendShapeIndex])
                .ThenBy(x => x.BlendShapeIndex)*/
                .Select(x => x.BlendShapeIndex)
                .ToArray();

            Logging.Trace($"GetInfluencingVertexForVertex took {Time.realtimeSinceStartup - t0} seconds.");

            return influences;
        }

        public Color[] GetInfluenceAsColorsForBlendShape(int blendShapeIndex)
        {
            var colors = new Color[vertexCount];

            for (int i = 0; i < vertexCount; i++)
            {
                var influenced = BlendShapeInfluenceDataBurst.Get(ref data, blendShapeCount, i, blendShapeIndex) != 0;
                colors[i] = influenced ? new Color(1, 1, 1, 1) : new Color(0, 0, 0, 0);
            }

            return colors;
        }

        public bool[] GetInfluencesForVertex(int vertexIndex)
        {
            var influences = new bool[blendShapeCount];

            for (int i = 0; i < blendShapeCount; i++)
            {
                influences[i] = BlendShapeInfluenceDataBurst.Get(ref data, blendShapeCount, vertexIndex, i) != 0;
            }

            return influences;
        }

        public static BlendShapeInfluenceData FromSkinnedMeshRenderer(SkinnedMeshRenderer renderer, float threshold)
        {
            var mesh = renderer.sharedMesh;

            var data = new BlendShapeInfluenceData(mesh, threshold);

            return data;
        }
    }
}
