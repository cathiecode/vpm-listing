using UniRx;
using UnityEditor;
using UnityEngine;
using System;

#nullable enable

namespace com.superneko.TurboFace.Edit
{
    internal class TurboFaceEditorWindow : EditorWindow
    {
        [MenuItem("Window/TurboFace")]
        public static void ShowWindow()
        {
            var window = GetWindow<TurboFaceEditorWindow>();
            window.titleContent = new GUIContent("TurboFace", TurboFaceUtils.LoadAssetByGUID<Texture2D>("caa3688c0f8fc3a4a8a9533f846e4e31"));
            window.Show();
        }

        ServiceRoot model;

        System.IDisposable subscription;

        TurboFaceGUI.EntriesView entriesView;

        Rect searchFieldRect = Rect.zero;

        void OnEnable()
        {
            model = ServiceRoot.Instance;
            entriesView = new TurboFaceGUI.EntriesView(this, model);
            entriesView.Initialize();

            var d = new CompositeDisposable();

            Observable.CombineLatest(
                model.PreviewService.IsPreviewing,
                model.ExpressionEditorService.EntriesSortKeyAspect,
                model.ExpressionEditorService.EntriesAnimationAspect,
                ValueTuple.Create
            )
                .Subscribe(_ =>
                {
                    Repaint();
                })
                .AddTo(d);

            Observable.CombineLatest(model.ExpressionEditorService.EntriesListStructureAspect).Subscribe(_ =>
            {
                EditorApplication.delayCall += () =>
                {
                    entriesView.ResetScrollPosition();
                    Repaint();
                };
            }).AddTo(d);

            subscription = d;

            SceneView.duringSceneGui += OnSceneGUI;
            EditorApplication.update += Update;
            wantsMouseMove = true;
        }

        void OnDisable()
        {
            subscription.Dispose();
            SceneView.duringSceneGui -= OnSceneGUI;
            EditorApplication.update -= Update;
        }

        void Update()
        {

        }

        void OnGUI()
        {
            if (model == null) return;

            GUILayout.BeginHorizontal();

            var mayAnimationClip = EditorGUILayout.ObjectField("Animation Clip", model.ExpressionEditorService.BaseAnimationClip.Value, typeof(AnimationClip), true);

            if (mayAnimationClip is AnimationClip clip)
            {
                model.ExpressionEditorService.SetBaseAnimationClip(clip);
            }
            else
            {
                model.ExpressionEditorService.SetBaseAnimationClip(null);
            }

            var animationClipButtonColor = model.ExpressionEditorService.BaseAnimationClip.Value != null ? Color.white : Color.cyan;

            using (TurboFaceGUI.WithColor(animationClipButtonColor))
            {
                if (GUILayout.Button("+", GUILayout.Width(EditorGUIUtility.singleLineHeight)))
                {
                    // Context menu
                    var menu = new GenericMenu();

                    menu.AddItem(new GUIContent("Create New And Edit"), false, () =>
                    {
                        string exisitingPath = "Assets";

                        if (model.ExpressionEditorService.BaseAnimationClip.Value != null)
                        {
                            exisitingPath = AssetDatabase.GetAssetPath(model.ExpressionEditorService.BaseAnimationClip.Value);
                        }

                        // New file dialog
                        var newPath = EditorUtility.SaveFilePanelInProject(
                            "Create New AnimationClip",
                            "New AnimationClip.anim",
                            "anim",
                            "Please enter a file name to save the animation clip to.",
                            exisitingPath
                        );

                        if (string.IsNullOrEmpty(newPath))
                        {
                            return;
                        }

                        var newClip = new AnimationClip();
                        AssetDatabase.CreateAsset(newClip, newPath);
                        AssetDatabase.SaveAssets();
                        model.ExpressionEditorService.SetBaseAnimationClip(newClip);
                    });

                    menu.AddItem(new GUIContent("Open Existing and Edit"), false, () =>
                    {
                        var selectedPath = EditorUtility.OpenFilePanel("Select AnimationClip", "Assets", "anim");
                        if (string.IsNullOrEmpty(selectedPath))
                        {
                            return;
                        }
                        // Convert absolute path to relative path
                        var relativePath = "Assets" + selectedPath.Substring(Application.dataPath.Length);
                        var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(relativePath);
                        if (clip != null)
                        {
                            model.ExpressionEditorService.SetBaseAnimationClip(clip);
                        }
                        else
                        {
                            EditorUtility.DisplayDialog("Invalid Selection", "The selected file is not a valid AnimationClip.", "OK");
                        }
                    });

                    if (model.ExpressionEditorService.BaseAnimationClip.Value != null)
                    {
                        menu.AddItem(new GUIContent("Duplicate And Edit"), false, () =>
                        {
                            var newClip = Instantiate(model.ExpressionEditorService.BaseAnimationClip.Value);
                            newClip.name = model.ExpressionEditorService.BaseAnimationClip.Value.name + " (Copy)";

                            // Save the new clip as an asset in the same folder as the original clip.
                            var originalPath = AssetDatabase.GetAssetPath(model.ExpressionEditorService.BaseAnimationClip.Value);
                            var newPath = AssetDatabase.GenerateUniqueAssetPath(originalPath);
                            AssetDatabase.CreateAsset(newClip, newPath);
                            AssetDatabase.SaveAssets();

                            model.ExpressionEditorService.SetBaseAnimationClip(newClip);

                            // Ping
                            EditorGUIUtility.PingObject(newClip);
                        });
                    }

                    menu.ShowAsContext();
                }
            }


            GUILayout.EndHorizontal();

            EditorGUI.BeginDisabledGroup(model.PreviewService.IsPreviewing.Value);

            model.AvatarService.SetAvatarRoot((Transform?)EditorGUILayout.ObjectField("Avatar Root", model.AvatarService.AvatarRoot.Value, typeof(Transform), true));
            model.AvatarService.SetFaceSMR((SkinnedMeshRenderer?)EditorGUILayout.ObjectField("Face SkinnedMeshRenderer", model.AvatarService.FaceSMR.Value, typeof(SkinnedMeshRenderer), true));
            model.AvatarService.SetDefaultFaceAnimation((AnimationClip?)EditorGUILayout.ObjectField("Default Face Animation", model.AvatarService.DefaultFaceAnimation.Value, typeof(AnimationClip), true));

            EditorGUI.EndDisabledGroup();

            if (model.PreviewService.IsPreviewing.Value)
            {
                if (GUILayout.Button("Stop Preview"))
                {
                    model.PreviewService.StopPreview();
                }
            }
            else
            {
                EditorGUI.BeginDisabledGroup(!model.PreviewService.CheckPreviewable().IsSuccess);

                if (GUILayout.Button("Open Preview Window"))
                {
                    model.PreviewService.StartPreview();
                }
                EditorGUI.EndDisabledGroup();
            }

            if (!model.PreviewService.CheckPreviewable().IsSuccess && model.PreviewService.CheckPreviewable().Error is Exception previewRequisitesError)
            {
                TurboFaceGUI.Exception(previewRequisitesError);
            }

            GUILayout.Space(10);

            GUILayout.BeginHorizontal();

            if (model.BlendShapePickerService.Picking.Value)
            {
                using (TurboFaceGUI.WithColor(Color.cyan))
                {
                    if (GUILayout.Button(new GUIContent(Textures.Instance.GetTexture(TextureName.Picker)), GUILayout.Width(30), GUILayout.Height(30), GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false)))
                    {
                        model.BlendShapePickerService.StopPicking();
                    }
                }
            }
            else
            {
                using (TurboFaceGUI.WithColor(model.BlendShapePickerService.PickResult.Value != null ? Color.green : Color.white))
                {
                    if (GUILayout.Button(new GUIContent(Textures.Instance.GetTexture(TextureName.Picker)), GUILayout.Width(30), GUILayout.Height(30), GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false)))
                    {
                        if (model.BlendShapePickerService.PickResult.Value != null)
                        {
                            model.BlendShapePickerService.ClearPickedVertex();
                        }

                        model.BlendShapePickerService.StartPicking();
                    }
                }
            }

            GUILayout.EndHorizontal();

            GUI.SetNextControlName("com.superneko.TurboFace.Edit.View.SearchField");

            EditorGUILayout.TextField("Search");

            if (Event.current.type == EventType.Repaint)
            {
                searchFieldRect = GUILayoutUtility.GetLastRect();
            }

            if (GUI.GetNameOfFocusedControl() == "com.superneko.TurboFace.Edit.View.SearchField")
            {
                GUI.FocusControl(null);

                var activator = searchFieldRect;

                activator.y -= searchFieldRect.height; // NOTE: Adjust position to hide behind the search field.

                ExpressionEntrySearchWindow.Open(activator, model, model.ExpressionEditorService.Expression.Value);
            }

            var mayExpression = model.ExpressionEditorService.Expression.Value;

            if (mayExpression.Value is Expression expression)
            {
                entriesView.OnGUI(model.ExpressionEditorService.Expression.Value.Unwrap(), expression.GetEntries());
            }

            if (mayExpression.Error is Exception error)
            {
                TurboFaceGUI.Exception(error);
            }

            OnGUISettings();
        }

        void OnGUISettings()
        {
            var threshold = model.ExpressionEditorService.Threshold.Value;

            var visibleThreshold = (Mathf.Log10(threshold) + 4f) / 4f;

            visibleThreshold = EditorGUILayout.Slider("Blend Shape Influence Threshold", visibleThreshold, 0f, 1f);

            var newThreshold = Mathf.Pow(10f, visibleThreshold * 4f - 4f);

            model.ExpressionEditorService.SetThreshold(newThreshold);

            model.ExpressionEditorService.SetBlendShapeFolderSplitter(EditorGUILayout.TextField("Blend Shape Folder Splitter", model.ExpressionEditorService.BlendShapeFolderSplitter.Value));
        }

        void OnSceneGUI(SceneView sceneView)
        {
            if (model == null) return;

            Event e = Event.current;

            if (model.BlendShapePickerService.Picking.Value)
            {
                if (e.type == EventType.MouseDown && e.button == 0)
                {
                    model.BlendShapePickerService.Pick(e.mousePosition);
                    e.Use();
                }
                if (e.type == EventType.Repaint) {
                    Graphics.DrawTexture(new Rect(0, 0, sceneView.position.width, sceneView.position.height), Texture2D.whiteTexture, new Rect(0, 0, 1, 1), 0, 0, 0, 0, new Color(0.0f, 0.5f, 0.5f, 0.1f));
                }
            }

            if (model.BlendShapePickerService.PickResult.Value is BlendShapePickerService.VertexSelectResultValue pickResult)
            {
                if (e.type == EventType.Repaint)
                {
                    Handles.color = Color.cyan;

                    Handles.SphereHandleCap(
                        GUIUtility.GetControlID(FocusType.Passive),
                        pickResult.PickedVertexPosition,
                        Quaternion.identity,
                        HandleUtility.GetHandleSize(pickResult.PickedVertexPosition) * 0.1f,
                        EventType.Repaint);
                }
            }
        }
    }
}

