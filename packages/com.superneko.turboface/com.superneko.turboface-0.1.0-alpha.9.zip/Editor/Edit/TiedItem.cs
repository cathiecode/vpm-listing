using System;
using JetBrains.Annotations;

#nullable enable

namespace com.superneko.TurboFace.Edit
{
    [Serializable]
    internal class TiedItem<T, U>
    {
        public readonly T Item;
        public readonly U TiedTo;

        public TiedItem(T value, U tiedTo)
        {
            Item = value;
            TiedTo = tiedTo;
        }

        public static implicit operator T(TiedItem<T, U> tiedItem) => tiedItem.Item;
    }
}
