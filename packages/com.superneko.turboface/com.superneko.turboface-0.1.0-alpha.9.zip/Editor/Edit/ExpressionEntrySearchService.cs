using System;
using System.Collections.Generic;
using UniRx;
using UnityEngine.Profiling;

#nullable enable

namespace com.superneko.TurboFace.Edit
{
    class BKNode
    {
        public ExpressionEntry Entry;
        public Dictionary<int, BKNode> Children = new();

        public BKNode(ExpressionEntry entry) => Entry = entry;

        public void Add(ExpressionEntry e)
        {
            int d = Levenshtein(Entry.DisplayName, e.DisplayName);

            if (Children.TryGetValue(d, out var child))
                child.Add(e);
            else
                Children[d] = new BKNode(e);
        }

        public void Search(ExpressionEntry query, int maxDist, List<ExpressionEntry> result)
        {
            if (Math.Abs(Entry.DisplayName.Length - query.DisplayName.Length) < maxDist)
            {
                int d = Levenshtein(Entry.DisplayName, query.DisplayName);
                if (d <= maxDist)
                    result.Add(Entry);

                // BK-tree の探索範囲
                int from = d - maxDist;
                int to = d + maxDist;

                foreach (var kv in Children)
                {
                    if (kv.Key >= from && kv.Key <= to)
                        kv.Value.Search(query, maxDist, result);
                }

                return;
            }

            foreach (var child in Children.Values)
                child.Search(query, maxDist, result);
        }

        private static int Levenshtein(string a, string b)
        {
            int n = a.Length;
            int m = b.Length;

            var dp = new int[n + 1, m + 1];
            for (int i = 0; i <= n; i++) dp[i, 0] = i;
            for (int j = 0; j <= m; j++) dp[0, j] = j;

            for (int i = 1; i <= n; i++)
                for (int j = 1; j <= m; j++)
                {
                    int cost = a[i - 1] == b[j - 1] ? 0 : 1;

                    int del = dp[i - 1, j] + 1;
                    int ins = dp[i, j - 1] + 1;
                    int sub = dp[i - 1, j - 1] + cost;

                    dp[i, j] = Math.Min(Math.Min(del, ins), sub);
                }

            return dp[n, m];
        }
    }

    class EntryQuery
    {
        public readonly string[] DisplayNameContains;

        public EntryQuery(string queryString)
        {
            DisplayNameContains = queryString.Split(new[] { ' ', '　' }, StringSplitOptions.RemoveEmptyEntries);
        }

        public bool TestEntry(ExpressionEntry entry)
        {
            foreach (var namePart in DisplayNameContains)
            {
                if (entry.DisplayName.IndexOf(namePart, StringComparison.OrdinalIgnoreCase) < 0)
                {
                    return false;
                }
            }

            return true;
        }
    }

    class EntryIndex
    {
        ExpressionEntry[] entries;
        Dictionary<ExpressionEntry, ExpressionEntry[]> similarEntryIndex = new();

        public EntryIndex(ExpressionEntry[] entries)
        {
            this.entries = entries;
            similarEntryIndex = SimilarDisplayNameEntries(entries, 3);
        }

        public ExpressionEntry[] SearchByQuery(EntryQuery query)
        {
            Profiler.BeginSample("ExpressionEntrySearchService.SearchByQuery");

            var results = new List<ExpressionEntry>();

            foreach (var entry in entries)
            {
                if (query.TestEntry(entry))
                {
                    results.Add(entry);
                }
            }

            Profiler.EndSample();

            return results.ToArray();
        }

        public ExpressionEntry[] FindBySimilarDisplayName(ExpressionEntry entry)
        {
            Profiler.BeginSample("ExpressionEntrySearchService.FindBySimilarDisplayName");

            var results = new List<ExpressionEntry>();

            if (similarEntryIndex.TryGetValue(entry, out var similarEntries))
            {
                results.AddRange(similarEntries);
            }

            Profiler.EndSample();

            return results.ToArray();
        }

        static Dictionary<ExpressionEntry, ExpressionEntry[]> SimilarDisplayNameEntries(ExpressionEntry[] entries, int maxDistance)
        {
            if (maxDistance < 0) throw new ArgumentOutOfRangeException(nameof(maxDistance));
            if (entries.Length == 0) return new Dictionary<ExpressionEntry, ExpressionEntry[]>();

            // BK-tree 構築
            var root = new BKNode(entries[0]);
            for (int i = 1; i < entries.Length; ++i)
                root.Add(entries[i]);

            var similarEntryIndex = new Dictionary<ExpressionEntry, List<ExpressionEntry>>();

            // 全件クエリ
            foreach (var e in entries)
            {
                var hits = new List<ExpressionEntry>();
                root.Search(e, maxDistance, hits);

                foreach (var h in hits)
                {
                    if (h.BlendShapeIndex == e.BlendShapeIndex)
                        continue;

                    if (!similarEntryIndex.TryGetValue(e, out var list))
                    {
                        list = new List<ExpressionEntry>();
                        similarEntryIndex[e] = list;
                    }

                    list.Add(h);
                }
            }

            // リストを配列に変換
            var result = new Dictionary<ExpressionEntry, ExpressionEntry[]>();

            foreach (var kv in similarEntryIndex)
            {
                result[kv.Key] = kv.Value.ToArray();
            }

            return result;
        }
    }

    internal class ExpressionEntrySearchService : ReactiveService
    {
        ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> entries;
        AlwaysNotifyReactiveProperty<Result<EntryIndex>> entryIndex = new(Result.Failure<EntryIndex>(new InvalidOperationException("Entry index is not built yet.")));
        AlwaysNotifyReactiveProperty<Result<ExpressionEntry[]>> searchResults = new(Result.Failure<ExpressionEntry[]>(new InvalidOperationException("Search results are not available yet.")));

        public ReactiveProperty<string> SearchQueryString = new("");
        public ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> SearchResults => searchResults.ToReadOnlyReactiveProperty();

        public ExpressionEntrySearchService(ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> entries)
        {
            this.entries = entries;
        }

        protected override void Initialize(CompositeDisposable d)
        {
            entries.Subscribe(UpdateIndex).AddTo(d);
            Observable.CombineLatest(entryIndex, SearchQueryString, ValueTuple.Create).Subscribe(UpdateSearchResults).AddTo(d);
        }

        public ExpressionEntry[] SearchByQuery(EntryQuery query)
        {
            var index = entryIndex.Value.Value;

            if (index == null) return Array.Empty<ExpressionEntry>();

            return index.SearchByQuery(query);
        }

        public ExpressionEntry[] FindSimilarEntries(ExpressionEntry entry)
        {
            var index = entryIndex.Value.Value;

            if (index == null) return Array.Empty<ExpressionEntry>();

            return index.FindBySimilarDisplayName(entry);
        }

        void UpdateIndex(Result<ExpressionEntry[]> entries)
        {
            entryIndex.Value = entries.Map(e => new EntryIndex(e));
        }

        void UpdateSearchResults((Result<EntryIndex>, string) args)
        {
            var (index, queryString) = args;

            searchResults.Value = index.Map((index) =>
            {
                if (string.IsNullOrEmpty(queryString))
                {
                    return Array.Empty<ExpressionEntry>();
                }

                var query = new EntryQuery(queryString);
                var results = index.SearchByQuery(query);
                return results;
            });
        }
    }
}
