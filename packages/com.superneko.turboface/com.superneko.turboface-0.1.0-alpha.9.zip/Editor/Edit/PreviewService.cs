using UniRx;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

#nullable enable

namespace com.superneko.TurboFace.Edit
{
    internal class PreviewService : ReactiveService
    {
        internal class PreviewModelState : ScriptableSingleton<PreviewModelState>
        {
            public ReactiveProperty<bool> IsPreviewing = new(false);
        }

        internal class FBCPreviewSceneStage : PreviewSceneStage
        {
            protected override GUIContent CreateHeaderContent()
            {
                return new GUIContent("TurboFace Preview");
            }

            protected override bool OnOpenStage()
            {
                return true;
            }

            protected override void OnCloseStage()
            {
                PreviewModelState.instance.IsPreviewing.Value = false;
                base.OnCloseStage();
            }

            public void SetScene(Scene scene)
            {
                this.scene = scene;
            }
        }

        public AlwaysNotifyReactiveProperty<Transform?> PreviewAvatarRoot = new(null);
        public AlwaysNotifyReactiveProperty<TiedItem<SkinnedMeshRenderer?, SkinnedMeshRenderer?>?> PreviewFaceSMR = new(null);
        public AlwaysNotifyReactiveProperty<TiedItem<SkinnedMeshRenderer?, SkinnedMeshRenderer?>?> QuickPreviewFaceSMR = new(null);
        public ReadOnlyReactiveProperty<bool> IsPreviewing => PreviewModelState.instance.IsPreviewing.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<(int, float)?> QuickPreviewingBlendShape => quickPreviewingBlendShape.ToReadOnlyReactiveProperty();

        readonly ReactiveProperty<(int, float)?> quickPreviewingBlendShape = new(null);

        readonly ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> entriesAnimationAspect;
        readonly ReadOnlyReactiveProperty<Result<TiedItem<float[], SkinnedMeshRenderer>>> defaultBlendShapeWeights;
        readonly ReadOnlyReactiveProperty<Transform?> avatarRoot;
        readonly ReadOnlyReactiveProperty<SkinnedMeshRenderer?> faceSMR;
        readonly ReadOnlyReactiveProperty<Result<BlendShapeInfluenceData>> influenceData;

        ReadOnlyReactiveProperty<Result<(Transform, SkinnedMeshRenderer)>>? previewRequisites;

        public PreviewService(
            ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> entriesAnimationAspect,
            ReadOnlyReactiveProperty<Result<TiedItem<float[], SkinnedMeshRenderer>>> defaultBlendShapeWeights,
            ReadOnlyReactiveProperty<Transform?> avatarRoot,
            ReadOnlyReactiveProperty<SkinnedMeshRenderer?> faceSMR,
            ReadOnlyReactiveProperty<Result<BlendShapeInfluenceData>> influenceData
        )
        {
            this.entriesAnimationAspect = entriesAnimationAspect;
            this.defaultBlendShapeWeights = defaultBlendShapeWeights;
            this.avatarRoot = avatarRoot;
            this.faceSMR = faceSMR;
            this.influenceData = influenceData;
        }

        protected override void Initialize(CompositeDisposable d)
        {
            Logging.Trace("PreviewModel: Initialize");

            PreviewModelState.instance.IsPreviewing.Subscribe(IsPreviewing =>
            {
                IsPreviewingChanged(IsPreviewing);
            }).AddTo(d);

            Observable.CombineLatest(
                PreviewAvatarRoot,
                PreviewFaceSMR,
                entriesAnimationAspect,
                defaultBlendShapeWeights,
                quickPreviewingBlendShape,
                System.ValueTuple.Create
            ).Subscribe(ApplyValuesToPreviewModel).AddTo(d);

            Observable.CombineLatest(
                entriesAnimationAspect,
                defaultBlendShapeWeights,
                QuickPreviewFaceSMR,
                quickPreviewingBlendShape,
                influenceData,
                System.ValueTuple.Create
            ).Subscribe(ApplyQuickPreview).AddTo(d);

            previewRequisites = Observable.CombineLatest(avatarRoot, faceSMR, (avatarRoot, faceSMR) =>
            {
                if (faceSMR == null)
                {
                    return new PreconditionException("faceSMR is null");
                }

                if (avatarRoot == null)
                {
                    return new PreconditionException("avatarRoot is null");
                }

                return Result<(Transform, SkinnedMeshRenderer)>.Success((avatarRoot, faceSMR));
            }).ToReadOnlyReactiveProperty().AddTo(d);
        }

        public Result<Unit> CheckPreviewable()
        {
            if (previewRequisites?.Value == null)
            {
                return new PreconditionException("previewRequisites is null");
            }

            if (!previewRequisites.Value.IsSuccess)
            {
                return new PreconditionException("previewRequisites is not successfully loaded");
            }

            if (previewRequisites.Value.Unwrap().Item1 == null || previewRequisites.Value.Unwrap().Item2 == null)
            {
                return new PreconditionException("avatarRoot or faceSMR is null");
            }

            return new Unit();
        }

        public void StartPreview()
        {
            PreviewModelState.instance.IsPreviewing.Value = true;
        }

        public void StopPreview()
        {
            PreviewModelState.instance.IsPreviewing.Value = false;
        }

        public void SetQuickPreviewBlendShape(int index, float weight)
        {
            if (index < 0)
            {
                quickPreviewingBlendShape.Value = null;
            }
            else
            {
                quickPreviewingBlendShape.Value = (index, weight);
            }
        }

        void IsPreviewingChanged(bool isPreviewing)
        {
            Logging.Trace($"PreviewModel: IsPreviewingChanged: {isPreviewing}");

            if (isPreviewing)
            {
                StartPreviewImpl();
            }
            else
            {
                StopPreviewImpl();
            }
        }

        void StartPreviewImpl()
        {
            if (StageUtility.GetCurrentStage() is FBCPreviewSceneStage)
            {
                return;
            }

            if (previewRequisites == null)
            {
                Logging.Warn("Cannot start preview: previewRequisites is null. Aborting.");
                PreviewModelState.instance.IsPreviewing.Value = false;
                return;
            }

            if (!previewRequisites.Value.IsSuccess)
            {
                Logging.Warn("Cannot start preview: At least one of prerequisites is missing. Aborting.");
                PreviewModelState.instance.IsPreviewing.Value = false;
                return;
            }

            var (avatar, faceSMR) = previewRequisites.Value.Unwrap();

            if (avatar == null || faceSMR == null)
            {
                Logging.Warn("Cannot start preview: avatar or faceSMR is null. Aborting.");
                PreviewModelState.instance.IsPreviewing.Value = false;
                return;
            }

            Logging.Trace("Preparing preview stage...");

            var mainScene = SceneManager.GetActiveScene();
            var sceneView = SceneView.lastActiveSceneView; // NOTE: Sceneview will overwrite when changing stage
            var previewScene = EditorSceneManager.NewPreviewScene();

            var pivot = sceneView != null ? sceneView.pivot : Vector3.zero;
            var rotation = sceneView != null ? sceneView.rotation : Quaternion.identity;
            var size = sceneView != null ? sceneView.size : 1f;

            var cloned = Object.Instantiate(avatar.gameObject);

            foreach (var t in cloned.GetComponentsInChildren<Transform>(true))
            {
                t.gameObject.hideFlags = HideFlags.NotEditable | HideFlags.DontSave;
            }

            foreach (var c in cloned.GetComponentsInChildren<Component>(true))
            {
                switch (c)
                {
                    case Transform:
                    case SkinnedMeshRenderer:
                    case MeshFilter:
                    case MeshRenderer:
                    case ParticleSystem:
                    case TrailRenderer:
                        break;
                    default:
                        Object.DestroyImmediate(c);
                        break;
                }
            }

            cloned.transform.SetPositionAndRotation(avatar.transform.position, avatar.transform.rotation);
            cloned.transform.localScale = avatar.transform.lossyScale;

            SceneManager.MoveGameObjectToScene(cloned, previewScene);

            PreviewAvatarRoot.Value = cloned.transform;

            var facePath = AnimationUtility.CalculateTransformPath(faceSMR.transform, avatar);

            var previewFaceObject = cloned.transform.Find(facePath)?.gameObject;
            var previewFaceSMR = previewFaceObject?.GetComponent<SkinnedMeshRenderer>();

            if (previewFaceSMR == null)
            {
                Logging.Warn("Cannot start preview: Failed to find the SkinnedMeshRenderer for preview. Aborting.");
                PreviewModelState.instance.IsPreviewing.Value = false;
                return;
            }

            PreviewFaceSMR.Value = new TiedItem<SkinnedMeshRenderer?, SkinnedMeshRenderer?>(previewFaceSMR, faceSMR);

            if (previewFaceObject != null)
            {
                var quickPreviewFaceObject = Object.Instantiate(previewFaceObject);
                quickPreviewFaceObject.name = "QuickPreviewFaceSMR";
                quickPreviewFaceObject.hideFlags = HideFlags.DontSave;
                SceneManager.MoveGameObjectToScene(quickPreviewFaceObject, previewScene);
                QuickPreviewFaceSMR.Value = new TiedItem<SkinnedMeshRenderer?, SkinnedMeshRenderer?>(quickPreviewFaceObject.GetComponent<SkinnedMeshRenderer>(), faceSMR);
                QuickPreviewFaceSMR.Value.Item!.sharedMesh = Object.Instantiate(QuickPreviewFaceSMR.Value.Item.sharedMesh);

                var material = TurboFaceUtils.LoadAssetByGUID<Material>("a249faf3d39a9ef4998fedd7ece4e54a");

                if (material != null)
                {
                    var materialCount = QuickPreviewFaceSMR.Value.Item.sharedMesh.subMeshCount;

                    var materials = new Material[materialCount];
                    for (int i = 0; i < materialCount; i++)
                    {
                        materials[i] = material;
                    }

                    QuickPreviewFaceSMR.Value.Item.sharedMaterials = materials;
                }
            }

            // Lighting
            var light = new GameObject("Directional Light", typeof(Light))
            {
                hideFlags = HideFlags.DontSave
            }.GetComponent<Light>();

            light.type = LightType.Directional;
            light.transform.position = Vector3.up * 3f + Vector3.back * 3f;
            light.transform.rotation = Quaternion.Euler(50f, 120f, 0f);
            light.intensity = 1f;
            light.color = Color.white;

            SceneManager.MoveGameObjectToScene(light.gameObject, previewScene);

            Logging.Trace("Go to preview stage.");
            var sceneStage = ScriptableObject.CreateInstance<FBCPreviewSceneStage>();
            sceneStage.SetScene(previewScene);

            StageUtility.GoToStage(sceneStage, false);

            EditorApplication.delayCall += () =>
            {
                var sv = SceneView.lastActiveSceneView;

                if (sv != null)
                {
                    sv.pivot = pivot;
                    sv.rotation = rotation;
                    sv.size = size;
                    sv.Repaint();
                }
            };
        }

        void StopPreviewImpl()
        {
            Object.DestroyImmediate(PreviewAvatarRoot.Value?.gameObject);
            PreviewAvatarRoot.Value = null;
            PreviewFaceSMR.Value = null;

            if (StageUtility.GetCurrentStage() is FBCPreviewSceneStage fbcStage)
            {
                Logging.Trace("Exiting preview stage...");
                StageUtility.GoBackToPreviousStage();
            }
        }

        void ApplyValuesToPreviewModel((Transform? previewAvatarRoot, TiedItem<SkinnedMeshRenderer, SkinnedMeshRenderer>? previewFaceSMR, Result<ExpressionEntry[]> mayEntries, Result<TiedItem<float[], SkinnedMeshRenderer>> mayDefaultBlendShapeWeights, (int, float)? quickPreviewingBlendShape) e)
        {
            Logging.Trace("PreviewModel: Applying preview data.");

            var (previewAvatarRoot, previewFaceSMR, mayEntries, mayDefaultBlendShapeWeights, quickPreviewingBlendShape) = e;

            if (previewFaceSMR == null || previewFaceSMR.Item == null)
            {
                Logging.Trace("PreviewModel: previewFaceSMR is null. Skipping.");
                return;
            }

            if (!mayEntries.IsSuccess)
            {
                Logging.Trace("PreviewModel: entryData is not successfully loaded. Skipping.");
                return;
            }

            if (!mayDefaultBlendShapeWeights.IsSuccess)
            {
                Logging.Trace("PreviewModel: defaultBlendShapeWeights is not successfully loaded. Skipping.");
                return;
            }

            var entries = mayEntries.Unwrap();
            var defaultBlendShapeWeights = mayDefaultBlendShapeWeights.Unwrap();

            if (defaultBlendShapeWeights.TiedTo != previewFaceSMR.TiedTo)
            {
                Logging.Trace("PreviewModel: defaultBlendShapeWeights is tied to a different SkinnedMeshRenderer. Skipping.");
                return;
            }

            foreach (var entry in entries)
            {
                var registeredData = entry.RegisteredData;

                if (registeredData == null)
                {
                    if (quickPreviewingBlendShape?.Item1 == entry.BlendShapeIndex)
                    {
                        var (index, weight) = quickPreviewingBlendShape.Value;
                        previewFaceSMR.Item.SetBlendShapeWeight(index, weight);
                    }
                    else
                    {
                        previewFaceSMR.Item.SetBlendShapeWeight(entry.BlendShapeIndex, defaultBlendShapeWeights.Item[entry.BlendShapeIndex]);
                    }

                    continue;
                }

                previewFaceSMR.Item.SetBlendShapeWeight(entry.BlendShapeIndex, registeredData.FirstFrameValue);
            }
        }

        void ApplyQuickPreview((Result<ExpressionEntry[]> mayEntries, Result<TiedItem<float[], SkinnedMeshRenderer>> mayDefaultBlendShapeWeights, TiedItem<SkinnedMeshRenderer?, SkinnedMeshRenderer?>? previewFaceSMR, (int, float)? quickPreviewingBlendShape, Result<BlendShapeInfluenceData> mayInfluenceData) props)
        {
            var (mayEntries, mayDefaultBlendShapeWeights, previewFaceSMR, quickPreviewingBlendShape, mayInfluenceData) = props;

            if (previewFaceSMR == null || previewFaceSMR.Item == null)
            {
                return;
            }

            if (!mayEntries.IsSuccess)
            {
                Logging.Trace("PreviewModel: entryData is not successfully loaded. Skipping quick preview update.");
                return;
            }

            if (!mayDefaultBlendShapeWeights.IsSuccess)
            {
                Logging.Trace("PreviewModel: defaultBlendShapeWeights is not successfully loaded. Skipping quick preview update.");
                return;
            }

            if (!mayInfluenceData.IsSuccess)
            {
                Logging.Trace("PreviewModel: influenceData is not successfully loaded. Skipping quick preview update.");
                return;
            }

            var entries = mayEntries.Unwrap();
            var defaultBlendShapeWeights = mayDefaultBlendShapeWeights.Unwrap();
            var influenceData = mayInfluenceData.Unwrap();

            if (defaultBlendShapeWeights.TiedTo != previewFaceSMR.TiedTo)
            {
                Logging.Trace("PreviewModel: defaultBlendShapeWeights is tied to a different SkinnedMeshRenderer. Skipping quick preview update.");
                return;
            }

            foreach (var entry in entries)
            {
                var registeredData = entry.RegisteredData;

                if (registeredData == null)
                {
                    if (quickPreviewingBlendShape != null && quickPreviewingBlendShape?.Item1 == entry.BlendShapeIndex)
                    {
                        var index = quickPreviewingBlendShape.Value.Item1;
                        var weight = quickPreviewingBlendShape.Value.Item2;

                        previewFaceSMR.Item.SetBlendShapeWeight(index, weight);
                    }
                    else
                    {
                        previewFaceSMR.Item.SetBlendShapeWeight(entry.BlendShapeIndex, defaultBlendShapeWeights.Item[entry.BlendShapeIndex]);
                    }

                    continue;
                }

                previewFaceSMR.Item.SetBlendShapeWeight(entry.BlendShapeIndex, registeredData.FirstFrameValue);
            }

            if (quickPreviewingBlendShape != null)
            {
                var color = influenceData.GetInfluenceAsColorsForBlendShape(quickPreviewingBlendShape.Value.Item1);
                previewFaceSMR.Item.sharedMesh.SetColors(color);
            }
            else
            {
                var colors = new Color[previewFaceSMR.Item.sharedMesh.vertexCount];
                previewFaceSMR.Item.sharedMesh.SetColors(colors);
            }
        }
    }
}
