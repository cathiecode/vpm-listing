using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Edit
{
    class ExpressionEntrySearchWindow : PopupWindowContent
    {
        readonly ServiceRoot model;
        readonly Result<Expression> mayExpression;

        bool focused = false;
        Rect activatorRect;
        TurboFaceGUI.EntriesView? entriesView;

        ExpressionEntrySearchWindow(ServiceRoot model, Result<Expression> expression, Rect activatorRect)
        {
            this.model = model;
            this.mayExpression = expression;
            this.activatorRect = activatorRect;
        }

        public override Vector2 GetWindowSize()
        {
            return new Vector2(activatorRect.width, 200);
        }

        public override void OnOpen()
        {
            entriesView = new TurboFaceGUI.EntriesView(editorWindow, model, false);
            editorWindow.wantsMouseMove = true;
        }

        public override void OnGUI(Rect rect)
        {
            EditorGUI.DrawRect(rect, new Color(0f, 0f, 0f));

            GUILayout.BeginArea(rect);

            GUI.SetNextControlName("com.superneko.TurboFace.Edit.ExpressionEntrySearchWindow.SearchField");

            model.ExpressionEntrySearchService.SearchQueryString.Value = EditorGUILayout.TextField(model.ExpressionEntrySearchService.SearchQueryString.Value);

            var searchResults = model.ExpressionEntrySearchService.SearchResults.Value;

            if (mayExpression.Value is Expression expressionValue)
            {
                if (searchResults.Value is ExpressionEntry[] searchResultsArray)
                {
                    entriesView?.OnGUI(expressionValue, searchResultsArray);
                }
                if (searchResults.Error is Exception ex2)
                {
                    TurboFaceGUI.Exception(ex2);
                }
            }

            if (mayExpression.Error is Exception ex)
            {
                TurboFaceGUI.Exception(ex);
            }
            GUILayout.EndArea();

            if (!focused)
            {
                GUI.FocusControl("com.superneko.TurboFace.Edit.ExpressionEntrySearchWindow.SearchField");
                focused = true;
            }

            if (Event.current.type == EventType.KeyDown)
            {
                switch (Event.current.keyCode)
                {
                    case KeyCode.Escape:
                        editorWindow.Close();
                        Event.current.Use();
                        break;
                    case KeyCode.Tab:
                        editorWindow.Close();
                        Event.current.Use();
                        break;
                }
            }
        }

        public override void OnClose()
        {

        }

        public static void Open(Rect rect, ServiceRoot model, Result<Expression> expression)
        {
            var menu = new ExpressionEntrySearchWindow(model, expression, rect);
            PopupWindow.Show(rect, menu);
        }
    }
}
