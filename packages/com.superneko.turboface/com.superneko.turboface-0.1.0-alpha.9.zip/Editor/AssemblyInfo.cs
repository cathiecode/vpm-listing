using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("com.superneko.TurboFace.Tests")]
[assembly: InternalsVisibleTo("com.superneko.turboface.editorui")]
