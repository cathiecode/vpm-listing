using UnityEngine;
using VRC.SDKBase;

namespace com.superneko.TurboFace.Runtime.Setup
{
    public abstract class TurboFaceSetupBehaviour : MonoBehaviour, IEditorOnly {}
}
