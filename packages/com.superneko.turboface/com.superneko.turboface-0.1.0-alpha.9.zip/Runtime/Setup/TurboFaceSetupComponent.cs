#nullable enable

using UnityEngine;

namespace com.superneko.TurboFace.Runtime.Setup
{
    [DisallowMultipleComponent]
    public class TurboFaceSetupComponent : TurboFaceSetupBehaviour
    {
        public SerializedDataWrapper SerializedSetupData = new();
    }
}
