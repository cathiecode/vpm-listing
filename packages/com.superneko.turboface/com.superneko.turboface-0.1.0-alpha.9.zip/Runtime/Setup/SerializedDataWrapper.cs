using System;

namespace com.superneko.TurboFace.Runtime.Setup
{
    [Serializable]
    public struct SerializedDataWrapper
    {
        public int Version;
        public string Body;
    }
}
