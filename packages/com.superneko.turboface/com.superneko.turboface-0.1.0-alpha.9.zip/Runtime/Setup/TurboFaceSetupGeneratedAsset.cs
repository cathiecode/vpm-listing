using UnityEngine;

namespace com.superneko.TurboFace.Runtime.Setup
{
    public class TurboFaceSetupGeneratedAsset : ScriptableObject
    {
        
    }
}
