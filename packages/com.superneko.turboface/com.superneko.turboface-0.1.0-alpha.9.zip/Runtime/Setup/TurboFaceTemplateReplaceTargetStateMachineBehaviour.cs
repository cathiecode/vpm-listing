using UnityEngine;
using VRC.SDKBase;

namespace com.superneko.TurboFace.Runtime.Setup
{
    public class TurboFaceTemplateReplaceTargetStateMachineBehaviour : StateMachineBehaviour, IEditorOnly
    {
        public string Name = "";
    }
}
