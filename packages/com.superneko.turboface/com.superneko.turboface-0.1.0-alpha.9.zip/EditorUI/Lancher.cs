using System.Linq;
using com.superneko.TurboFace.Editor.Setup.FaceEmoImporter;
using com.superneko.TurboFace.Editor.Setup.HeuristicAnimatorControllerParser;
using com.superneko.TurboFace.Runtime.Setup;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.ShaderKeywordFilter;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

#nullable enable

namespace com.superneko.TurboFace
{
    using com.superneko.TurboFace.Editor.Setup;
    using Edit;

    public static class TurboFaceLauncher
    {
        [MenuItem("GameObject/TurboFace", true, 0)]
        static bool CanOpenEditorWindowWithGameObject()
        {
            var gameObject = Selection.activeGameObject;

            if (gameObject == null)
            {
                return false;
            }

            if (gameObject.GetComponent("Animator") == null)
            {
                return false;
            }

            return true;
        }

        [MenuItem("GameObject/TurboFace/Open TurboFace Editor", priority = 0)]
        public static void OpenEditorWindowWithGameObject()
        {
            var selectedGameObject = Selection.activeGameObject;

            if (selectedGameObject == null)
            {
                EditorUtility.DisplayDialog(
                    "No GameObject Selected",
                    "Please select a GameObject to open the TurboFace Editor with.",
                    "OK");
                return;
            }

            Launch(selectedGameObject.transform, null, null);
        }

        [MenuItem("GameObject/TurboFace/Convert to TurboFace Setup", priority = 0)]
        public static void ParseSelectedAnimatorControllerGraph()
        {
            var selectedObject = Selection.activeObject;

            if (selectedObject is not GameObject go)
            {
                Logging.Error("Please select a GameObject with an Animator component.");
                return;
            }


            if (!go.TryGetComponent<VRCAvatarDescriptor>(out var descriptor))
            {
                Logging.Error("Please select a GameObject with a VRCAvatarDescriptor component.");
                return;
            }

            var fxRuntimeController = descriptor.baseAnimationLayers.First(layer => layer.type == VRCAvatarDescriptor.AnimLayerType.FX).animatorController;

            if (fxRuntimeController == null)
            {
                Logging.Error("The selected GameObject does not have a valid FX Animator Controller.");
                return;
            }

            var fxController = fxRuntimeController as AnimatorController;

            if (fxController == null)
            {
                Logging.Error("The selected GameObject does not have a valid FX Animator Controller.");
                return;
            }

            SetupData setupData;
            var hasFaceEmoPrefab = go.transform.Find("FaceEmoPrefab") != null;

            if (FaceEmoSetupDataImporter.TryImportFromAvatar(descriptor, out var importedSetupData, out var faceEmoWarnings, out var faceEmoError))
            {
                setupData = importedSetupData;

                foreach (var warning in faceEmoWarnings)
                {
                    Logging.Warn($"[FaceEmo Import] {warning}");
                }

                Logging.Info("Imported setup data from FaceEmo serialized data.");
            }
            else if (hasFaceEmoPrefab)
            {
                Logging.Error($"Failed to import FaceEmo serialized data: {faceEmoError ?? "Unknown error"}");
                return;
            }
            else
            {
                setupData = VRCHeuristicAnimatorControllerParser.Parse(fxController, descriptor);
            }

            var setupGameObject = new GameObject("TurboFaceSetup");
            setupGameObject.transform.SetParent(go.transform);
            setupGameObject.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            setupGameObject.transform.localScale = Vector3.one;

            var component = setupGameObject.AddComponent<TurboFaceSetupComponent>();
            component.SerializedSetupData = SetupSerializer.Serialize(setupData);

            TurboFaceSetupEditorWindow.ShowWindow(component);

            return;
        }

        [MenuItem("Assets/Open in TurboFace Editor")]
        static void OpenEditorWindowWithAnimationClip()
        {
            var selectedObject = Selection.activeObject;

            if (selectedObject is AnimationClip animationClip)
            {
                ServiceRoot.Instance.ExpressionEditorService.SetBaseAnimationClip(animationClip);
                return;
            }

            return;
        }

        [MenuItem("Assets/Open in TurboFace Editor", true)]
        static bool CanOpenEditorWindowWithAnimationClip()
        {
            var selectedObject = Selection.activeObject;

            if (selectedObject is not AnimationClip)
            {
                return false;
            }

            if (!ServiceRoot.Instance.PreviewService.CheckPreviewable().IsSuccess)
            {
                return false;
            }

            return true;
        }

        public static void Launch(Transform avatarRoot, SkinnedMeshRenderer? faceSMR, AnimationClip? baseAnimationClip)
        {
            ServiceRoot.Instance.AvatarService.SetAvatarRoot(avatarRoot);

            if (faceSMR != null)
            {
                ServiceRoot.Instance.AvatarService.SetFaceSMR(faceSMR);
            }

            if (baseAnimationClip != null)
            {
                ServiceRoot.Instance.ExpressionEditorService.SetBaseAnimationClip(baseAnimationClip);
            }

            if (ServiceRoot.Instance.AvatarService.FaceSMR.Value == null)
            {
                EditorUtility.DisplayDialog(
                    "No SkinnedMeshRenderer Found",
                    "Failed to detect the SkinnedMeshRenderer used for the face. Please set it manually.",
                    "OK");
            }
            else
            {
                ServiceRoot.Instance.PreviewService.StartPreview();
            }

            TurboFaceEditorWindow.ShowWindow();
        }
    }
}
