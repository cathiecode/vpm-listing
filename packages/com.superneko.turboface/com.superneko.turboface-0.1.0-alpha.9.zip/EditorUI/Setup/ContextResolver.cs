#nullable enable

using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup
{
    internal static class Context
    {
        public static T? GetContextValueUnwrap<T>(this VisualElement element)
        {
            var context = ResolveContext<T>(element);

            if (context != null)
            {
                return context.ContextValue;
            }

            throw new System.Exception($"Context of type {typeof(T)} not found for element {element}");
        }

        public static T? GetContextValue<T>(this VisualElement element)
        {
            var context = ResolveContext<T>(element);

            if (context != null)
            {
                return context.ContextValue;
            }

            return default;
        }

        public static IContext<T>? ResolveContext<T>(this VisualElement element)
        {
            if (element is IContext<T> context)
            {
                return context;
            }

            if (element.parent != null)
            {
                return ResolveContext<T>(element.parent);
            }

            return null;
        }
    }
}
