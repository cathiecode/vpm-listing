using UnityEditor;

namespace com.superneko.TurboFace.Editor.Setup
{
    using System;
    using com.superneko.TurboFace.Editor.Setup.Processor;
    using Runtime.Setup;
    using UniRx;
    using UnityEditor.VersionControl;
    using UnityEngine;
    using UnityEngine.UIElements;
    using VisualElements;

    [CustomEditor(typeof(TurboFaceSetupComponent))]
    internal class TurboFaceSetupComponentEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            if (GUILayout.Button(Localization.GetTranslated(MessageKey.Get("setup.open-editor.button"))))
            {
                var component = target as TurboFaceSetupComponent;

                if (component == null)
                {
                    Logging.Error("Failed to get TurboFaceSetupComponent");
                    return;
                }

                TurboFaceSetupEditorWindow.ShowWindow(component);
            }

            if (GUILayout.Button(Localization.GetTranslated(MessageKey.Get("setup.apply.button"))))
            {
                var component = target as TurboFaceSetupComponent;

                if (component == null)
                {
                    Logging.Error("Failed to get TurboFaceSetupComponent");
                    return;
                }

                var asset = CreateInstance<TurboFaceSetupGeneratedAsset>();
                AssetDatabase.CreateAsset(asset, $"Assets/TurboFaceSetupGeneratedAsset_{Guid.NewGuid()}.asset");

                var assetJar = new AssetJar(asset);

                Generator.Generate(component, assetJar);

                EditorUtility.SetDirty(asset);
                AssetDatabase.SaveAssets();
            }

            if (GUILayout.Button(Localization.GetTranslated(MessageKey.Get("setup.copy-current-setup-data.button"))))
            {
                var component = target as TurboFaceSetupComponent;

                if (component == null)
                {
                    Logging.Error("Failed to get TurboFaceSetupComponent");
                    return;
                }

                var body = component.SerializedSetupData.Body;

                EditorGUIUtility.systemCopyBuffer = body;

                Logging.Info("Copied current setup data to clipboard.");
                Logging.Info($"Current version: {component.SerializedSetupData.Version}");
            }
        }
    }
}
