using System;
using com.superneko.TurboFace.Editor.Setup.VisualElements;
using com.superneko.TurboFace.Runtime.Setup;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    class TurboFaceSetupEditorWindow : EditorWindow
    {
        public static void ShowWindow(TurboFaceSetupComponent component)
        {
            var window = GetWindow<TurboFaceSetupEditorWindow>();
            window.titleContent = new GUIContent("TurboFace Setup Editor");
            window.EditorService.EditComponent(component);
            window.Show();
        }

        [SerializeField] SetupEditorService? _editorService;

        public SetupEditorService EditorService
        {
            get
            {
                _editorService ??= new SetupEditorService();

                return _editorService;
            }
        }

        void OnEnable()
        {
            EditorService.Initialize();
            Undo.undoRedoPerformed += OnUndoRedo;
            Undo.undoRedoEvent += OnUndoRedoEvent;
        }

        void CreateGUI()
        {
            if (EditorService == null)
            {
                return;
            }

            var translationActivatorVisualElement = new TranslationActivatorVisualElement();

            var setupVisualElement = new SetupVisualElement();

            setupVisualElement.SubscribeTo(EditorService.Setup);
            setupVisualElement.SetSetupEditorService(EditorService);

            translationActivatorVisualElement.Add(setupVisualElement);
            translationActivatorVisualElement.style.alignItems = Align.Stretch;
            translationActivatorVisualElement.style.flexGrow = 1;
            translationActivatorVisualElement.style.flexShrink = 1;

            rootVisualElement.Add(translationActivatorVisualElement);
            rootVisualElement.style.alignItems = Align.Stretch;
            translationActivatorVisualElement.style.flexGrow = 1;
            translationActivatorVisualElement.style.flexShrink = 1;
        }

        void OnDisable()
        {
            _editorService?.Dispose();
            _editorService = null;

            Undo.undoRedoPerformed -= OnUndoRedo;
            Undo.undoRedoEvent -= OnUndoRedoEvent;
        }

        public void OnUndoRedo()
        {
            try
            {
                EditorService.OnExternalChange();
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }
        }

        // NOTE: Sometimes, VRCSDK and other editor extensions throw Exception in undoRedoPerformed event.
        // This prevents us from executing ForceReload(), results broken state of UI.
        // Fortunately, we have an additional chance to execute ForceReload() on Undo Event by undoRedoEvent.
        public void OnUndoRedoEvent(in UndoRedoInfo info)
        {
            try
            {
                EditorService.OnExternalChange();
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }
        }

    }
}
