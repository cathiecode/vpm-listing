using System;
using com.superneko.TurboFace.Runtime.Setup;
using UniRx;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    class SetupEditorService : ReactiveService, DataChangeCallback
    {
        class PersistentData : ScriptableSingleton<PersistentData>
        {
            public string? LastComponentPath = null;
        }

        TurboFaceSetupComponent? component = null;
        public ReactiveProperty<Setup?> Setup = new();
        public ReactiveProperty<AvatarData?> CurrentAvatarData = new();

        protected override void Initialize(CompositeDisposable d)
        {
            ObservableEditorEvents.HierarchyChanged.Subscribe(_ => SaveLastComponentPath()).AddTo(d);

            ObservableEditorEvents.PlayMode.Subscribe(mode =>
            {
                switch (mode)
                {
                    case PlayModeStateChange.EnteredEditMode:
                        RestoreLastComponentIfNeeded();
                        break;
                    case PlayModeStateChange.ExitingEditMode:
                    case PlayModeStateChange.EnteredPlayMode:
                        component = null;
                        Setup.Value = null;
                        break;
                    case PlayModeStateChange.ExitingPlayMode:
                        break;
                }
            }).AddTo(d);
        }

        public void EditComponent(TurboFaceSetupComponent newComponent)
        {
            if (newComponent == null)
            {
                Setup.Value = null;
                return;
            }

            try
            {
                Setup.Value = new Setup(SetupSerializer.Deserialize(newComponent.SerializedSetupData), this);
            }
            catch (Exception ex)
            {
                Logging.Error($"Failed to deserialize setup data: {ex}");
            }

            component = newComponent;

            CurrentAvatarData.Value = AvatarData.FromAvatarDescriptor(newComponent.GetComponentInParent<VRCAvatarDescriptor>());
        }

        public void OnExternalChange()
        {
            if (component == null)
            {
                Setup.Value = null;
                return;
            }

            try
            {
                Setup.Value = new Setup(SetupSerializer.Deserialize(component.SerializedSetupData), this);
            }
            catch (Exception ex)
            {
                Logging.Error($"Failed to deserialize setup data: {ex}");
            }
        }

        public void OnBeforeChange()
        {
            if (component == null)
            {
                return;
            }
            TurboFaceUtils.ThrowsWhenTooManyStacks();

            Undo.RecordObject(component, "Modify TurboFace Setup");
        }

        public void OnChange()
        {
            if (Setup.Value == null || component == null)
            {
                return;
            }

            component.SerializedSetupData = SetupSerializer.Serialize(Setup.Value.SetupData);
            EditorUtility.SetDirty(component);

            SaveLastComponentPath();
        }

        void SaveLastComponentPath()
        {
            if (component == null)
            {
                return;
            }

            PersistentData.instance.LastComponentPath = TurboFaceUtils.GetPathFromRoot(component.transform);
        }

        void RestoreLastComponentIfNeeded()
        {
            if (component != null)
            {
                return;
            }

            if (string.IsNullOrEmpty(PersistentData.instance.LastComponentPath))
            {
                return;
            }
            var obj = GameObject.Find(PersistentData.instance.LastComponentPath);

            if (obj == null)
            {
                PersistentData.instance.LastComponentPath = null;
                return;
            }

            if (obj.TryGetComponent<TurboFaceSetupComponent>(out var lastComponent))
            {
                EditComponent(lastComponent);
            } else
            {
                PersistentData.instance.LastComponentPath = null;
            }
        }
    }
}
