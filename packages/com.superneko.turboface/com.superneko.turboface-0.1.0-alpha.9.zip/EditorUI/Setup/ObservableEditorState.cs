using System;
using UniRx;
using UnityEditor;

namespace com.superneko.TurboFace.Editor
{
    internal class ObservableEditorEvents
    {        
        readonly static ReactiveProperty<PlayModeStateChange> playMode = new(EditorApplication.isPlaying ? PlayModeStateChange.EnteredPlayMode : PlayModeStateChange.EnteredEditMode);
        public static IReadOnlyReactiveProperty<PlayModeStateChange> PlayMode => playMode;

        readonly static Subject<Unit> hierarchyChanged = new();
        public static IObservable<Unit> HierarchyChanged => hierarchyChanged;

        [InitializeOnLoadMethod]
        static void Initialize()
        {
            EditorApplication.playModeStateChanged += (state) =>
            {
                playMode.Value = state;
            };

            EditorApplication.hierarchyChanged += () =>
            {
                hierarchyChanged.OnNext(Unit.Value);
            };
        }
    }
}
