#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    internal interface IContext<T>
    {
        public T ContextValue { get; }
    }
}
