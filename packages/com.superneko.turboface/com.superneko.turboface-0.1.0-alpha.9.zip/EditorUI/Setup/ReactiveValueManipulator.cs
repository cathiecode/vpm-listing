using System;
using UniRx;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    internal abstract class ReactiveValueManipulator<T, U> : Manipulator where U: VisualElement
    {
        protected ReactiveProperty<T>? ReactiveProperty;
        IDisposable? subscription;
        bool needsSubscribe = false;

        protected U CurrentTarget
        {
            get {
                if (target is U typedTarget)
                {
                    return typedTarget;
                }
                else
                {
                    throw new LogicException($"Target is not of type {typeof(U).Name}");
                }
            }
        }

        protected override void RegisterCallbacksOnTarget()
        {
            RegisterCallbacksOnTargetImpl();
            Subscribe();
        }

        protected override void UnregisterCallbacksFromTarget()
        {
            UnregisterCallbacksFromTargetImpl();
            Unsubscribe();
        }

        protected abstract void RegisterCallbacksOnTargetImpl();
        protected abstract void UnregisterCallbacksFromTargetImpl();

        public abstract void OnReactivePropertyChanged(T value);

        public void SubscribeTo(ReactiveProperty<T> newProperty)
        {
            ReactiveProperty = newProperty;
            UpdateSubscription();
        }

        void Subscribe()
        {
            needsSubscribe = true;
            UpdateSubscription();
        }

        void Unsubscribe()
        {
            needsSubscribe = false;
            UpdateSubscription();
        }

        void UpdateSubscription()
        {
            subscription?.Dispose();

            if (needsSubscribe)
            {
                if (ReactiveProperty != null)
                {
                    subscription = ReactiveProperty.Subscribe(OnReactivePropertyChanged);
                }
            }
        }

    }
}
