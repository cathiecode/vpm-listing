using System;
using UniRx;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    using Editor.Processor;

    internal class ExpressionSetSummaryVisualElement : InnerReactiveVisualElement<ExpressionSet>
    {
        public new class UxmlFactory : UxmlFactory<ExpressionSetSummaryVisualElement, UxmlTraits> { }

        TextField nameField;
        ExpressionIconVisualElement iconVisualElement;

        public ExpressionSetSummaryVisualElement() : base()
        {
            var tree = UIDocumentLoader.Instance.Load("ExpressionSetSummaryVisualElement").CloneTree();

            nameField = tree.Q<TextField>("Name");
            nameField.RegisterCallback<ChangeEvent<string>>(evt =>
            {
                if (CurrentTarget != null)
                {
                    CurrentTarget.Name.Value = evt.newValue;
                }
            });

            iconVisualElement = tree.Q<ExpressionIconVisualElement>("ExpressionIconVisualElement");

            SetEnabled(false);

            Add(tree);
        }

        protected override void OnSubscribe(ExpressionSet expressionSet, CompositeDisposable subscription)
        {
            expressionSet.Name.Subscribe(nameField.SetValueWithoutNotify).AddTo(subscription);

            var setupEditorService = this.GetContextValueUnwrap<SetupEditorService?>();

            if (setupEditorService == null)
            {
                Logging.Error("SetupEditorService not found in context for ExpressionVisualElement");
            }
            else
            {
                expressionSet.DefaultExpression.AnimationClip.CombineLatest(
                        setupEditorService.CurrentAvatarData,
                        ValueTuple.Create
                    )
                    .Subscribe(args =>
                    {
                        var (mayAnimationClip, mayAvatarData) = args;

                        if (mayAvatarData is not AvatarData avatarData)
                        {
                            iconVisualElement.SetIconReference(null);
                            return;
                        }

                        iconVisualElement.SetIconReference(
                            IconGenerationService.Instance.GetIcon(
                                avatarData,
                                new[] { mayAnimationClip.Instance }
                            )
                        );
                    })
                    .AddTo(subscription);
            }


            SetEnabled(true);
        }

        protected override void OnUnsubscribe()
        {
            nameField.SetValueWithoutNotify(string.Empty);

            SetEnabled(false);
        }
    }
}
