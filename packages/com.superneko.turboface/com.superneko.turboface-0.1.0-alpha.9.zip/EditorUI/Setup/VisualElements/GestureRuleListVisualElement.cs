namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    using com.superneko.TurboFace.Editor.Setup;
    using UniRx;
    using UnityEditor.UIElements;
    using UnityEngine;
    using UnityEngine.UIElements;

    internal class GestureRuleListVisualElement : ReactiveListViewVisualElement<GestureRule[]>
    {
        public new class UxmlFactory : UxmlFactory<GestureRuleListVisualElement, UxmlTraits> { }

        public GestureRuleListVisualElement() : base()
        {
            makeItem = () => new GestureRuleVisualElement();

            bindItem = (element, index) =>
            {
                if (ReactiveProperty == null) return;

                var gestureRuleElement = (GestureRuleVisualElement)element;
                gestureRuleElement.SubscribeTo(ReactiveProperty.Value[index]);
            };
        }
    }
}
