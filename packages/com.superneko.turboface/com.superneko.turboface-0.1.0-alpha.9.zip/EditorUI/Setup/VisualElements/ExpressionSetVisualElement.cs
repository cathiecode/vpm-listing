using System;
using System.Linq;
using System.Linq.Expressions;
using UniRx;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class ExpressionSetVisualElement : InnerReactiveVisualElement<ExpressionSet>
    {
        public new class UxmlFactory : UxmlFactory<ExpressionSetVisualElement, UxmlTraits> { }

        TextField nameField;
        ExpressionVisualElement defaultExpressionVisualElement;

        public ExpressionSetVisualElement() : base()
        {
            var tree = UIDocumentLoader.Instance.Load("ExpressionSetVisualElement").CloneTree();

            nameField = tree.Q<TextField>("Name");
            nameField.RegisterCallback<ChangeEvent<string>>(evt =>
            {
                if (CurrentTarget != null)
                {
                    CurrentTarget.Name.Value = evt.newValue;
                }
            });

            defaultExpressionVisualElement = tree.Q<ExpressionVisualElement>("DefaultExpression");

            SetEnabled(false);

            Add(tree);
        }

        protected override void OnSubscribe(ExpressionSet expressionSet, CompositeDisposable subscription)
        {
            expressionSet.Name.Subscribe(nameField.SetValueWithoutNotify).AddTo(subscription);
            defaultExpressionVisualElement.SubscribeTo(expressionSet.DefaultExpression);

            SetEnabled(true);
        }

        protected override void OnUnsubscribe()
        {
            nameField.SetValueWithoutNotify(string.Empty);
            defaultExpressionVisualElement.SubscribeTo(null);

            SetEnabled(false);
        }
    }
}
