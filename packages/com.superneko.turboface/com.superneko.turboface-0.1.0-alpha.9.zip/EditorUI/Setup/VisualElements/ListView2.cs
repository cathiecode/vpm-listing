using System;
using System.Collections.Generic;
using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class ListView2 : ListView
    {
        class ListView2Controller : BaseListViewController
        {
            ListView2 listView2 => (ListView2)view;

            protected override void BindItem(VisualElement element, int index)
            {
                listView2.bindItem.Invoke(element, index);
            }

            protected override void DestroyItem(VisualElement element)
            {
                listView2.destroyItem?.Invoke(element);
            }

            protected override VisualElement MakeItem()
            {
                return listView2.makeItem();
            }

            protected override void UnbindItem(VisualElement element, int index)
            {
                listView2.unbindItem?.Invoke(element, index);
            }

            public override void AddItems(int itemCount)
            {
                listView2.addItem?.Invoke(listView2.itemsSource.Count);
            }

            public override void RemoveItem(int index)
            {
                listView2.removeItem?.Invoke(index);
            }

            public override void RemoveItems(List<int> indices)
            {
                indices.Sort();
                for (int i = indices.Count - 1; i >= 0; i--)
                {
                    listView2.removeItem?.Invoke(indices[i]);
                }
            }
        }

        public new class UxmlFactory : UxmlFactory<ListView2, UxmlTraits> { }

        public Action<int> addItem;
        public Action<int> removeItem;

        public ListView2() : base()
        {
            
        }

        protected override CollectionViewController CreateViewController()
        {
            return new ListView2Controller();
        }
    }
}
