using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class ExpressionListVisualElement : ReactiveListViewVisualElement<Expression[]>
    {
        public new class UxmlFactory : UxmlFactory<ExpressionListVisualElement, UxmlTraits> { }

        public ExpressionListVisualElement() : base()
        {
            makeItem += () => new ExpressionVisualElement();
            
            bindItem += (element, index) =>
            {
                if (ReactiveProperty == null) return;

                var expressionElement = (ExpressionVisualElement)element;
                expressionElement.SubscribeTo(ReactiveProperty.Value?[index]);
            };
        }
    }
}
