using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class PopperVisualElement: VisualElement
    {
        public new class UxmlFactory : UxmlFactory<PopperVisualElement, UxmlTraits> { }

        float x = 0;
        float y = 0;

        float width = 100;
        float height = 100;

        public PopperVisualElement() : base()
        {
            pickingMode = PickingMode.Ignore;
            style.position = Position.Absolute;
        }

        public void UpdatePosition()
        {
            style.left = 0;
            style.top = 0;

            style.width = new StyleLength(new Length(width));
            style.height = new StyleLength(new Length(height));

            var left = x;
            var top = y;

            if (left + width > parent?.layout.width)
            {
                left = parent.layout.width - width;
            }

            if (top + height > parent?.layout.height)
            {
                top = parent.layout.height - height;
            }

            style.translate = new StyleTranslate(new Translate(left, top));
        }

        public PopperVisualElement SetPosition(float x, float y)
        {
            this.x = x;
            this.y = y;
            UpdatePosition();
            return this;
        }

        public PopperVisualElement SetSize(float width, float height)
        {
            this.width = width;
            this.height = height;
            UpdatePosition();
            return this;
        }
    }
}
