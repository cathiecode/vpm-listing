using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class TranslationActivatorVisualElement : VisualElement, IContext<TranslationActivator>
    {
        public TranslationActivator ContextValue => new();
    }
}
