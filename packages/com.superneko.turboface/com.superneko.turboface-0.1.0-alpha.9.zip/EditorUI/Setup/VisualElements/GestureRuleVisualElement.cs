namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    using com.superneko.TurboFace.Editor.Setup;
    using UniRx;
    using UnityEngine.UIElements;

    internal class GestureRuleVisualElement : InnerReactiveVisualElement<GestureRule>
    {
        public new class UxmlFactory : UxmlFactory<GestureRuleVisualElement, UxmlTraits> { }
        public new class UxmlTraits : VisualElement.UxmlTraits { }

        public GestureRuleVisualElement()
        {
            var tree = UIDocumentLoader.Instance.Load("GestureRuleVisualElement").CloneTree();

            var handField = tree.Q<EnumField>("Hand");
            var gestureField = tree.Q<EnumField>("Gesture");

            handField.RegisterValueChangedCallback(evt =>
            {
                if (CurrentTarget != null)
                {
                    CurrentTarget.Hand.Value = (HandData)evt.newValue;
                }
            });

            gestureField.RegisterValueChangedCallback(evt =>
            {
                if (CurrentTarget != null)
                {
                    CurrentTarget.Gesture.Value = (GestureData)evt.newValue;
                }
            });

            Add(tree);
        }

        protected override void OnSubscribe(GestureRule value, CompositeDisposable subscription)
        {
            value.Hand.Subscribe(newHand =>
            {
                var handField = this.Q<EnumField>("Hand");
                handField.SetValueWithoutNotify(newHand);
            }).AddTo(subscription);

            value.Gesture.Subscribe(newGesture =>
            {
                var gestureField = this.Q<EnumField>("Gesture");
                gestureField.SetValueWithoutNotify(newGesture);
            }).AddTo(subscription);
        }
    }
}
