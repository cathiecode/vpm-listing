using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class ReactiveVisibilityVisualElement : ReactiveVisualElement<bool>
    {
        public new class UxmlFactory : UxmlFactory<ReactiveVisibilityVisualElement, UxmlTraits> { }

        public ReactiveVisibilityVisualElement() : base() { }

        public override void OnReactivePropertyChanged(bool value)
        {
            style.display = value ? DisplayStyle.Flex : DisplayStyle.None;
        }
    }
}
