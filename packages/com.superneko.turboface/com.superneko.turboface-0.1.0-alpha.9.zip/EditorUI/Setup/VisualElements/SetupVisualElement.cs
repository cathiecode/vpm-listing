using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UniRx;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class SetupVisualElement : ReactiveVisualElement<Setup?>, IContext<SetupEditorService?>
    {
        public new class UxmlFactory : UxmlFactory<SetupVisualElement, UxmlTraits> { }

        ExpressionSetListVisualElement expressionSetList;
        ExpressionListVisualElement expressionList;
        ExpressionSetVisualElement headerExpressionSet;
        BlinkingSettingsVisualElement blinkingSettings;

        ReactiveProperty<int> selectedExpressionSetIndex = new();

        IDisposable? subscription;

        public SetupEditorService? ContextValue { get; private set; }

        public SetupVisualElement()
        {
            var tree = UIDocumentLoader.Instance.Load("SetupVisualElement").CloneTree();

            expressionSetList = tree.Q<ExpressionSetListVisualElement>("ExpressionSetList");

            expressionSetList.addItem += (index) =>
            {
                ReactiveProperty?.Value?.AddExpressionSet();
            };

            expressionSetList.removeItem += (index) =>
            {
                ReactiveProperty?.Value?.RemoveExpressionSetAt(index);
            };

            expressionSetList.selectionChanged += (expressionSetsAsObj) =>
            {
                var sets = ReactiveProperty?.Value?.ExpressionSets.Value;

                if (expressionSetsAsObj.Count() != 1)
                {
                    Logging.Debug("Multiple or no ExpressionSets selected");
                    return;
                }

                var first = expressionSetsAsObj.FirstOrDefault();

                if (first is not ExpressionSet expressionSet)
                {
                    Logging.Warn("Selected object is not an ExpressionSet");
                    selectedExpressionSetIndex.Value = -1;
                    return;
                }

                selectedExpressionSetIndex.Value = Array.IndexOf(ReactiveProperty?.Value?.ExpressionSets.Value, expressionSet);
            };

            expressionSetList.itemIndexChanged += (from, to) =>
            {
                if (selectedExpressionSetIndex.Value == from)
                {
                    selectedExpressionSetIndex.Value = to;
                }
                else if (selectedExpressionSetIndex.Value == to)
                {
                    selectedExpressionSetIndex.Value = from;
                }
            };

            expressionList = tree.Q<ExpressionListVisualElement>("ExpressionList");

            expressionList.addItem += (index) =>
            {
                var selectedExpressionSet = ReactiveProperty?.Value?.ExpressionSets.Value.ElementAtOrDefault(selectedExpressionSetIndex.Value);
                selectedExpressionSet?.AddExpressionAt(index);
            };

            expressionList.removeItem += (index) =>
            {
                var selectedExpressionSet = ReactiveProperty?.Value?.ExpressionSets.Value.ElementAtOrDefault(selectedExpressionSetIndex.Value);
                selectedExpressionSet?.RemoveExpressionAt(index);
            };

            headerExpressionSet = tree.Q<ExpressionSetVisualElement>("HeaderExpressionSet");
            blinkingSettings = tree.Q<BlinkingSettingsVisualElement>("BlinkingSettings");
            Add(tree);

            style.flexGrow = 1;
            tree.style.flexGrow = 1;
        }

        public override void OnReactivePropertyChanged(Setup? value)
        {
            subscription?.Dispose();

            var newSubscription = new CompositeDisposable();

            expressionSetList.SubscribeTo(value?.ExpressionSets);

            blinkingSettings.SubscribeTo(value?.BlinkingSettings);

            if (value == null)
            {
                headerExpressionSet.SubscribeTo(null);
                expressionList.SubscribeTo(null);
                subscription = newSubscription;
            }
            else
            {
                value.ExpressionSets
                    .CombineLatest(selectedExpressionSetIndex, ValueTuple.Create)
                    .Subscribe((args) =>
                {
                    var (expressionSet, index) = args;

                    var selectedExpressionSet = ReactiveProperty?.Value?.ExpressionSets.Value.ElementAtOrDefault(index);

                    headerExpressionSet.SubscribeTo(selectedExpressionSet);
                    expressionList.SubscribeTo(selectedExpressionSet?.Expressions);
                }).AddTo(newSubscription);
            }

            subscription = newSubscription;
        }

        public void SetSetupEditorService(SetupEditorService service)
        {
            ContextValue = service;
        }
    }
}
