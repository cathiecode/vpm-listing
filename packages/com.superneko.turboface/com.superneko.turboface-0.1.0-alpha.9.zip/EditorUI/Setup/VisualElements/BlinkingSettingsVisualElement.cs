using System.Linq;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class BlinkingSettingsVisualElement : ReactiveVisualElement<BlinkingSettingsData>
    {
        public new class UxmlFactory : UxmlFactory<BlinkingSettingsVisualElement, UxmlTraits> { }

        DropdownField blinkingAnimationModeDropdown;
        ObjectField animationClipForBlinkingField;

        public BlinkingSettingsVisualElement() : base()
        {
            var tree = UIDocumentLoader.Instance.Load("BlinkingSettingsVisualElement").CloneTree();

            blinkingAnimationModeDropdown = tree.Q<DropdownField>("BlinkingAnimationModeDropdown");
            blinkingAnimationModeDropdown.RegisterCallback<ChangeEvent<string>>(evt =>
            {
                var selectedIndex = blinkingAnimationModeDropdown.choices.IndexOf(evt.newValue);

                if (selectedIndex < 0)
                {
                    return;
                }

                ReactiveProperty.Value = new(
                    (BlinkingAnimationMode)selectedIndex,
                    ReactiveProperty.Value.AnimationClipForBlinking
                );
            });

            animationClipForBlinkingField = tree.Q<ObjectField>("AnimationClipForBlinkingObjectField");
            animationClipForBlinkingField.RegisterCallback<ChangeEvent<UnityEngine.Object>>(evt =>
            {
                ReactiveProperty.Value = new(
                    ReactiveProperty.Value.BlinkingAnimationMode,
                    new AssetReference<AnimationClip>(evt.newValue as AnimationClip)
                );
            });

            Add(tree);
        }

        public override void OnReactivePropertyChanged(BlinkingSettingsData value)
        {
            var blinkingAnimationModeText = blinkingAnimationModeDropdown.choices.AsEnumerable().ElementAtOrDefault((int)value.BlinkingAnimationMode);

            blinkingAnimationModeDropdown.SetValueWithoutNotify(blinkingAnimationModeText);
            animationClipForBlinkingField.SetValueWithoutNotify(value.AnimationClipForBlinking?.Instance);

            if (value.BlinkingAnimationMode == BlinkingAnimationMode.UseBuiltInAnimation)
            {
                animationClipForBlinkingField.style.display = DisplayStyle.None;
            }
            else
            {
                animationClipForBlinkingField.style.display = DisplayStyle.Flex;
            }
        }
    }
}
