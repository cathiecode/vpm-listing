using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class ExpressionSetListVisualElement : ReactiveListViewVisualElement<ExpressionSet[]>
    {
        public new class UxmlFactory : UxmlFactory<ExpressionSetListVisualElement, UxmlTraits> { }

        public ExpressionSetListVisualElement() : base()
        {
            makeItem += () => new ExpressionSetSummaryVisualElement();
            
            bindItem += (element, index) =>
            {
                if (ReactiveProperty == null) return;

                var expressionSetElement = (ExpressionSetSummaryVisualElement)element;
                expressionSetElement.SubscribeTo(ReactiveProperty.Value[index]);
            };
        }
    }
}
