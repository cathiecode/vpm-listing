using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class AnimationClipFieldVisualElement : ReactiveVisualElement<IAssetReference<AnimationClip>>
    {
        public new class UxmlFactory : UxmlFactory<AnimationClipFieldVisualElement, UxmlTraits> { }

        ObjectField animationClipField;

        public AnimationClipFieldVisualElement() : base()
        {
            var tree = UIDocumentLoader.Instance.Load("AnimationClipFieldVisualElement").CloneTree();

            animationClipField = tree.Q<ObjectField>("AnimationClip");

            animationClipField.RegisterCallback<ChangeEvent<Object>>(evt =>
            {
                if (ReactiveProperty != null)
                {
                    var newValue = evt.newValue as AnimationClip;

                    if (newValue != null)
                    {
                        ReactiveProperty.Value = new AssetReference<AnimationClip>(newValue);
                    }
                    else
                    {
                        ReactiveProperty.Value = AssetReference<AnimationClip>.Empty;
                    }
                }
            });

            Add(tree);
        }

        public override void OnReactivePropertyChanged(IAssetReference<AnimationClip> value)
        {
            var animationClip = value.Instance;

            if (animationClipField.value != animationClip)
            {
                animationClipField.SetValueWithoutNotify(animationClip);
            }
        }
    }
}