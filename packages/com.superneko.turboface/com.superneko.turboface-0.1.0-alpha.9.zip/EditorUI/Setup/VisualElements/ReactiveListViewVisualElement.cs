using System;
using System.Collections;
using UniRx;
using UnityEditor;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal abstract class ReactiveListViewVisualElement<T> : ListView2 where T : class, IList
    {
        ReactiveProperty<T>? reactiveProperty;
        bool needsSubscribe = false;
        IDisposable? subscription;

        protected ReactiveProperty<T>? ReactiveProperty => reactiveProperty;

        public ReactiveListViewVisualElement() : base()
        {
            RegisterCallback<AttachToPanelEvent>((_) => Subscribe());
            RegisterCallback<DetachFromPanelEvent>((_) => Unsubscribe());

            itemIndexChanged += (from, to) =>
            {
                // HACK: Items are already swapped at this point, by the ListView. We just need to update the index.
                var expressionSets = reactiveProperty?.Value;

                if (expressionSets != null)
                {
                    reactiveProperty?.SetValueAndForceNotify(expressionSets);
                }
            };
        }

        public void SubscribeTo(ReactiveProperty<T>? newProperty)
        {
            reactiveProperty = newProperty;
            UpdateSubscription();
        }

        public virtual void OnReactivePropertyChanged(T? value)
        {
            if (value == null)
            {
                itemsSource = Array.Empty<object>();
                return;
            } else {
                itemsSource = value;
            }

            // NOTE: Sometimes adding/removing items to/from a listview causes StackOverflowException.
            // It seems to be related to invalid event handling inside the ListView, but I'm not sure.
            // Rebuilding the ListView somehow works around this issue, so we do it every time the list changes.
            // 
            // StackOverflowException: The requested operation caused a stack overflow.
            //   at UnityEngine.UIElements.VisualElement.UnityEngine.UIElements.IStylePropertyAnimations.CancelAnimation (UnityEngine.UIElements.StyleSheets.StylePropertyId id) [0x00001] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.InlineStyleAccess.ApplyStyleTranslate (UnityEngine.UIElements.StyleTranslate translate) [0x0008b] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.InlineStyleAccess.SetInlineTranslate (UnityEngine.UIElements.StyleTranslate inlineValue) [0x00092] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.InlineStyleAccess.UnityEngine.UIElements.IStyle.set_translate (UnityEngine.UIElements.StyleTranslate value) [0x00001] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.VisualElement.UnityEngine.UIElements.ITransform.set_position (UnityEngine.Vector3 value) [0x0002d] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.BaseSlider`1[TValueType].UpdateDragElementPosition () [0x001c2] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.BaseSlider`1[TValueType].SetValueWithoutNotify (TValueType newValue) [0x0001c] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.DynamicHeightVirtualizationController`1[T].ApplyScrollViewUpdate (System.Boolean dimensionsOnly) [0x00163] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.DynamicHeightVirtualizationController`1[T].Fill () [0x002ca] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.DynamicHeightVirtualizationController`1[T].OnScrollUpdate () [0x0019b] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.DynamicHeightVirtualizationController`1[T].OnScroll (UnityEngine.Vector2 scrollOffset) [0x0003a] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.BaseVerticalCollectionView.OnScroll (UnityEngine.Vector2 offset) [0x00016] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.BaseVerticalCollectionView.<.ctor>b__158_0 (System.Single v) [0x0000c] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at (wrapper delegate-invoke) System.Action`1[System.Single].invoke_void_T(single)
            //   at UnityEngine.UIElements.Scroller.OnSliderValueChange (UnityEngine.UIElements.ChangeEvent`1[T] evt) [0x00025] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventCallbackFunctor`1[TEventType].Invoke (UnityEngine.UIElements.EventBase evt, UnityEngine.UIElements.PropagationPhase propagationPhase) [0x00046] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventCallbackRegistry.InvokeCallbacks (UnityEngine.UIElements.EventBase evt, UnityEngine.UIElements.PropagationPhase propagationPhase) [0x0008b] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.CallbackEventHandler.HandleEvent (UnityEngine.UIElements.EventBase evt) [0x000cf] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.CallbackEventHandler.HandleEventAtCurrentTargetAndPhase (UnityEngine.UIElements.EventBase evt) [0x00001] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.CallbackEventHandler.UnityEngine.UIElements.IEventHandler.HandleEvent (UnityEngine.UIElements.EventBase evt) [0x00001] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventDispatchUtilities.HandleEventAcrossPropagationPath (UnityEngine.UIElements.EventBase evt) [0x00121] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventDispatchUtilities.PropagateEvent (UnityEngine.UIElements.EventBase evt) [0x00075] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.DefaultDispatchingStrategy.DispatchEvent (UnityEngine.UIElements.EventBase evt, UnityEngine.UIElements.IPanel panel) [0x0002e] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventDispatcher.ApplyDispatchingStrategies (UnityEngine.UIElements.EventBase evt, UnityEngine.UIElements.IPanel panel, System.Boolean imguiEventIsInitiallyUsed) [0x00025] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventDispatcher.ProcessEvent (UnityEngine.UIElements.EventBase evt, UnityEngine.UIElements.IPanel panel) [0x00045] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventDispatcher.ProcessEventQueue () [0x0003d] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventDispatcher.OpenGate () [0x0003b] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventDispatcherGate.Dispose () [0x00001] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventDispatcher.ProcessEvent (UnityEngine.UIElements.EventBase evt, UnityEngine.UIElements.IPanel panel) [0x001a1] in <332857d8803a4878904bcf8f9581ec33>:0 
            //   at UnityEngine.UIElements.EventDispatcher.ProcessEventQueue () [0x0003d] in <332857d8803a4878904bcf8f9581ec33>:0
            //   ...
            Rebuild();
        }

        void Subscribe()
        {
            needsSubscribe = true;
            UpdateSubscription();
        }

        void Unsubscribe()
        {
            needsSubscribe = false;
            UpdateSubscription();
        }

        void UpdateSubscription()
        {
            subscription?.Dispose();

            if (needsSubscribe)
            {
                if (reactiveProperty != null)
                {
                    subscription = reactiveProperty.Subscribe(OnReactivePropertyChanged);
                } else
                {
                    itemsSource = Array.Empty<object>();
                }
            }

            // Hack: Rebuilding the Listview during the AttachToPanelEvent handling causes an Exception below, so we delay it to the next frame.
            // ArgumentException: Cannot unschedule unknown scheduled function UnityEngine.UIElements.VisualElement+SimpleScheduledItem
            // UnityEngine.UIElements.BaseVerticalCollectionView.Rebuild () (at <332857d8803a4878904bcf8f9581ec33>:0)
            // ...
            // com.superneko.TurboFace.Editor.Setup.VisualElements.ReactiveVisualElement`1[T].<.ctor>b__5_0 (UnityEngine.UIElements.AttachToPanelEvent _) (at ./Packages/com.superneko.turboface/Editor/Setup/VisualElements/ReactiveVisualElement.cs:19)
            // ...
            // UnityEngine.GUIUtility.ProcessEvent (System.Int32 instanceID, System.IntPtr nativeEventPtr, System.Boolean& result) (at <74d6aaa3aedf4a279751914e170fef65>:0)
            EditorApplication.delayCall += Rebuild;
        }
    }
}
