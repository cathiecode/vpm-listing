using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class TranslatedButtonVisualElement : Button
    {
        public new class UxmlFactory : UxmlFactory<TranslatedButtonVisualElement, UxmlTraits> { }
        public new class UxmlTraits : Button.UxmlTraits
        {
            private readonly UxmlStringAttributeDescription messageKey = new() { name = "message-key", defaultValue = string.Empty };

            public override void Init(VisualElement ve, IUxmlAttributes bag, CreationContext cc)
            {
                base.Init(ve, bag, cc);
                
                var ate = (TranslatedButtonVisualElement)ve;
                ate.MessageKey = messageKey.GetValueFromBag(bag, cc);
            }
        }

        string messageKey = string.Empty;

        public string MessageKey
        {
            get => messageKey;
            set
            {
                if (messageKey == value) return;
                messageKey = value;
                UpdateTranslation();
            }
        }

        public TranslatedButtonVisualElement()
        {
            RegisterCallback<AttachToPanelEvent>(e => UpdateTranslation());
        }

        void UpdateTranslation()
        {
            if (this.GetContextValue<TranslationActivator>() == null)
            {
                text = messageKey;
                return;
            }

            if (messageKey == string.Empty)
            {
                text = string.Empty;
            }

            text = Localization.GetTranslated(Editor.MessageKey.Get(messageKey));
        }
    }
}
