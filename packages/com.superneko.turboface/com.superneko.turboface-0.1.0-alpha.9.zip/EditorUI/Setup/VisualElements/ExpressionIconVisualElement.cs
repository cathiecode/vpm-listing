using UniRx;
using UnityEngine;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class ExpressionIconVisualElement : ReactiveVisualElement<Texture2D?>
    {
        RefCount<ReactiveProperty<Texture2D?>>? refCount;

        public new class UxmlFactory : UxmlFactory<ExpressionIconVisualElement, UxmlTraits> { }

        public PopperVisualElement? popper;

        public ExpressionIconVisualElement() : base()
        {
            RegisterCallback<AttachToPanelEvent>((ev) =>
            {
                popper?.RemoveFromHierarchy();
                popper = null;

                popper = new PopperVisualElement();
                popper.style.backgroundColor = new StyleColor(new Color(0f, 0f, 0f, 1f));
                popper.SetSize(300, 300);
                popper.style.opacity = 0f;

                ev.destinationPanel.visualTree.Add(popper);
            });

            RegisterCallback<DetachFromPanelEvent>((ev) =>
            {
                popper?.RemoveFromHierarchy();
                popper = null;
            });

            RegisterCallback<MouseEnterEvent>((ev) =>
            {
                if (popper != null)
                {
                    popper.style.opacity = 1f;
                    popper.SetPosition(ev.mousePosition.x, ev.mousePosition.y);
                }
            });

            RegisterCallback<MouseMoveEvent>((ev) =>
            {
                if (popper != null)
                {
                    popper.SetPosition(ev.mousePosition.x, ev.mousePosition.y);
                }
            });

            RegisterCallback<MouseLeaveEvent>((ev) =>
            {
                if (popper != null)
                {
                    popper.SetPosition(-1000, -1000);
                    popper.style.opacity = 0f;
                }
            });
        }

        public void SetIconReference(RefCount<ReactiveProperty<Texture2D?>>? newRefCount)
        {
            refCount?.Dispose();
            refCount = null;

            refCount = newRefCount;

            if (newRefCount != null) {
                SubscribeTo(newRefCount.Value.Value);
            }
        }

        public override void OnReactivePropertyChanged(Texture2D? value)
        {
            if (value != null)
            {
                style.backgroundImage = new StyleBackground(value);
                
                if (popper != null)
                {
                    popper.style.backgroundImage = new StyleBackground(value);
                }
            }
        }
    }
}
