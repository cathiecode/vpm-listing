using System;
using UniRx;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal abstract class InnerReactiveVisualElement<T> : VisualElement
    {
        T? target;
        bool needsSubscribe = false;
        IDisposable? subscription;

        protected T? CurrentTarget => subscription != null ? target : default;

        public InnerReactiveVisualElement() : base()
        {
            RegisterCallback<AttachToPanelEvent>((_) => Subscribe());
            RegisterCallback<DetachFromPanelEvent>((_) => Unsubscribe());
        }

        public void SubscribeTo(T? value)
        {
            target = value;
            UpdateSubscription();
        }

        void Subscribe()
        {
            needsSubscribe = true;
            UpdateSubscription();
        }

        void Unsubscribe()
        {
            needsSubscribe = false;
            UpdateSubscription();
        }

        protected abstract void OnSubscribe(T value, CompositeDisposable subscription);
        protected virtual void OnUnsubscribe() { }

        void UpdateSubscription()
        {
            if (subscription != null)
            {
                OnUnsubscribe();
                subscription.Dispose();
                subscription = null;
            }

            if (needsSubscribe)
            {
                if (target != null)
                {
                    var compositeDisposable = new CompositeDisposable();
                    subscription = compositeDisposable;
                    OnSubscribe(target, compositeDisposable);
                }
            }
        }
    }
}
