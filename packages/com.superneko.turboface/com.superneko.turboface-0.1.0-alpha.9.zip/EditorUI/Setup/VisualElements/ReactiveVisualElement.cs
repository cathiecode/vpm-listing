using System;
using UniRx;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal abstract class ReactiveVisualElement<T> : VisualElement
    {
        ReactiveProperty<T>? reactiveProperty;
        IDisposable? subscription;
        bool needsSubscribe = false;

        protected ReactiveProperty<T>? ReactiveProperty => reactiveProperty;

        public ReactiveVisualElement() : base()
        {
            RegisterCallback<AttachToPanelEvent>((_) => Subscribe());
            RegisterCallback<DetachFromPanelEvent>((_) => Unsubscribe());
        }

        public void SubscribeTo(ReactiveProperty<T>? newProperty)
        {
            reactiveProperty = newProperty;
            UpdateSubscription();
        }

        public abstract void OnReactivePropertyChanged(T value);

        void Subscribe()
        {
            needsSubscribe = true;
            UpdateSubscription();
        }

        void Unsubscribe()
        {
            needsSubscribe = false;
            UpdateSubscription();
        }

        void UpdateSubscription()
        {
            subscription?.Dispose();
            subscription = null;

            if (needsSubscribe)
            {
                if (reactiveProperty != null)
                {
                    subscription = reactiveProperty.Subscribe(OnReactivePropertyChanged);
                }
            }
        }
    }
}
