using System;
using UniRx;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    using Editor.Processor;
    using Editor.Setup;

    internal class ExpressionVisualElement : InnerReactiveVisualElement<Expression>
    {
        public new class UxmlFactory : UxmlFactory<ExpressionVisualElement, UxmlTraits> { }

        AnimationClipFieldVisualElement animationClipField;
        GestureRuleListVisualElement gestureRuleList;
        ExpressionIconVisualElement iconVisualElement;

        ReactiveToggleManipulator shouldCancelMouthMorphingToggleManipulator;
        ReactiveToggleManipulator compatibleWithLipsyncToggleManipulator;
        ReactiveToggleManipulator compatibleWithBlinkingToggleManipulator;
        ReactiveToggleManipulator compatibleWithEyeMovementsToggleManipulator;

        ReactiveVisibilityVisualElement gestureLeftWeightVisibility;
        ExpressionIconVisualElement gestureLeftWeightIcon;
        AnimationClipFieldVisualElement gestureLeftWeightAnimationClipField;
        TranslatedButtonVisualElement gestureLeftWeightRemoveButton;

        ReactiveVisibilityVisualElement gestureRightWeightVisibility;
        ExpressionIconVisualElement gestureRightWeightIcon;
        AnimationClipFieldVisualElement gestureRightWeightAnimationClipField;
        TranslatedButtonVisualElement gestureRightWeightRemoveButton;

        TranslatedButtonVisualElement AddSpecialEffectButton;

        public ExpressionVisualElement() : base()
        {
            var tree = UIDocumentLoader.Instance.Load("ExpressionVisualElement").CloneTree();

            animationClipField = tree.Q<AnimationClipFieldVisualElement>("AnimationClipField");

            gestureRuleList = tree.Q<GestureRuleListVisualElement>("GestureRuleList");

            gestureRuleList.addItem += (index) =>
            {
                CurrentTarget?.AddGestureRuleAt(index);
            };

            gestureRuleList.removeItem += (index) =>
            {
                CurrentTarget?.RemoveGestureRuleAt(index);
            };

            iconVisualElement = tree.Q<ExpressionIconVisualElement>("ExpressionIconVisualElement");

            shouldCancelMouthMorphingToggleManipulator = new ReactiveToggleManipulator();
            tree.Q<Toggle>("ShouldCancelMouthMorphingToggle").AddManipulator(shouldCancelMouthMorphingToggleManipulator);

            compatibleWithLipsyncToggleManipulator = new ReactiveToggleManipulator();
            tree.Q<Toggle>("CompatibleWithLipsyncToggle").AddManipulator(compatibleWithLipsyncToggleManipulator);

            compatibleWithBlinkingToggleManipulator = new ReactiveToggleManipulator();
            tree.Q<Toggle>("CompatibleWithBlinkingToggle").AddManipulator(compatibleWithBlinkingToggleManipulator);

            compatibleWithEyeMovementsToggleManipulator = new ReactiveToggleManipulator();
            tree.Q<Toggle>("CompatibleWithEyeMovementsToggle").AddManipulator(compatibleWithEyeMovementsToggleManipulator);

            gestureLeftWeightVisibility = tree.Q<ReactiveVisibilityVisualElement>("GestureLeftWeightVisibility");
            gestureLeftWeightIcon = tree.Q<ExpressionIconVisualElement>("GestureLeftWeightExpressionIcon");
            gestureLeftWeightAnimationClipField = tree.Q<AnimationClipFieldVisualElement>("GestureLeftWeightAnimationClipField");
            gestureLeftWeightRemoveButton = tree.Q<TranslatedButtonVisualElement>("GestureLeftWeightRemoveButton");
            gestureLeftWeightRemoveButton.clicked += () =>
            {
                if (CurrentTarget == null) return;

                CurrentTarget.GestureLeftWeightAnimationClip.Value = new AssetReference<AnimationClip>(null);
                CurrentTarget.UseGestureLeftWeight.Value = false;
            };

            gestureRightWeightVisibility = tree.Q<ReactiveVisibilityVisualElement>("GestureRightWeightVisibility");
            gestureRightWeightIcon = tree.Q<ExpressionIconVisualElement>("GestureRightWeightExpressionIcon");
            gestureRightWeightAnimationClipField = tree.Q<AnimationClipFieldVisualElement>("GestureRightWeightAnimationClipField");
            gestureRightWeightRemoveButton = tree.Q<TranslatedButtonVisualElement>("GestureRightWeightRemoveButton");
            gestureRightWeightRemoveButton.clicked += () =>
            {
                if (CurrentTarget == null) return;

                CurrentTarget.GestureRightWeightAnimationClip.Value = new AssetReference<AnimationClip>(null);
                CurrentTarget.UseGestureRightWeight.Value = false;
            };

            AddSpecialEffectButton = tree.Q<TranslatedButtonVisualElement>("AddSpecialEffectButton");
            AddSpecialEffectButton.clicked += () =>
            {
                if (CurrentTarget == null) return;

                var menu = new GenericMenu();

                if (!CurrentTarget.UseGestureLeftWeight.Value)
                {
                    menu.AddItem(new GUIContent("Add Gesture Left Weight"), false, () =>
                    {
                        CurrentTarget.UseGestureLeftWeight.Value = true;
                    });
                }

                if (!CurrentTarget.UseGestureRightWeight.Value)
                {
                    menu.AddItem(new GUIContent("Add Gesture Right Weight"), false, () =>
                    {
                        CurrentTarget.UseGestureRightWeight.Value = true;
                    });
                }

                menu.ShowAsContext();
            };

            Add(tree);
        }

        protected override void OnSubscribe(Expression value, CompositeDisposable subscription)
        {
            animationClipField.SubscribeTo(value.AnimationClip);
            gestureRuleList.SubscribeTo(value.GestureRules);

            shouldCancelMouthMorphingToggleManipulator.SubscribeTo(value.ShouldCancelMouthMorphing);
            compatibleWithLipsyncToggleManipulator.SubscribeTo(value.CompatibleWithLipsync);
            compatibleWithBlinkingToggleManipulator.SubscribeTo(value.CompatibleWithBlinking);
            compatibleWithEyeMovementsToggleManipulator.SubscribeTo(value.CompatibleWithEyeMovements);

            gestureLeftWeightVisibility.SubscribeTo(value.UseGestureLeftWeight);
            gestureLeftWeightAnimationClipField.SubscribeTo(value.GestureLeftWeightAnimationClip);

            gestureRightWeightVisibility.SubscribeTo(value.UseGestureRightWeight);
            gestureRightWeightAnimationClipField.SubscribeTo(value.GestureRightWeightAnimationClip);

            var setupEditorService = this.GetContextValueUnwrap<SetupEditorService?>();

            if (setupEditorService == null)
            {
                Logging.Error("SetupEditorService not found in context for ExpressionVisualElement");
            }
            else
            {
                value.AnimationClip.CombineLatest(
                        value.ParentSet.DefaultExpression.AnimationClip,
                        setupEditorService.CurrentAvatarData,
                        ValueTuple.Create
                    )
                    .Subscribe(args =>
                    {
                        var (mayAnimationClip, mayDefaultFaceAnimationClip, mayAvatarData) = args;

                        if (mayAvatarData is not AvatarData avatarData)
                        {
                            iconVisualElement.SetIconReference(null);
                            return;
                        }

                        iconVisualElement.SetIconReference(
                            IconGenerationService.Instance.GetIcon(
                                avatarData,
                                new[] { mayDefaultFaceAnimationClip.Instance, mayAnimationClip.Instance }
                            )
                        );
                    })
                    .AddTo(subscription);

                value.GestureLeftWeightAnimationClip.CombineLatest(
                    value.ParentSet.DefaultExpression.AnimationClip,
                    setupEditorService.CurrentAvatarData,
                    value.UseGestureLeftWeight,
                    ValueTuple.Create
                )
                .Subscribe(args =>
                {
                    var (mayGestureLeftWeightAnimationClip, mayDefaultFaceAnimationClip, mayAvatarData, useGestureLeftWeight) = args;

                    if (!useGestureLeftWeight || mayAvatarData is not AvatarData avatarData)
                    {
                        gestureLeftWeightIcon.SetIconReference(null);
                        return;
                    }

                    gestureLeftWeightIcon.SetIconReference(
                        IconGenerationService.Instance.GetIcon(
                            avatarData,
                            new[] { mayDefaultFaceAnimationClip.Instance, mayGestureLeftWeightAnimationClip.Instance }
                        )
                    );
                });

                value.GestureRightWeightAnimationClip.CombineLatest(
                    value.AnimationClip,
                    value.ParentSet.DefaultExpression.AnimationClip,
                    setupEditorService.CurrentAvatarData,
                    value.UseGestureRightWeight,
                    ValueTuple.Create
                )
                .Subscribe(args =>
                {
                    var (mayGestureRightWeightAnimationClip, mayAnimationClip, mayDefaultFaceAnimationClip, mayAvatarData, useGestureRightWeight) = args;

                    if (!useGestureRightWeight || mayAvatarData is not AvatarData avatarData)
                    {
                        gestureRightWeightIcon.SetIconReference(null);
                        return;
                    }

                    gestureRightWeightIcon.SetIconReference(
                        IconGenerationService.Instance.GetIcon(
                            avatarData,
                            new[] { mayDefaultFaceAnimationClip.Instance, mayAnimationClip.Instance, mayGestureRightWeightAnimationClip.Instance }
                        )
                    );
                });
            }

            subscription.Add(Disposable.Create(() =>
            {
                iconVisualElement.SetIconReference(null);
                gestureLeftWeightIcon.SetIconReference(null);
                gestureRightWeightIcon.SetIconReference(null);
            }));
        }
    }
}
