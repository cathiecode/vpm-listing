using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class ReactiveEnablenessVisualElement : ReactiveVisualElement<bool>
    {
        public new class UxmlFactory : UxmlFactory<ReactiveEnablenessVisualElement, UxmlTraits> { }

        public ReactiveEnablenessVisualElement() : base() { }

        public override void OnReactivePropertyChanged(bool value)
        {
            SetEnabled(value);
        }
    }
}
