namespace com.superneko.TurboFace.Editor.Setup
{
    internal class TranslationActivator
    {
        
    }
}