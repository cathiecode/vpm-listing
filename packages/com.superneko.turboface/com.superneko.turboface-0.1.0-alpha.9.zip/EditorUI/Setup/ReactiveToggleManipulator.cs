using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup
{
    internal class ReactiveToggleManipulator : ReactiveValueManipulator<bool, Toggle>
    {
        public ReactiveToggleManipulator() { }

        protected override void RegisterCallbacksOnTargetImpl()
        {
            CurrentTarget.RegisterCallback<ChangeEvent<bool>>(OnValueChanged);
        }

        protected override void UnregisterCallbacksFromTargetImpl()
        {
            CurrentTarget.UnregisterCallback<ChangeEvent<bool>>(OnValueChanged);
        }

        public override void OnReactivePropertyChanged(bool value)
        {
            CurrentTarget.SetValueWithoutNotify(value);
        }

        void OnValueChanged(ChangeEvent<bool> evt)
        {
            if (ReactiveProperty != null)
            {
                ReactiveProperty.Value = evt.newValue;
            }
        }
    }
}
