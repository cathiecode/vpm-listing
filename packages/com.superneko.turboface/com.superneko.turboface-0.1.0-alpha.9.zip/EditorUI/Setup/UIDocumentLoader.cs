using System;
using UnityEditor;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    public class UIDocumentLoader
    {
        static UIDocumentLoader? instance;

        public static UIDocumentLoader Instance
        {
            get
            {
                instance ??= new UIDocumentLoader();

                return instance;
            }
        }

        public VisualTreeAsset Load(string name)
        {
            var value =  AssetDatabase.LoadAssetAtPath<VisualTreeAsset>($"Packages/com.superneko.turboface/EditorUI/Setup/UIDocuments/{name}.uxml");

            if (value == null)
            {
                throw new Exception($"Failed to load UXML document: {name}");
            }

            return value;
        }
    }
}
