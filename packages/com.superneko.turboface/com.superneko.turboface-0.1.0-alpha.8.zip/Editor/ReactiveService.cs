using System;
using UniRx;

namespace com.superneko.TurboFace
{
    internal abstract class ReactiveService : IDisposable
    {
        IDisposable disposable;

        protected abstract void Initialize(CompositeDisposable d);

        public void Initialize()
        {
            var d = new CompositeDisposable();

            Initialize(d);

            disposable = d;
        }

        protected virtual void OnDisposed() {}

        public void Dispose()
        {
            disposable.Dispose();
            OnDisposed();
        }
    }
}
