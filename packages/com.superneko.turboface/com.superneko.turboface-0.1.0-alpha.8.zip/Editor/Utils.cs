using System.Collections.Generic;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    public static class Utils
    {
        public static bool IsChildOf(Transform? transform, Transform? potentialParent)
        {
            if (transform == null || potentialParent == null)
            {
                return false;
            }

            var current = transform.parent;

            while (current != null)
            {
                if (current == potentialParent)
                {
                    return true;
                }

                current = current.parent;
            }

            return false;
        }

        public static T? LoadAssetByGUID<T>(string guid) where T : Object
        {
            var path = UnityEditor.AssetDatabase.GUIDToAssetPath(guid);

            if (string.IsNullOrEmpty(path))
            {
                return null;
            }

            return UnityEditor.AssetDatabase.LoadAssetAtPath<T>(path);
        }

        public static IEnumerable<string> Ngram(string str, int n)
        {
            if (str.Length < n)
            {
                yield break;
            }

            for (int i = 0; i <= str.Length - n; i++)
            {
                yield return str.Substring(i, n);
            }
        }

        public static char CounterPart(this char c)
        {
            switch (c)
            {
                case '(': return ')';
                case ')': return '(';
                case '[': return ']';
                case ']': return '[';
                case '{': return '}';
                case '}': return '{';
                case '<': return '>';
                case '>': return '<';
                default: return c;
            }
        }

        public static U GetOrCreate<T, U>(this Dictionary<T, U> dict, T key, System.Func<U> defaultValue)
        {
            if (!dict.TryGetValue(key, out var value))
            {
                value = defaultValue();
                dict[key] = value;
            }

            return value;
        }
    }

    class AlwaysFalseEqualityComparer<T> : IEqualityComparer<T>
    {
        public bool Equals(T? x, T? y) => false;
        public int GetHashCode(T obj) => 0;
    }

    class FastStack<T> where T : class
    {
        T?[] array;
        int count;
        T? top;

        public FastStack(int capacity)
        {
            array = new T[capacity];
            count = 0;
            top = null;
        }

        public void Push(T item)
        {
            if (count >= array.Length)
            {
                System.Array.Resize(ref array, array.Length * 2);
            }

            array[count] = item;
            count++;
            UpdateTop();
        }

        public T Pop()
        {
            count--;
            UpdateTop();
            return array[count]!;
        }

        public T Peek()
        {
            return top!;
        }

        public bool TryPeek(out T? value)
        {
            if (count == 0)
            {
                value = null;
                return false;
            }

            value = top!;
            return true;
        }

        public bool IsEmpty => count == 0;

        void UpdateTop()
        {
            if (count == 0)
            {
                top = null;
            }
            else
            {
                top = array[count - 1];
            }
        }
    }
}
