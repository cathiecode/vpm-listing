using System;
using UniRx;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class BlendShapePickerModel
    {
        public class VertexSelectResultValue
        {
            public SkinnedMeshRenderer? pickedVertexRenderer;
            public bool IsVertexPicked = false;
            public Vector3 PickedVertexPosition = Vector3.zero;
            public int pickedVertexIndex = -1;
        }

        public BlendShapePickerModel(AvatarModel avatarModel, PreviewModel previewModel, ExpressionEditorService expressionEditorModel)
        {
            Logging.Trace("BlendShapePickerModel: Constructing BlendShapePickerModel.");

            this.avatarModel = avatarModel;
            this.previewModel = previewModel;
            this.expressionEditorModel = expressionEditorModel;
        }

        public void Initialize()
        {
            Logging.Trace("BlendShapePickerModel: Initialize");

            var currentAvatarFaceSMR = Observable.CombineLatest(avatarModel.FaceSMR, previewModel.PreviewFaceSMR, (originalSMR, previewSMR) => previewSMR ?? originalSMR);

            InfluenceData = currentAvatarFaceSMR.Select(smr =>
            {
                if (smr != null)
                {
                    var data = BlendShapeInfluenceData.FromSkinnedMeshRenderer(smr, 0.001f);
                    return data;
                }
                else
                {
                    return null;
                }
            }).ToReadOnlyReactiveProperty();

            AssemblyReloadEvents.beforeAssemblyReload += () =>
            {
                InfluenceData.Dispose();
            };

            Pickable = InfluenceData.Select(influenceData =>
            {
                return influenceData != null;
            }).ToReadOnlyReactiveProperty();

            AssemblyReloadEvents.beforeAssemblyReload += () =>
            {
                Pickable.Dispose();
            };

            Logging.Trace("BlendShapePickerModel: Creating TempCollider reactive property.");

            // TODO: Observe Transform
            var timer = Observable.Interval(TimeSpan.FromSeconds(5)).Select(_ => (int)(Time.realtimeSinceStartup / 5)).Distinct();

            timer.Subscribe(_ =>
            {
                Logging.Trace("BlendShapePickerModel: TempCollider timer tick.");
            });

            tempCollider = Observable.CombineLatest(timer, currentAvatarFaceSMR, (_, smr) => smr).Select((smr) =>
            {
                Logging.Trace("BlendShapePickerModel: Updating TempCollider.");

                if (smr == null)
                {
                    return null;
                }

                if (tempCollider != null && tempCollider.Value != null)
                {
                    Logging.Trace("Disposing previous temp collider.");
                    UnityEngine.Object.DestroyImmediate(tempCollider.Value.sharedMesh);
                    UnityEngine.Object.DestroyImmediate(tempCollider.Value.gameObject);
                }

                Logging.Trace("Creating temp collider.");

                var bakedMesh = new Mesh();

                smr.BakeMesh(bakedMesh);

                var go = new GameObject("~tempCollider");
                go.hideFlags = HideFlags.HideAndDontSave;
                var tempColliderComponent = go.AddComponent<MeshCollider>();

                tempColliderComponent.sharedMesh = bakedMesh;
                tempColliderComponent.transform.SetPositionAndRotation(
                    smr.transform.position,
                    smr.transform.rotation);

                Logging.Trace("Temp collider created.");

                return tempColliderComponent;
            }).ToReadOnlyReactiveProperty();

            AssemblyReloadEvents.beforeAssemblyReload += () =>
            {
                tempCollider.Dispose();
            };
        }

        PreviewModel previewModel;
        AvatarModel avatarModel;
        ExpressionEditorService expressionEditorModel;

        public ReadOnlyReactiveProperty<bool> Picking => picking.ToReadOnlyReactiveProperty();

        public ReadOnlyReactiveProperty<bool> Pickable { get; private set; } = null!;
        public ReadOnlyReactiveProperty<BlendShapeInfluenceData?> InfluenceData { get; private set; } = null!;

        public ReadOnlyReactiveProperty<VertexSelectResultValue?> PickResult => pickResult.ToReadOnlyReactiveProperty();

        readonly ReactiveProperty<bool> picking = new(false);
        AlwaysNotifyReactiveProperty<VertexSelectResultValue?> pickResult = new(null);
        ReadOnlyReactiveProperty<MeshCollider?> tempCollider = null!;

        public bool StartPicking()
        {
            if (!Pickable.Value)
            {
                return false;
            }

            picking.Value = true;
            return true;
        }

        public bool StopPicking()
        {
            picking.Value = false;
            return false;
        }

        public void Pick(Vector2 mousePosition)
        {
            StopPicking();

            Ray ray = HandleUtility.GUIPointToWorldRay(mousePosition);

            if (InfluenceData.Value == null)
            {
                return;
            }

            if (tempCollider.Value == null)
            {
                return;
            }

            if (tempCollider.Value.Raycast(ray, out RaycastHit hit, 1000f))
            {
                int triIndex = hit.triangleIndex;

                // Get nearest vertex
                var mesh = tempCollider.Value.sharedMesh;
                var triangles = mesh.triangles;
                var vertices = mesh.vertices;
                int v0 = triangles[triIndex * 3 + 0];
                int v1 = triangles[triIndex * 3 + 1];
                int v2 = triangles[triIndex * 3 + 2];
                float d0 = (hit.point - tempCollider.Value.transform.TransformPoint(vertices[v0])).sqrMagnitude;
                float d1 = (hit.point - tempCollider.Value.transform.TransformPoint(vertices[v1])).sqrMagnitude;
                float d2 = (hit.point - tempCollider.Value.transform.TransformPoint(vertices[v2])).sqrMagnitude;
                int nearestVertex = v0;
                if (d1 < d0 && d1 < d2)
                {
                    nearestVertex = v1;
                }
                else if (d2 < d0 && d2 < d1)
                {
                    nearestVertex = v2;
                }

                Logging.Info($"Picked vertex index: {nearestVertex}");

                VertexSelectResultValue result = new VertexSelectResultValue();
                result.pickedVertexRenderer = previewModel.PreviewFaceSMR.Value;
                result.IsVertexPicked = true;
                result.PickedVertexPosition = tempCollider.Value.transform.TransformPoint(vertices[nearestVertex]);
                result.pickedVertexIndex = nearestVertex;
                pickResult.Value = result;
                expressionEditorModel.ChangeSelectedVertex(nearestVertex);
            }
            else
            {
                Logging.Info("No vertex picked.");
                pickResult.Value = null;
                expressionEditorModel.ChangeSelectedVertex(-1);
            }
        }

        public void ClearPickedVertex()
        {
            pickResult.Value = null;
            expressionEditorModel.ChangeSelectedVertex(-1);
        }
    }
}
