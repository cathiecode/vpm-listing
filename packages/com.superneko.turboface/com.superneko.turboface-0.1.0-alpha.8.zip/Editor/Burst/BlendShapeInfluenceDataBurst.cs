using Unity.Burst;
using Unity.Collections;
using Unity.Mathematics;

namespace com.superneko.TurboFace
{
    [BurstCompile]
    public static class BlendShapeInfluenceDataBurst
    {
        [BurstCompile]
        public static void BlendShapeLoop(
            float threshold,
            int blendShapeCount,
            ref NativeArray<byte> influenceData,
            ref NativeArray<float3> blendShapeVerticesNative,
            ref NativeArray<float> avgblendShapeOffset,
            ref NativeArray<float> bleandShapeOffsetSD,
            int i
        )
        {
            float totalMagnitude = 0.0f;
            int vertexCount = blendShapeVerticesNative.Length;

            for (int v = 0; v < vertexCount; v++)
            {
                var influence = math.length(blendShapeVerticesNative[v]);
                var influenced = influence >= threshold ? (byte)1 : (byte)0;
                totalMagnitude += influence;
                Set(ref influenceData, blendShapeCount, v, i, influenced);
            }

            avgblendShapeOffset[i] = totalMagnitude / vertexCount;

            for (int v = 0; v < vertexCount; v++)
            {
                var influence = math.length(blendShapeVerticesNative[v]);
                var diff = influence - avgblendShapeOffset[i];
                bleandShapeOffsetSD[i] += diff * diff;
            }

            bleandShapeOffsetSD[i] = math.sqrt(bleandShapeOffsetSD[i] / vertexCount);
        }

        public static byte Get(ref NativeArray<byte> data, int blendShapeCount, int vertexIndex, int blendShapeIndex)
        {
            var bitIndex = vertexIndex * blendShapeCount + blendShapeIndex;
            var byteIndex = bitIndex >> 3;
            var bitOffset = bitIndex & 7;

            return (byte)((data[byteIndex] & (1 << bitOffset)) >> bitOffset);
        }

        public static void Set(ref NativeArray<byte> data, int blendShapeCount, int vertexIndex, int blendShapeIndex, byte value)
        {
            var bitIndex = vertexIndex * blendShapeCount + blendShapeIndex;
            var byteIndex = bitIndex >> 3;
            var bitOffset = bitIndex & 7;

            data[byteIndex] = (byte)(data[byteIndex] & ~(1 << bitOffset) | (value << bitOffset));
        }
    }
}