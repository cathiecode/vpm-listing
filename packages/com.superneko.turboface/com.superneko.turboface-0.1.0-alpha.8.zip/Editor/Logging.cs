namespace com.superneko.TurboFace
{
    public interface ILogger
    {
        void Trace(string message);
        void Debug(string message);
        void Info(string message);
        void Warn(string message);
        void Error(string message);

        ILogger WithContext(string context);
    }

    public class ConsoleLogger : ILogger
    {
        string context = "[TurboFace]";

        void ILogger.Trace(string message)
        {
            UnityEngine.Debug.Log($"[Trace] {context} {message}");
        }

        void ILogger.Debug(string message)
        {
            UnityEngine.Debug.Log($"[Debug] {context} {message}");
        }

        void ILogger.Info(string message)
        {
            UnityEngine.Debug.Log($"[Info] {context} {message}");
        }

        void ILogger.Warn(string message)
        {
            UnityEngine.Debug.LogWarning($"[Warn] {context} {message}");
        }

        void ILogger.Error(string message)
        {
            UnityEngine.Debug.LogError($"[Error] {context} {message}");
        }

        ILogger ILogger.WithContext(string newContext)
        {
            return new ConsoleLogger { context = $"{context} [{newContext}]" };
        }
    }


    public static class Logging
    {
        public static ILogger Logger { get; set; } = new ConsoleLogger();

        public static void Trace(string message) => Logger.Trace(message);
        public static void Debug(string message) => Logger.Debug(message);
        public static void Info(string message) => Logger.Info(message);
        public static void Warn(string message) => Logger.Warn(message);
        public static void Error(string message) => Logger.Error(message);
        public static ILogger WithContext(string context) => Logger.WithContext(context);
    }
}
