using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class RegisteredData
    {
        float firstFrameValue;
        public float FirstFrameValue => firstFrameValue;

        public RegisteredData(float firstFrameValue)
        {
            this.firstFrameValue = firstFrameValue;
        }
    }

    internal class Entry
    {
        public string Path;
        public string PropertyName;
        public int BlendShapeIndex;
        public float DefaultValue;
        public bool WillMoveCurrentSelectedVertex;
        public float BlendShapeInfluenceScore;
        public bool IsFolder;

        public bool isRegisteredDataCached = false;
        RegisteredData? cachedRegisteredData;
        AnimationClip? baseAnimationClip;
        Expression expression;

        public RegisteredData? RegisteredData
        {
            get
            {
                if (isRegisteredDataCached)
                {
                    return cachedRegisteredData;
                }

                UpdateRegisteredData();

                return cachedRegisteredData;
            }
            private set
            {
                cachedRegisteredData = value;
                isRegisteredDataCached = true;
            }
        }
        public string DisplayName { private set; get; } = "";

        public Entry(
            AnimationClip animationClip,
            string path,
            string propertyName,
            string folderName,
            bool willMoveCurrentSelectedVertex,
            float blendShapeInfluenceScore,
            int blendShapeIndex,
            float defaultValue,
            Expression expression)
        {
            baseAnimationClip = animationClip;
            Path = path;
            PropertyName = propertyName;
            DisplayName = CalcDisplayName(folderName, propertyName);
            WillMoveCurrentSelectedVertex = willMoveCurrentSelectedVertex;
            BlendShapeInfluenceScore = blendShapeInfluenceScore;
            BlendShapeIndex = blendShapeIndex;
            DefaultValue = defaultValue;

            this.expression = expression;
        }

        public void ChangeFirstFrameValue(float newValue)
        {
            var binding = EditorCurveBinding.FloatCurve(Path, typeof(SkinnedMeshRenderer), PropertyName);

            var curve = new AnimationCurve();
            curve.AddKey(0f, newValue);
            AnimationUtility.SetEditorCurve(baseAnimationClip, binding, curve);

            isRegisteredDataCached = false;

            expression.OnEntryChanged(this);
        }

        public void RegisterData()
        {
            var binding = EditorCurveBinding.FloatCurve(Path, typeof(SkinnedMeshRenderer), PropertyName);

            var curve = new AnimationCurve();
            curve.AddKey(0f, DefaultValue);
            AnimationUtility.SetEditorCurve(baseAnimationClip, binding, curve);

            isRegisteredDataCached = false;

            expression.OnEntryChanged(this);
        }

        public void ClearRegisteredData()
        {
            var binding = EditorCurveBinding.FloatCurve(Path, typeof(SkinnedMeshRenderer), PropertyName);

            AnimationUtility.SetEditorCurve(baseAnimationClip, binding, null);

            isRegisteredDataCached = false;

            expression.OnEntryChanged(this);
        }

        public void SetFolderName(string folderName)
        {
            DisplayName = CalcDisplayName(folderName, PropertyName);
        }

        public void UpdateRegisteredData()
        {
            if (baseAnimationClip == null)
            {
                Logging.Trace("Base animation clip is null. Skipping update of registered data.");
                return;
            }

            var binding = EditorCurveBinding.FloatCurve(Path, typeof(SkinnedMeshRenderer), PropertyName);
            var curve = AnimationUtility.GetEditorCurve(baseAnimationClip, binding);

            if (curve != null && curve.keys.Length > 0)
            {
                cachedRegisteredData = new RegisteredData(curve.keys[0].value);
            }
            else
            {
                cachedRegisteredData = null;
            }

            isRegisteredDataCached = true;
        }

        public float RegisteredFirstFrameDataOrZero()
        {
            if (RegisteredData == null)
            {
                return 0f;
            }
            else
            {
                return RegisteredData.FirstFrameValue;
            }
        }

        public void InvalidateCachedData()
        {
            isRegisteredDataCached = false;
        }

        static string CalcDisplayName(string folderName, string propertyName)
        {
            if (string.IsNullOrEmpty(folderName))
            {
                return propertyName["blendShape.".Length..];
            }

            var blendShapeName = propertyName["blendShape.".Length..];

            if (blendShapeName.StartsWith(folderName, StringComparison.OrdinalIgnoreCase))
            {
                if (blendShapeName[folderName.Length..].IndexOfAny(new char[] { '_', ' ', '.' }) is 0)
                {
                    blendShapeName = blendShapeName[(folderName.Length + 1)..];
                }
            }

            return $"[{folderName}] {blendShapeName}";
        }
    }
}
