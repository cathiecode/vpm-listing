using System;

#nullable enable

namespace com.superneko.TurboFace
{
    [Serializable]
    internal class TiedItem<T, U>
    {
        public readonly T Item;
        public readonly U TiedTo;

        public TiedItem(T value, U tiedTo)
        {
            Item = value;
            TiedTo = tiedTo;
        }
    }
}
