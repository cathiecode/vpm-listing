using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class Expression
    {
        readonly Transform baseTransform;
        readonly SkinnedMeshRenderer smr;
        readonly AnimationClip animationClip;
        readonly Entry[] entries;

        public SkinnedMeshRenderer Target => smr;

        public delegate void EntryEventHandler(Entry? changedEntry);
        public event EntryEventHandler? EntryAnimationValueChanged;

        public Expression(Transform baseTransform, SkinnedMeshRenderer smr, AnimationClip animationClip)
        {
            this.smr = smr;
            this.animationClip = animationClip;
            this.baseTransform = baseTransform;

            entries = BuildEntries(baseTransform, smr, animationClip);
        }

        public Entry[] GetEntries()
        {
            return entries;
        }

        Entry[] BuildEntries(Transform baseTransform, SkinnedMeshRenderer smr, AnimationClip animationClip)
        {
            var blendShapeCount = smr.sharedMesh.blendShapeCount;
            var newEntries = new List<Entry>();
            var sharedMesh = smr.sharedMesh;

            for (int i = 0; i < blendShapeCount; i++)
            {
                var blendShapeName = sharedMesh.GetBlendShapeName(i);
                var path = AnimationUtility.CalculateTransformPath(smr.transform, baseTransform);
                var propertyName = $"blendShape.{blendShapeName}";

                var curve = AnimationUtility.GetEditorCurve(animationClip, EditorCurveBinding.FloatCurve(path, typeof(SkinnedMeshRenderer), propertyName));

                var newEntry = new Entry(
                    animationClip,
                    path,
                    propertyName,
                    "",
                    false,
                    0,
                    i,
                    0,
                    this
                );

                newEntries.Add(newEntry);
            }

            return newEntries.ToArray();
        }

        public void OnEntryChanged(Entry changedEntry)
        {
            foreach (var entry in entries)
            {
                if (entry == changedEntry)
                {
                    EntryAnimationValueChanged?.Invoke(changedEntry);
                    return;
                }
            }

            EditorUtility.SetDirty(animationClip);
        }

        public void RecordObject(string message)
        {
            Undo.RecordObject(animationClip, message);
        }

        public void ClearUndoHistory()
        {
            Undo.ClearUndo(animationClip);
        }

        public void InvalidateCachedData()
        {
            foreach (var entry in entries)
            {
                entry.InvalidateCachedData();
            }

            EntryAnimationValueChanged?.Invoke(null);
        }
    }
}
