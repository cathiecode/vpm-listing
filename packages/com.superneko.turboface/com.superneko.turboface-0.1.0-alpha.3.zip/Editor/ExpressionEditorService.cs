using System;
using System.Collections.Generic;
using System.Linq;
using UniRx;
using UnityEditor;
using UnityEngine;
using UnityEngine.Profiling;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class ExpressionEditorService : ReactiveService
    {
        class ExpressionEditorModelState : ScriptableSingleton<ExpressionEditorModelState>
        {
            public ReactiveProperty<AnimationClip?> BaseAnimationClip = new(null);
            public ReactiveProperty<string> BlendShapeFolderSplitter = new("--");
            public ReactiveProperty<float> Threshold = new(0.0001f);
        }

        public enum SortKey
        {
            WillMoveCurrentSelectedVertex,
            FolderIndex,
            IsFolder,
            BlendShapeInfluenceScore,
            BlendShapeIndex,
            RegisteredDataFirstFrameValue,
            IsRegistered,
        }

        public struct SortRule
        {
            public SortKey Key;
            public bool Ascending;
        }

        public ExpressionEditorService(AvatarModel avatarModel)
        {
            this.avatarModel = avatarModel;
        }

        protected override void Initialize(CompositeDisposable d)
        {
            Observable
                .CombineLatest(avatarModel.AvatarRoot, avatarModel.FaceSMR, state.BaseAnimationClip, ValueTuple.Create)
                .Throttle(TimeSpan.FromMilliseconds(250))
                .Subscribe(RebuildEntries).AddTo(d);

            Observable.CombineLatest(avatarModel.FaceSMR, state.Threshold, ValueTuple.Create).Subscribe(UpdateInfluenceData).AddTo(d);

            Observable.CombineLatest(entriesSetAspect, state.BlendShapeFolderSplitter, ValueTuple.Create).Subscribe(UpdateEntryFolders).AddTo(d);

            Observable.CombineLatest(avatarModel.FaceSMR, entriesSetAspect, selectedVertexIndex, influenceData, ValueTuple.Create).Subscribe(UpdateInfluenceSortKey).AddTo(d);

            Observable.CombineLatest(entriesSortKeyAspect, selectedVertexIndex, sortRule, ValueTuple.Create).Subscribe(SortEntries).AddTo(d);

            Observable.CombineLatest(entriesSetAspect, avatarModel.FaceSMR, avatarModel.DefaultBlendShapeWeights, ValueTuple.Create)
                .Subscribe(UpdateDefaultValues)
                .AddTo(d);
        }

        public ReadOnlyReactiveProperty<Entry[]?> EntriesSetAspect => entriesSetAspect.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<Entry[]?> EntriesAnimationAspect => entriesAnimationAspect.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<Entry[]?> EntriesSortKeyAspect => entriesSortKeyAspect.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<Entry[]?> EntriesListStructureAspect => entriesListStructureAspect.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<AnimationClip?> BaseAnimationClip => state.BaseAnimationClip.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<float> Threshold => state.Threshold.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<BlendShapeInfluenceData?> InfluenceData => influenceData.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<string> BlendShapeFolderSplitter => state.BlendShapeFolderSplitter.ToReadOnlyReactiveProperty();
        public string[] FolderNames { get; private set; } = new string[] { "" };
        public ReadOnlyReactiveProperty<List<SortRule>> SortRules => sortRule.ToReadOnlyReactiveProperty();

        ExpressionEditorModelState state => ExpressionEditorModelState.instance;

        AvatarModel avatarModel;

        Entry[]? entries = null;
        ReactiveProperty<Entry[]?> entriesSetAspect = new(null);
        ReactiveProperty<Entry[]?> entriesAnimationAspect = new(null);
        ReactiveProperty<Entry[]?> entriesSortKeyAspect = new(null);
        ReactiveProperty<Entry[]?> entriesListStructureAspect = new(null);

        ReactiveProperty<int> selectedVertexIndex = new(-1);
        ReactiveProperty<BlendShapeInfluenceData?> influenceData = new(null);
        ReactiveProperty<List<SortRule>> sortRule = new(new List<SortRule>()
        {
            new SortRule() { Key = SortKey.WillMoveCurrentSelectedVertex, Ascending = false },
            new SortRule() { Key = SortKey.IsRegistered, Ascending = false },
            new SortRule() { Key = SortKey.FolderIndex, Ascending = true },
            new SortRule() { Key = SortKey.BlendShapeInfluenceScore, Ascending = false },
            new SortRule() { Key = SortKey.BlendShapeIndex, Ascending = true },
        });

        public IEnumerable<Entry> GetEntries()
        {
            if (entries == null)
            {
                yield break;
            }

            foreach (var entry in entries)
            {
                yield return entry;
            }
        }

        public void SetThreshold(float newThreshold)
        {
            if (Mathf.Abs(newThreshold - state.Threshold.Value) > 0.00001f)
            {
                Logging.Trace($"Setting new threshold: {newThreshold}");
                state.Threshold.Value = newThreshold;
            }
        }

        public void ChangeSelectedVertex(int vertexIndex)
        {
            selectedVertexIndex.Value = vertexIndex;

            if (vertexIndex > 0)
            {
                SetSortRule(SortKey.BlendShapeInfluenceScore, false);
                SetSortRule(SortKey.WillMoveCurrentSelectedVertex, false);
            }
        }

        public void SetBaseAnimationClip(AnimationClip? clip)
        {
            if (state.BaseAnimationClip.Value == clip)
            {
                return;
            }

            state.BaseAnimationClip.Value = clip;
        }

        public void OnEntryChanged(Entry changedEntry)
        {
            if (entries == null)
            {
                Logging.Trace("OnEntryChanged called but entries is null. Ignoring.");

                return;
            }

            foreach (var entry in entries)
            {
                if (entry == changedEntry)
                {
                    entry.WritebackToAnimationClip();
                    entriesAnimationAspect.Value = entries;
                    return;
                }
            }

            Logging.Trace("OnEntryChanged called but changed entriy was not found in entries. Ignoring.");
        }

        public void SetSortRule(SortKey key)
        {
            var rules = sortRule.Value;

            var latestRule = rules.Last();

            if (latestRule.Key == key)
            {
                latestRule.Ascending = !latestRule.Ascending;
                rules[^1] = latestRule;
                sortRule.Value = rules;
                return;
            }

            rules.Add(new SortRule() { Key = key, Ascending = false });

            if (rules.Count > 6)
            {
                rules.RemoveAt(0);
            }

            sortRule.Value = rules;
        }

        public void SetSortRule(SortKey key, bool ascending)
        {
            var rules = sortRule.Value;

            var latestRule = rules.Last();

            if (latestRule.Key == key)
            {
                latestRule.Ascending = ascending;
                rules[^1] = latestRule;
                sortRule.Value = rules;
                return;
            }

            rules.RemoveAll(r => r.Key == key);

            rules.Add(new SortRule() { Key = key, Ascending = ascending });

            if (rules.Count > 6)
            {
                rules.RemoveAt(0);
            }

            sortRule.Value = rules;
        }

        public string SetBlendShapeFolderSplitter(string splitter)
        {
            if (state.BlendShapeFolderSplitter.Value == splitter)
            {
                return splitter;
            }

            state.BlendShapeFolderSplitter.Value = splitter;

            return splitter;
        }

        void RebuildEntries((Transform? baseTransform, SkinnedMeshRenderer? faceSMR, AnimationClip? baseAnimationClip) args)
        {
            var (baseTransform, faceSMR, baseAnimationClip) = args;

            Logging.Trace("ExpressionEditorModel: Rebuilding entries.");

            if (entries != null)
            {
                Logging.Trace("ExpressionEditorModel: Entries already exist. Cleaning up.");

                foreach (var entry in entries)
                {
                    Profiler.BeginSample("ExpressionEditorModel: Cleaning up entry");
                    Undo.ClearUndo(entry);
                    ScriptableObject.DestroyImmediate(entry);
                    Profiler.EndSample();
                }
            }

            if (baseTransform == null || faceSMR == null || baseAnimationClip == null)
            {
                Logging.Trace("ExpressionEditorModel: One of baseTransform, faceSMR, or baseAnimationClip is null. Clearing entries.");
                entries = null;
                entriesAnimationAspect.Value = null;
                entriesListStructureAspect.Value = null;
                entriesSetAspect.Value = null;
                return;
            }

            Profiler.BeginSample("ExpressionEditorModel: Rebuilding entries");

            var blendShapeCount = faceSMR.sharedMesh.blendShapeCount;
            var newEntries = new List<Entry>();
            var sharedMesh = faceSMR.sharedMesh;

            Dictionary<string, int> folderNameIndicatorCandidateCount = new Dictionary<string, int>();

            for (int i = 0; i < blendShapeCount; i++)
            {
                var blendShapeName = sharedMesh.GetBlendShapeName(i);
                var path = AnimationUtility.CalculateTransformPath(faceSMR.transform, baseTransform);
                var propertyName = $"blendShape.{blendShapeName}";

                // Is folder-like?
                if (blendShapeName.Length >= 3 && blendShapeName[0] == blendShapeName[1] && blendShapeName[1] == blendShapeName[2])
                {
                    var repeatCount = blendShapeName.TakeWhile(c => c == blendShapeName[0]).Count();
                    var count = folderNameIndicatorCandidateCount.GetOrCreate(blendShapeName.Substring(0, repeatCount), () => 0);
                    folderNameIndicatorCandidateCount[blendShapeName[..repeatCount]] = count + 1;
                }

                var curve = AnimationUtility.GetEditorCurve(baseAnimationClip, EditorCurveBinding.FloatCurve(path, typeof(SkinnedMeshRenderer), propertyName));

                var newEntry = ScriptableObject.CreateInstance<Entry>();

                newEntry.SetValues(
                    baseAnimationClip,
                    path,
                    propertyName,
                    "",
                    false,
                    0,
                    i,
                    0,
                    curve != null && curve.keys.Length > 0 ? new RegisteredData(curve.keys[0].value) : null,
                    () => OnEntryChanged(newEntry)
                );

                newEntries.Add(newEntry);
            }

            state.BlendShapeFolderSplitter.Value = folderNameIndicatorCandidateCount
                .Where(kv => kv.Value >= 2)
                .OrderByDescending(kv => kv.Value)
                .Select(kv => kv.Key)
                .FirstOrDefault() ?? "";

            entries = newEntries.ToArray();
            entriesAnimationAspect.Value = entries;
            entriesListStructureAspect.Value = entries;
            entriesSetAspect.Value = entries;
            Profiler.EndSample();
        }

        void UpdateInfluenceData((SkinnedMeshRenderer? faceSMR, float threshold) args)
        {
            var (faceSMR, threshold) = args;

            Logging.Trace("ExpressionEditorModel: Updating BlendShapeInfluenceData.");

            if (faceSMR == null)
            {
                Logging.Trace("ExpressionEditorModel: faceSMR is null. Clearing influence data.");
                influenceData.Value = null;
                return;
            }

            influenceData.Value = BlendShapeInfluenceData.FromSkinnedMeshRenderer(faceSMR, threshold);
        }

        void UpdateEntryFolders((Entry[]? entries, string blendShapeFolderSplitter) args)
        {
            var (entries, blendShapeFolderSplitter) = args;

            Logging.Trace("ExpressionEditorModel: Scanning folders.");

            if (entries == null)
            {
                return;
            }

            List<string> folderNames = new List<string>();

            if (blendShapeFolderSplitter == "")
            {
                this.FolderNames = new string[] { "" };
                state.BlendShapeFolderSplitter.Value = "";

                foreach (var entry in entries)
                {
                    entry.SetFolderName("");
                }

                return;
            }

            Profiler.BeginSample("ExpressionEditorModel: Scanning folders");

            folderNames.Add("");
            int folderIndex = 0;

            for (int i = 0; i < entries.Length; i++)
            {
                var entry = entries[i];
                var isFolder = entry.PropertyName.Substring("blendShape.".Length).StartsWith(blendShapeFolderSplitter);

                if (isFolder)
                {
                    var folderName = entry.PropertyName.Substring("blendShape.".Length + blendShapeFolderSplitter.Length);

                    if (folderName.StartsWith(blendShapeFolderSplitter))
                    {
                        folderName = folderName.Substring(blendShapeFolderSplitter.Length);
                    }

                    if (folderName.EndsWith(new string(blendShapeFolderSplitter.Select(c => c.CounterPart()).Reverse().ToArray())))
                    {
                        folderName = folderName[..^blendShapeFolderSplitter.Length];
                    }

                    folderNames.Add(folderName);
                    folderIndex++;
                }

                entry.SetFolderName(folderNames[folderIndex]);
                entry.IsFolder = isFolder;
            }

            FolderNames = folderNames.ToArray();

            entriesSortKeyAspect.Value = entries;
            Profiler.EndSample();
        }

        void UpdateDefaultValues((Entry[]? entries, SkinnedMeshRenderer? faceSMR, float[]? defaultBlendShapeWeights) args)
        {
            var (entries, faceSMR, defaultBlendShapeWeights) = args;

            Logging.Trace("ExpressionEditorModel: Updating default values.");

            if (faceSMR == null || entries == null || defaultBlendShapeWeights == null)
            {
                Logging.Trace("ExpressionEditorModel: One of faceSMR, entries, or defaultBlendShapeWeights is null. Skipping.");
                return;
            }

            if (defaultBlendShapeWeights.Length != faceSMR.sharedMesh.blendShapeCount)
            {
                Logging.Trace("ExpressionEditorModel: defaultBlendShapeWeights length does not match blend shape count. Skipping.");
                return;
            }

            Profiler.BeginSample("ExpressionEditorModel: Updating default values");

            foreach (var entry in entries)
            {
                entry.DefaultValue = defaultBlendShapeWeights[entry.BlendShapeIndex];
            }

            entriesSortKeyAspect.Value = entries;
            Profiler.EndSample();
        }

        void UpdateInfluenceSortKey((SkinnedMeshRenderer? faceSMR, Entry[]? entries, int selectedVertexIndex, BlendShapeInfluenceData? influenceData) args)
        {
            var (faceSMR, entries, selectedVertexIndex, influenceData) = args;

            Logging.Trace("ExpressionEditorModel: Updating blendshape influence sort key");

            if (entries == null)
            {
                Logging.Trace("ExpressionEditorModel: entries is null. Skipping.");
                return;
            }

            if (faceSMR == null)
            {
                Logging.Trace("ExpressionEditorModel: faceSMR is null. Skipping.");
                return;
            }

            if (selectedVertexIndex < 0)
            {
                Logging.Trace("ExpressionEditorModel: selectedVertexIndex is less than 0. Removing influence sort key.");
                foreach (var entry in entries)
                {
                    entry.WillMoveCurrentSelectedVertex = false;
                    entry.BlendShapeInfluenceScore = 0;
                }
                return;
            }

            if (influenceData == null)
            {
                Logging.Trace("ExpressionEditorModel: influenceData is null. Removing influence sort key.");
                foreach (var entry in entries)
                {
                    entry.WillMoveCurrentSelectedVertex = false;
                    entry.BlendShapeInfluenceScore = 0;
                }
                return;
            }

            Profiler.BeginSample("ExpressionEditorModel: Updating blendshape influence sort key");

            var influencingBlendShapeIndicesForVertex = influenceData.GetInfluencingBlendShapesForVertex(selectedVertexIndex);
            var sharedMesh = faceSMR.sharedMesh;

            foreach (var entry in entries)
            {
                entry.WillMoveCurrentSelectedVertex = false;
                entry.BlendShapeInfluenceScore = 0;
            }

            foreach (var blendShapeIndex in influencingBlendShapeIndicesForVertex)
            {
                var blendShapeName = sharedMesh.GetBlendShapeName(blendShapeIndex);
                var path = entries[0].Path; // Assume all entries have the same path
                var propertyName = $"blendShape.{blendShapeName}";

                for (int i = 0; i < entries.Length; i++)
                {
                    var entry = entries[i];

                    if (entry.Path == path && entry.PropertyName == propertyName)
                    {
                        entries[i].WillMoveCurrentSelectedVertex = true;
                        break;
                    }
                }
            }

            var scores = influenceData.GetBlendShapeInfluenceScores(selectedVertexIndex);

            if (scores != null)
            {
                for (var i = 0; i < entries.Length; i++)
                {
                    var entry = entries[i];
                    var blendShapeIndex = entry.BlendShapeIndex;
                    entries[i].BlendShapeInfluenceScore = scores[blendShapeIndex];
                }
            }
            else
            {
                Logging.Trace("ExpressionEditorModel: scores is null. Skipping.");
            }

            entriesSortKeyAspect.Value = entries;
            Profiler.EndSample();
        }

        void SortEntries((Entry[]? entries, int selectedVertexIndex, List<SortRule> sortRule) args)
        {
            var (entries, selectedVertexIndex, sortRule) = args;

            Logging.Trace("ExpressionEditorModel: sorting entries.");

            if (entries == null)
            {
                return;
            }

            if (sortRule == null)
            {
                return;
            }

            foreach (var rule in sortRule)
            {
                Logging.Trace($"  Sort Rule: {rule.Key}, Ascending: {rule.Ascending}");
            }

            var sortRuleArray = sortRule.ToArray().Reverse();

            Profiler.BeginSample("ExpressionEditorModel: sorting entries");

            Array.Sort(entries, (a, b) =>
            {
                foreach (var rule in sortRuleArray)
                {
                    int comparison = 0;

                    switch (rule.Key)
                    {
                        case SortKey.WillMoveCurrentSelectedVertex:
                            comparison = a.WillMoveCurrentSelectedVertex.CompareTo(b.WillMoveCurrentSelectedVertex);
                            break;
                        case SortKey.IsFolder:
                            comparison = a.IsFolder.CompareTo(b.IsFolder);
                            break;
                        case SortKey.BlendShapeInfluenceScore:
                            comparison = a.BlendShapeInfluenceScore.CompareTo(b.BlendShapeInfluenceScore);
                            break;
                        case SortKey.BlendShapeIndex:
                            comparison = a.BlendShapeIndex.CompareTo(b.BlendShapeIndex);
                            break;
                        case SortKey.RegisteredDataFirstFrameValue:
                            comparison = a.RegisteredFirstFrameDataOrZero().CompareTo(b.RegisteredFirstFrameDataOrZero());
                            break;
                        case SortKey.IsRegistered:
                            comparison = (a.RegisteredData != null).CompareTo(b.RegisteredData != null);
                            break;
                    }

                    if (comparison != 0)
                    {
                        return rule.Ascending ? comparison : -comparison;
                    }
                }

                return 0;
            });

            entriesListStructureAspect.Value = entries;
            Profiler.EndSample();
        }
    }
}
