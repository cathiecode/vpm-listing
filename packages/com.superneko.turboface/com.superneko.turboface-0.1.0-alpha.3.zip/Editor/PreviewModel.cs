using System.Linq;
using UniRx;
using UnityEditor;
using UnityEditor.Rendering;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class PreviewModel : ReactiveService
    {
        internal class PreviewModelState : ScriptableSingleton<PreviewModelState>
        {
            public ReactiveProperty<bool> IsPreviewing = new(false);
        }

        internal class FBCPreviewSceneStage : PreviewSceneStage
        {
            protected override GUIContent CreateHeaderContent()
            {
                return new GUIContent("TurboFace Preview");
            }

            protected override void OnCloseStage()
            {
                PreviewModelState.instance.IsPreviewing.Value = false;
                base.OnCloseStage();
            }
        }

        public ReactiveProperty<Transform?> PreviewAvatarRoot = new(null);
        public ReactiveProperty<SkinnedMeshRenderer?> PreviewFaceSMR = new(null);
        public ReactiveProperty<SkinnedMeshRenderer?> QuickPreviewFaceSMR = new(null);
        public ReadOnlyReactiveProperty<bool> IsPreviewing => PreviewModelState.instance.IsPreviewing.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<(int, float)?> QuickPreviewingBlendShape => quickPreviewingBlendShape.ToReadOnlyReactiveProperty();

        AvatarModel avatarModel;
        ExpressionEditorService expressionEditorModel;
        readonly ReactiveProperty<(int, float)?> quickPreviewingBlendShape = new(null);

        System.IDisposable? disposable;

        public PreviewModel(
            AvatarModel avatarModel,
            ExpressionEditorService expressionEditorModel
        )
        {
            this.avatarModel = avatarModel;
            this.expressionEditorModel = expressionEditorModel;
        }

        protected override void Initialize(CompositeDisposable d)
        {
            Logging.Trace("PreviewModel: Initialize");

            PreviewModelState.instance.IsPreviewing.Subscribe(IsPreviewing =>
            {
                IsPreviewingChanged(IsPreviewing);
            }).AddTo(d);

            Observable.CombineLatest(PreviewAvatarRoot, PreviewFaceSMR, expressionEditorModel.EntriesAnimationAspect, avatarModel.DefaultBlendShapeWeights, quickPreviewingBlendShape, (a, b, c, d, e) => (a, b, c, d, e)).Subscribe(e =>
            {
                Logging.Trace("PreviewModel: Applying preview data.");

                var (previewAvatarRoot, previewFaceSMR, entryData, defaultBlendShapeWeights, quickPreviewingBlendShape) = e;

                if (previewFaceSMR == null || previewFaceSMR == null || entryData == null || defaultBlendShapeWeights == null)
                {
                    Logging.Trace("PreviewModel: One of previewFaceSMR, entryData, or defaultBlendShapeWeights is null. Skipping.");
                    return;
                }

                var previewEntries = entryData;

                foreach (var entry in previewEntries)
                {
                    var registeredData = entry.RegisteredData;

                    if (registeredData == null)
                    {
                        if (quickPreviewingBlendShape?.Item1 == entry.BlendShapeIndex)
                        {
                            var (index, weight) = quickPreviewingBlendShape.Value;
                            previewFaceSMR.SetBlendShapeWeight(index, weight);
                        }
                        else
                        {
                            previewFaceSMR.SetBlendShapeWeight(entry.BlendShapeIndex, defaultBlendShapeWeights[entry.BlendShapeIndex]);
                        }

                        continue;
                    }

                    previewFaceSMR.SetBlendShapeWeight(entry.BlendShapeIndex, registeredData.FirstFrameValue);
                }
            }).AddTo(d);

            Observable.CombineLatest(
                expressionEditorModel.EntriesAnimationAspect,
                avatarModel.DefaultBlendShapeWeights,
                QuickPreviewFaceSMR,
                quickPreviewingBlendShape,
                expressionEditorModel.InfluenceData, (a, b, c, d, e) => (a, b, c, d, e)).Subscribe(props =>
            {
                var (entryData, defaultBlendShapeWeights, previewFaceSMR, quickPreviewingBlendShape, influenceData) = props;

                if (previewFaceSMR == null || entryData == null || defaultBlendShapeWeights == null || influenceData == null)
                {
                    return;
                }

                var previewEntries = entryData;

                foreach (var entry in previewEntries)
                {
                    var registeredData = entry.RegisteredData;

                    if (registeredData == null)
                    {
                        if (quickPreviewingBlendShape != null && quickPreviewingBlendShape?.Item1 == entry.BlendShapeIndex)
                        {
                            var index = quickPreviewingBlendShape.Value.Item1;
                            var weight = quickPreviewingBlendShape.Value.Item2;

                            previewFaceSMR.SetBlendShapeWeight(index, weight);
                        }
                        else
                        {
                            previewFaceSMR.SetBlendShapeWeight(entry.BlendShapeIndex, defaultBlendShapeWeights[entry.BlendShapeIndex]);
                        }

                        continue;
                    }

                    previewFaceSMR.SetBlendShapeWeight(entry.BlendShapeIndex, registeredData.FirstFrameValue);
                }

                if (quickPreviewingBlendShape != null)
                {
                    var color = influenceData.GetInfluenceAsColorsForBlendShape(quickPreviewingBlendShape.Value.Item1);
                    previewFaceSMR.sharedMesh.SetColors(color);
                } else
                {
                    var colors = new Color[previewFaceSMR.sharedMesh.vertexCount];
                    previewFaceSMR.sharedMesh.SetColors(colors);
                }
            }).AddTo(d);
        }

        public void StartPreview()
        {
            PreviewModelState.instance.IsPreviewing.Value = true;
        }

        public void StopPreview()
        {
            PreviewModelState.instance.IsPreviewing.Value = false;
        }

        public void SetQuickPreviewBlendShape(int index, float weight)
        {
            if (index < 0)
            {
                quickPreviewingBlendShape.Value = null;
            }
            else
            {
                quickPreviewingBlendShape.Value = (index, weight);
            }
        }

        void IsPreviewingChanged(bool isPreviewing)
        {
            Logging.Trace($"PreviewModel: IsPreviewingChanged: {isPreviewing}");

            if (isPreviewing)
            {
                StartPreviewImpl();
            }
            else
            {
                StopPreviewImpl();
            }
        }

        void StartPreviewImpl()
        {
            if (StageUtility.GetCurrentStage() is FBCPreviewSceneStage)
            {
                return;
            }

            if (avatarModel.FaceSMR.Value == null)
            {
                Logging.Warn("Cannot start preview: FaceSMR is null. Aborting.");
                PreviewModelState.instance.IsPreviewing.Value = false;
                return;
            }

            Logging.Trace("Preparing preview stage...");

            var mainScene = SceneManager.GetActiveScene();
            var sceneView = SceneView.lastActiveSceneView; // NOTE: Sceneview will overwrite when changing stage
            var sceneStage = ScriptableObject.CreateInstance<FBCPreviewSceneStage>();

            var pivot = sceneView != null ? sceneView.pivot : Vector3.zero;
            var rotation = sceneView != null ? sceneView.rotation : Quaternion.identity;
            var size = sceneView != null ? sceneView.size : 1f;

            Logging.Trace("Go to preview stage.");
            StageUtility.GoToStage(sceneStage, true);

            var avatar = avatarModel.AvatarRoot.Value;

            if (avatar != null)
            {
                var cloned = Object.Instantiate(avatar.gameObject);

                foreach (var t in cloned.GetComponentsInChildren<Transform>(true))
                {
                    t.gameObject.hideFlags = HideFlags.NotEditable | HideFlags.DontSave;
                }

                foreach (var c in cloned.GetComponentsInChildren<Component>(true))
                {
                    switch (c)
                    {
                        case Transform:
                        case SkinnedMeshRenderer:
                        case MeshFilter:
                        case MeshRenderer:
                        case ParticleSystem:
                        case TrailRenderer:
                            break;
                        default:
                            Object.DestroyImmediate(c);
                            break;
                    }
                }

                cloned.transform.SetPositionAndRotation(avatar.transform.position, avatar.transform.rotation);
                cloned.transform.localScale = avatar.transform.lossyScale;

                SceneManager.MoveGameObjectToScene(cloned, sceneStage.scene);

                PreviewAvatarRoot.Value = cloned.transform;

                var facePath = AnimationUtility.CalculateTransformPath(avatarModel.FaceSMR.Value.transform, avatar);

                var previewFaceObject = cloned.transform.Find(facePath)?.gameObject;
                var previewFaceSMR = previewFaceObject?.GetComponent<SkinnedMeshRenderer>();

                this.PreviewFaceSMR.Value = previewFaceSMR;

                if (previewFaceObject != null)
                {
                    var quickPreviewFaceObject = Object.Instantiate(previewFaceObject);
                    quickPreviewFaceObject.name = "QuickPreviewFaceSMR";
                    quickPreviewFaceObject.hideFlags = HideFlags.DontSave;
                    SceneManager.MoveGameObjectToScene(quickPreviewFaceObject, sceneStage.scene);
                    QuickPreviewFaceSMR.Value = quickPreviewFaceObject.GetComponent<SkinnedMeshRenderer>();
                    QuickPreviewFaceSMR.Value.sharedMesh = Object.Instantiate(QuickPreviewFaceSMR.Value.sharedMesh);

                    var material = Utils.LoadAssetByGUID<Material>("a249faf3d39a9ef4998fedd7ece4e54a");

                    if (material != null)
                    {
                        var materialCount = QuickPreviewFaceSMR.Value.sharedMesh.subMeshCount;

                        var materials = new Material[materialCount];
                        for (int i = 0; i < materialCount; i++)
                        {
                            materials[i] = material;
                        }

                        QuickPreviewFaceSMR.Value.sharedMaterials = materials;
                    }
                }
            }

            // Lighting
            var light = new GameObject("Directional Light", typeof(Light))
            {
                hideFlags = HideFlags.DontSave
            }.GetComponent<Light>();

            light.type = LightType.Directional;
            light.transform.position = Vector3.up * 3f + Vector3.back * 3f;
            light.transform.rotation = Quaternion.Euler(50f, 120f, 0f);
            light.intensity = 1f;
            light.color = Color.white;

            SceneManager.MoveGameObjectToScene(light.gameObject, sceneStage.scene);

            EditorApplication.delayCall += () =>
            {
                var sv = SceneView.lastActiveSceneView;

                if (sv != null)
                {
                    sv.pivot = pivot;
                    sv.rotation = rotation;
                    sv.size = size;
                    sv.Repaint();
                }
            };
        }

        void StopPreviewImpl()
        {
            Object.DestroyImmediate(PreviewAvatarRoot.Value?.gameObject);
            PreviewAvatarRoot.Value = null;
            PreviewFaceSMR.Value = null;

            if (StageUtility.GetCurrentStage() is FBCPreviewSceneStage fbcStage)
            {
                Logging.Trace("Exiting preview stage...");
                StageUtility.GoBackToPreviousStage();
            }
        }
    }
}
