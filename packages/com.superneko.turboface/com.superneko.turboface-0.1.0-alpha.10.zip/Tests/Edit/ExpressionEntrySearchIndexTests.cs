using System.Linq;
using com.superneko.TurboFace.Editor.Edit;
using NUnit.Framework;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Tests.Edit
{
    internal class ExpressionEntrySearchIndexTests
    {
        [Test]
        public void SearchByQuery_SplitsByHalfAndFullWidthSpace()
        {
            var entries = new[]
            {
                CreateEntry(0, "Smile_Open"),
                CreateEntry(1, "Smile_Close"),
                CreateEntry(2, "Angry")
            };

            var index = new EntryIndex(entries);
            var result = index.SearchByQuery(new EntryQuery("Smile\u3000Open"));

            Assert.That(result.Select(entry => entry.BlendShapeIndex), Is.EqualTo(new[] { 0 }));
        }

        [Test]
        public void FindBySimilarDisplayName_ReturnsNearEntriesWithoutSelf()
        {
            var smile = CreateEntry(0, "Smile");
            var smole = CreateEntry(1, "Smole");
            var angry = CreateEntry(2, "Angry");

            var index = new EntryIndex(new[] { smile, smole, angry });
            var result = index.FindBySimilarDisplayName(smile);

            Assert.That(result.Any(entry => entry.BlendShapeIndex == smile.BlendShapeIndex), Is.False);
            Assert.That(result.Any(entry => entry.BlendShapeIndex == smole.BlendShapeIndex), Is.True);
        }

        static ExpressionEntry CreateEntry(int blendShapeIndex, string blendShapeName)
        {
            return new ExpressionEntry(
                new AnimationClip(),
                "Face",
                $"blendShape.{blendShapeName}",
                "",
                false,
                0f,
                blendShapeIndex,
                0f,
                null!);
        }
    }
}
