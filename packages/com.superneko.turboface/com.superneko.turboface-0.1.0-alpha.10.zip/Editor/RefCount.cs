using System;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    internal interface WeakRefCount<T>
    {
        T? Value { get; }

        RefCount<T>? TryToRefCount();
    }

    internal class RefCount<T> : IDisposable
    {
        class SharedInner
        {
            public bool DisposedGlobal { get; private set; }
            public T Value { get; private set; }
            public int Count { get; private set; }
            public Action<T>? OnZero { get; private set; }

            public SharedInner(T value, Action<T>? onZero = null)
            {
                Value = value;
                Count = 1;
                OnZero = onZero;
            }

            public void Increment()
            {
                Count++;
            }

            public void Decrement()
            {
                Count--;
                
                if (Count == 0)
                {
                    OnZero?.Invoke(Value);
                    DisposedGlobal = true;
                }
            }
        }

        class Weak : WeakRefCount<T>
        {
            SharedInner sharedInner;

            public T? Value
            {
                get
                {
                    if (sharedInner.DisposedGlobal)
                    {
                        return default;
                    } else
                    {
                        return sharedInner.Value;
                    }
                }
            }

            public Weak(SharedInner inner)
            {
                sharedInner = inner;
            }

            public RefCount<T>? TryToRefCount()
            {
                if (!sharedInner.DisposedGlobal)
                {
                    sharedInner.Increment();
                    return new RefCount<T>(sharedInner);
                } else
                {
                    return null;
                }
            }
        }

        readonly SharedInner sharedInner;

        public bool DisposedSelf { get; private set; }

        public T Value
        {
            get
            {
                if (DisposedSelf)
                {
                    throw new ObjectDisposedException(nameof(RefCount<T>));
                }

                return sharedInner.Value;
            }
        }

        public int Count => sharedInner.Count;

        public RefCount(T value, Action<T>? onZero = null)
        {
            sharedInner = new SharedInner(value, onZero);
            DisposedSelf = false;
        }

        RefCount(SharedInner inner)
        {
            sharedInner = inner;
            DisposedSelf = false;
        }

        public void Dispose()
        {
            if (DisposedSelf)
            {
                throw new ObjectDisposedException(nameof(RefCount<T>));
            }

            sharedInner.Decrement();

            DisposedSelf = true;
        }

        public RefCount<T> Clone()
        {
            if (DisposedSelf)
            {
                throw new ObjectDisposedException(nameof(RefCount<T>));
            }

            sharedInner.Increment();

            return new RefCount<T>(sharedInner);
        }

        public WeakRefCount<T> ToWeak()
        {
            if (DisposedSelf)
            {
                throw new ObjectDisposedException(nameof(RefCount<T>));
            }

            return new Weak(sharedInner);
        }
    }
}
