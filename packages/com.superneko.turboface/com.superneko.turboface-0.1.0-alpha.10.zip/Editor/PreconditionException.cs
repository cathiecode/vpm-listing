using System;

namespace com.superneko.TurboFace
{
    using Editor;

    internal class PreconditionException : TurboFaceException
    {
        public PreconditionException(MessageKey messageKey) : base(messageKey)
        {
            
        }
    }
}
