using System;
using UniRx;

#nullable enable

namespace com.superneko.TurboFace.Editor
{
    internal class AssetChangeStream : ReactiveService
    {
        internal class Change
        {
            public UnityEngine.Object target;

            public Change(UnityEngine.Object target)
            {
                this.target = target;
            }
        }

        static AssetChangeStream? instance;

        public static AssetChangeStream Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new AssetChangeStream();
                    instance.Initialize();
                }

                return instance;
            }
        }

        Subject<Change> changeStream;

        public IObservable<Change> ChangeStream => changeStream;

        AssetChangeStream()
        {
            changeStream = new Subject<Change>();
        }

        protected override void Initialize(CompositeDisposable d)
        {
            changeStream.AddTo(d);
        }

        public void RegisterChange(UnityEngine.Object changedObject)
        {
            changeStream.OnNext(new Change(changedObject));
        }
    }
}
