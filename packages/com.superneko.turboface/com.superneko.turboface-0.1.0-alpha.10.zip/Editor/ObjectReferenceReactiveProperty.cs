using UniRx;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor
{
    internal class ObjectReferenceReactiveProperty<T> : ReactiveProperty<T?> where T: UnityEngine.Object
    {
        ObjectReferenceReactiveProperty() : base()
        {
            
        }

        public ObjectReferenceReactiveProperty(T? initialValue) : base(initialValue)
        {
            Undo.postprocessModifications += OnPostprocessModifications;
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            Undo.postprocessModifications -= OnPostprocessModifications;
        }

        UndoPropertyModification[] OnPostprocessModifications(UndoPropertyModification[] modifications)
        {
            foreach (var modification in modifications)
            {
                if (modification.currentValue.target is T target)
                {
                    try
                    {
                        Value = target;
                    } catch (System.Exception ex)
                    {
                        Debug.LogException(ex);
                    }
                }
            }

            return modifications;
        }
    }
}
