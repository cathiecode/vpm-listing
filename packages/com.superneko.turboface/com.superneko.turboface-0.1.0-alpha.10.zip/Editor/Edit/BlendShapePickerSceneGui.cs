using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal sealed class BlendShapePickerSceneGui
    {
        readonly BlendShapePickerService blendShapePickerService;

        public BlendShapePickerSceneGui(BlendShapePickerService blendShapePickerService)
        {
            this.blendShapePickerService = blendShapePickerService;
        }

        public void OnSceneGUI(SceneView sceneView)
        {
            var currentEvent = Event.current;

            if (blendShapePickerService.Picking.Value)
            {
                Handles.BeginGUI();

                using (TurboFaceGUI.WithColor(new Color(0f, 1f, 1f, 0.2f)))
                {
                    GUI.DrawTexture(new Rect(0, 0, sceneView.position.width, sceneView.position.height), Texture2D.whiteTexture);
                }

                Handles.EndGUI();

                if (currentEvent.type == EventType.MouseDown && currentEvent.button == 0)
                {
                    blendShapePickerService.Pick(currentEvent.mousePosition);
                    currentEvent.Use();
                }
            }

            if (blendShapePickerService.PickResult.Value is BlendShapePickerService.VertexSelectionResult pickResult &&
                currentEvent.type == EventType.Repaint)
            {
                Handles.color = Color.cyan;

                Handles.SphereHandleCap(
                    GUIUtility.GetControlID(FocusType.Passive),
                    pickResult.PickedVertexPosition,
                    Quaternion.identity,
                    HandleUtility.GetHandleSize(pickResult.PickedVertexPosition) * 0.1f,
                    EventType.Repaint);
            }
        }
    }
}
