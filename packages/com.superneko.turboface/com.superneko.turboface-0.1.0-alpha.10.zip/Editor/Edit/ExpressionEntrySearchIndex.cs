using System;
using System.Collections.Generic;
using UnityEngine.Profiling;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal sealed class BKNode
    {
        readonly ExpressionEntry entry;
        readonly Dictionary<int, BKNode> children = new Dictionary<int, BKNode>();

        public BKNode(ExpressionEntry entry)
        {
            this.entry = entry;
        }

        public void Add(ExpressionEntry targetEntry)
        {
            var distance = Levenshtein(entry.DisplayName, targetEntry.DisplayName);

            if (children.TryGetValue(distance, out var child))
            {
                child.Add(targetEntry);
                return;
            }

            children[distance] = new BKNode(targetEntry);
        }

        public void Search(ExpressionEntry query, int maxDistance, List<ExpressionEntry> result)
        {
            if (Math.Abs(entry.DisplayName.Length - query.DisplayName.Length) < maxDistance)
            {
                var distance = Levenshtein(entry.DisplayName, query.DisplayName);

                if (distance <= maxDistance)
                {
                    result.Add(entry);
                }

                var from = distance - maxDistance;
                var to = distance + maxDistance;

                foreach (var pair in children)
                {
                    if (pair.Key >= from && pair.Key <= to)
                    {
                        pair.Value.Search(query, maxDistance, result);
                    }
                }

                return;
            }

            foreach (var child in children.Values)
            {
                child.Search(query, maxDistance, result);
            }
        }

        static int Levenshtein(string a, string b)
        {
            var n = a.Length;
            var m = b.Length;

            var dp = new int[n + 1, m + 1];

            for (var i = 0; i <= n; i++)
            {
                dp[i, 0] = i;
            }

            for (var j = 0; j <= m; j++)
            {
                dp[0, j] = j;
            }

            for (var i = 1; i <= n; i++)
            {
                for (var j = 1; j <= m; j++)
                {
                    var cost = a[i - 1] == b[j - 1] ? 0 : 1;
                    var del = dp[i - 1, j] + 1;
                    var ins = dp[i, j - 1] + 1;
                    var sub = dp[i - 1, j - 1] + cost;

                    dp[i, j] = Math.Min(Math.Min(del, ins), sub);
                }
            }

            return dp[n, m];
        }
    }

    internal sealed class EntryQuery
    {
        readonly string[] displayNameContains;

        public EntryQuery(string queryString)
        {
            displayNameContains = queryString.Split(new[] { ' ', '　' }, StringSplitOptions.RemoveEmptyEntries);
        }

        public bool TestEntry(ExpressionEntry entry)
        {
            foreach (var queryPart in displayNameContains)
            {
                if (entry.DisplayName.IndexOf(queryPart, StringComparison.OrdinalIgnoreCase) < 0)
                {
                    return false;
                }
            }

            return true;
        }
    }

    internal sealed class EntryIndex
    {
        readonly ExpressionEntry[] entries;
        readonly Dictionary<ExpressionEntry, ExpressionEntry[]> similarEntryIndex;

        public EntryIndex(ExpressionEntry[] entries)
        {
            this.entries = entries;
            similarEntryIndex = BuildSimilarDisplayNameIndex(entries, 3);
        }

        public ExpressionEntry[] SearchByQuery(EntryQuery query)
        {
            Profiler.BeginSample("ExpressionEntrySearchService.SearchByQuery");

            var results = new List<ExpressionEntry>();

            foreach (var entry in entries)
            {
                if (query.TestEntry(entry))
                {
                    results.Add(entry);
                }
            }

            Profiler.EndSample();

            return results.ToArray();
        }

        public ExpressionEntry[] FindBySimilarDisplayName(ExpressionEntry entry)
        {
            Profiler.BeginSample("ExpressionEntrySearchService.FindBySimilarDisplayName");

            var results = Array.Empty<ExpressionEntry>();

            if (similarEntryIndex.TryGetValue(entry, out var similarEntries))
            {
                results = similarEntries;
            }

            Profiler.EndSample();
            return results;
        }

        static Dictionary<ExpressionEntry, ExpressionEntry[]> BuildSimilarDisplayNameIndex(ExpressionEntry[] entries, int maxDistance)
        {
            if (maxDistance < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(maxDistance));
            }

            if (entries.Length == 0)
            {
                return new Dictionary<ExpressionEntry, ExpressionEntry[]>();
            }

            var root = new BKNode(entries[0]);

            for (var i = 1; i < entries.Length; ++i)
            {
                root.Add(entries[i]);
            }

            var index = new Dictionary<ExpressionEntry, List<ExpressionEntry>>();

            foreach (var entry in entries)
            {
                var hits = new List<ExpressionEntry>();
                root.Search(entry, maxDistance, hits);

                foreach (var hit in hits)
                {
                    if (hit.BlendShapeIndex == entry.BlendShapeIndex)
                    {
                        continue;
                    }

                    if (!index.TryGetValue(entry, out var list))
                    {
                        list = new List<ExpressionEntry>();
                        index[entry] = list;
                    }

                    list.Add(hit);
                }
            }

            var result = new Dictionary<ExpressionEntry, ExpressionEntry[]>();

            foreach (var pair in index)
            {
                result[pair.Key] = pair.Value.ToArray();
            }

            return result;
        }
    }
}
