using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal class ExpressionEntryContextMenu : PopupWindowContent
    {
        readonly ServiceRoot model;
        readonly Expression expression;
        readonly ExpressionEntry entry;
        readonly List<ExpressionEntry> relatedEntries;
        EntriesView? entriesView;

        ExpressionEntryContextMenu(ServiceRoot model, Expression expression, ExpressionEntry entry)
        {
            this.model = model;
            this.entry = entry;
            this.expression = expression;

            relatedEntries = new List<ExpressionEntry>();

            foreach (var index in model.ExpressionEntrySearchService.FindSimilarEntries(entry))
            {
                relatedEntries.Add(index);
            }

            relatedEntries.Add(entry);

            relatedEntries.Sort((a, b) => a.BlendShapeIndex.CompareTo(b.BlendShapeIndex));
        }

        public override void OnOpen()
        {
            entriesView = new EntriesView(this.editorWindow, model, false);
            editorWindow.wantsMouseMove = true;
        }

        public override Vector2 GetWindowSize()
        {
            return new Vector2(500, 500);
        }

        public override void OnGUI(Rect rect)
        {
            GUILayout.BeginArea(rect);
            GUILayout.Label($"Related entries for {entry.DisplayName}");

            entriesView?.OnGUI(expression, relatedEntries);

            GUILayout.EndArea();
        }

        public static void Open(Rect rect, ServiceRoot model, Expression expression, ExpressionEntry entry)
        {
            var menu = new ExpressionEntryContextMenu(model, expression, entry);

            PopupWindow.Show(rect, menu);
        }
    }
}
