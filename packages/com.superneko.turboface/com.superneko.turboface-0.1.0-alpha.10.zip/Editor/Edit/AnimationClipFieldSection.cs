using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal sealed class AnimationClipFieldSection
    {
        readonly ExpressionEditorService expressionEditorService;

        public AnimationClipFieldSection(ExpressionEditorService expressionEditorService)
        {
            this.expressionEditorService = expressionEditorService;
        }

        public void Draw()
        {
            GUILayout.BeginHorizontal();

            var currentClip = expressionEditorService.BaseAnimationClip.Value;
            var selectedObject = EditorGUILayout.ObjectField(L.M("edit.animation-clip-to-edit"), currentClip, typeof(AnimationClip), true);
            expressionEditorService.SetBaseAnimationClip(selectedObject as AnimationClip);

            var buttonColor = expressionEditorService.BaseAnimationClip.Value != null ? Color.white : Color.cyan;

            using (TurboFaceGUI.WithColor(buttonColor))
            {
                if (GUILayout.Button("+", GUILayout.Width(EditorGUIUtility.singleLineHeight)))
                {
                    ShowContextMenu();
                }
            }

            GUILayout.EndHorizontal();
        }

        void ShowContextMenu()
        {
            var menu = new GenericMenu();

            menu.AddItem(new GUIContent(L.M("general.create-new")), false, CreateAndAssignClip);
            menu.AddItem(new GUIContent(L.M("general.open")), false, OpenAndAssignExistingClip);

            if (expressionEditorService.BaseAnimationClip.Value != null)
            {
                menu.AddItem(new GUIContent(L.M("general.duplicate")), false, DuplicateAndAssignClip);
            }

            menu.ShowAsContext();
        }

        void CreateAndAssignClip()
        {
            var existingPath = "Assets";
            var baseClip = expressionEditorService.BaseAnimationClip.Value;

            if (baseClip != null)
            {
                existingPath = AssetDatabase.GetAssetPath(baseClip);
            }

            var newClip = AnimationClipService.CreateNewClip(existingPath);

            expressionEditorService.SetBaseAnimationClip(newClip);
        }

        void OpenAndAssignExistingClip()
        {
            var path = "Assets";

            if (expressionEditorService.BaseAnimationClip.Value != null)
            {
                var currentPath = AssetDatabase.GetAssetPath(expressionEditorService.BaseAnimationClip.Value);
                
                if (!string.IsNullOrEmpty(currentPath))
                {
                    path = currentPath;
                }
            }

            var clip = AnimationClipService.OpenClip(path);

            if (clip != null)
            {
                expressionEditorService.SetBaseAnimationClip(clip);
                return;
            }
        }

        void DuplicateAndAssignClip()
        {
            var baseClip = expressionEditorService.BaseAnimationClip.Value;

            if (baseClip == null)
            {
                return;
            }

            var newClip = Object.Instantiate(baseClip);
            newClip.name = $"{baseClip.name} (Copy)";

            var originalPath = AssetDatabase.GetAssetPath(baseClip);
            var newPath = AssetDatabase.GenerateUniqueAssetPath(originalPath);

            AssetDatabase.CreateAsset(newClip, newPath);
            AssetDatabase.SaveAssets();

            expressionEditorService.SetBaseAnimationClip(newClip);
            EditorGUIUtility.PingObject(newClip);
        }
    }
}
