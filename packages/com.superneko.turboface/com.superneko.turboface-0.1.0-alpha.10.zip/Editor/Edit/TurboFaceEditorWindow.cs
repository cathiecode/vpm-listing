using UniRx;
using UnityEditor;
using UnityEngine;
using System;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal class TurboFaceEditorWindow : EditorWindow
    {
        [MenuItem("Window/TurboFace Edit")]
        public static void ShowWindow()
        {
            var window = GetWindow<TurboFaceEditorWindow>();
            window.titleContent = new GUIContent("TurboFace Edit", TurboFaceUtils.LoadAssetByGUID<Texture2D>("caa3688c0f8fc3a4a8a9533f846e4e31"));
            window.Show();
        }

        ServiceRoot model = null!;
        EntriesView entriesView = null!;
        AnimationClipFieldSection animationClipFieldSection = null!;
        readonly SearchPopupController searchPopupController = new SearchPopupController();
        BlendShapePickerSceneGui sceneGui = null!;
        bool manualAvatarDataFoldout = false;
        bool blendShapeSettingsFoldout = false;

        IDisposable subscription = Disposable.Empty;

        public void OnEnable()
        {
            model = ServiceRoot.Instance;
            entriesView = new EntriesView(this, model);
            entriesView.Initialize();
            animationClipFieldSection = new AnimationClipFieldSection(model.ExpressionEditorService);
            sceneGui = new BlendShapePickerSceneGui(model.BlendShapePickerService);

            var d = new CompositeDisposable();

            Observable.CombineLatest(
                model.PreviewService.IsPreviewing,
                model.ExpressionEditorService.EntriesSortKeyAspect,
                model.ExpressionEditorService.EntriesAnimationAspect,
                model.BlendShapePickerService.Picking,
                ValueTuple.Create
            )
                .Subscribe(_ =>
                {
                    Repaint();
                    SceneView.RepaintAll();
                })
                .AddTo(d);

            Observable.CombineLatest(model.ExpressionEditorService.EntriesListStructureAspect).Subscribe(_ =>
            {
                EditorApplication.delayCall += () =>
                {
                    entriesView.ResetScrollPosition();
                    Repaint();
                };
            }).AddTo(d);

            subscription = d;

            SceneView.duringSceneGui += OnSceneGUI;
            EditorApplication.update += Update;
            wantsMouseMove = true;
        }

        public void OnDisable()
        {
            subscription.Dispose();
            entriesView.Dispose();
            SceneView.duringSceneGui -= OnSceneGUI;
            EditorApplication.update -= Update;
        }

        public void Update()
        {

        }

        public void OnGUI()
        {
            if (model == null) return;

            if (model.PreviewService.IsPreviewing.Value)
            {
                if (GUILayout.Button(L.M("edit.stop-preview"), GUILayout.Height(EditorGUIUtility.singleLineHeight * 2)))
                {
                    model.PreviewService.StopPreview();
                }
            }
            else
            {
                EditorGUI.BeginDisabledGroup(!model.PreviewService.CheckPreviewable().IsSuccess);

                if (GUILayout.Button(L.M("edit.start-preview"), GUILayout.Height(EditorGUIUtility.singleLineHeight * 2)))
                {
                    model.PreviewService.StartPreview();
                }
                EditorGUI.EndDisabledGroup();
            }

            if (!model.PreviewService.CheckPreviewable().IsSuccess && model.PreviewService.CheckPreviewable().Error is Exception previewRequisitesError)
            {
                TurboFaceGUI.Exception(previewRequisitesError);
            }

            animationClipFieldSection.Draw();

            manualAvatarDataFoldout = EditorGUILayout.Foldout(manualAvatarDataFoldout, L.M("edit.open-avatar-data"));

            if (manualAvatarDataFoldout || model.AvatarService.AvatarRoot.Value == null || model.AvatarService.FaceSMR.Value == null)
            {
                EditorGUI.BeginDisabledGroup(model.PreviewService.IsPreviewing.Value);
                model.AvatarService.SetAvatarRoot((Transform?)EditorGUILayout.ObjectField(L.M("edit.avatar-root"), model.AvatarService.AvatarRoot.Value, typeof(Transform), true));
                model.AvatarService.SetFaceSMR((SkinnedMeshRenderer?)EditorGUILayout.ObjectField(L.M("edit.face-smr"), model.AvatarService.FaceSMR.Value, typeof(SkinnedMeshRenderer), true));
                EditorGUI.EndDisabledGroup();

                model.AvatarService.SetDefaultFaceAnimation((AnimationClip?)EditorGUILayout.ObjectField(L.M("edit.default-face-animation"), model.AvatarService.DefaultFaceAnimation.Value, typeof(AnimationClip), true));
            }

            if (blendShapeSettingsFoldout = EditorGUILayout.Foldout(blendShapeSettingsFoldout, L.M("edit.blend-shape-settings")))
            {
                OnGUISettings();
            }

            GUILayout.Space(10);

            GUILayout.BeginHorizontal();

            if (model.BlendShapePickerService.Picking.Value)
            {
                using (TurboFaceGUI.WithColor(Color.cyan))
                {
                    if (GUILayout.Button(new GUIContent(Textures.Instance.GetTexture(TextureName.Picker)), GUILayout.Width(30), GUILayout.Height(30), GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false)))
                    {
                        model.BlendShapePickerService.StopPicking();
                    }
                }
            }
            else
            {
                using (TurboFaceGUI.WithColor(model.BlendShapePickerService.PickResult.Value != null ? Color.green : Color.white))
                {
                    if (GUILayout.Button(new GUIContent(Textures.Instance.GetTexture(TextureName.Picker)), GUILayout.Width(30), GUILayout.Height(30), GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false)))
                    {
                        if (model.BlendShapePickerService.PickResult.Value != null)
                        {
                            model.BlendShapePickerService.ClearPickedVertex();
                        }

                        model.BlendShapePickerService.StartPicking();
                    }
                }
            }

            searchPopupController.DrawAndHandleOpen(model);

            GUILayout.EndHorizontal();

            var mayExpression = model.ExpressionEditorService.Expression.Value;

            if (mayExpression.Value is Expression expression)
            {
                entriesView.OnGUI(model.ExpressionEditorService.Expression.Value.Unwrap(), expression.GetEntries());
            }

            if (mayExpression.Error is Exception error)
            {
                TurboFaceGUI.Exception(error);
            }
        }

        void OnGUISettings()
        {
            var threshold = model.ExpressionEditorService.Threshold.Value;

            var visibleThreshold = (Mathf.Log10(threshold) + 4f) / 4f;

            visibleThreshold = EditorGUILayout.Slider(L.M("edit.blend-shape-influence-threshold"), visibleThreshold, 0f, 1f);

            var newThreshold = Mathf.Pow(10f, visibleThreshold * 4f - 4f);

            model.ExpressionEditorService.SetThreshold(newThreshold);

            model.ExpressionEditorService.SetBlendShapeFolderSplitter(EditorGUILayout.TextField(L.M("edit.blend-shape-folder-splitter"), model.ExpressionEditorService.BlendShapeFolderSplitter.Value));
        }

        void OnSceneGUI(SceneView sceneView)
        {
            if (model == null) return;
            sceneGui.OnSceneGUI(sceneView);
        }
    }
}

