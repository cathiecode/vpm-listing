using System;
using System.Collections.Generic;
using System.Linq;
using UniRx;
using UnityEditor;
using UnityEngine;
using UnityEngine.Profiling;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal class ExpressionEditorService : ReactiveService
    {
        class ExpressionEditorModelState : ScriptableSingleton<ExpressionEditorModelState>
        {
            public ReactiveProperty<AnimationClip?> BaseAnimationClip = new(null);
            public ReactiveProperty<string> BlendShapeFolderSplitter = new("--");
            public ReactiveProperty<float> Threshold = new(0.0001f);
        }

        internal enum SortKey
        {
            WillMoveCurrentSelectedVertex,
            FolderIndex,
            IsFolder,
            BlendShapeInfluenceScore,
            BlendShapeIndex,
            RegisteredDataFirstFrameValue,
            IsRegistered,
        }

        internal struct SortRule
        {
            public SortKey Key;
            public bool Ascending;
        }

        public ExpressionEditorService(AvatarService avatarModel)
        {
            this.avatarModel = avatarModel;
        }

        protected override void Initialize(CompositeDisposable d)
        {
            Observable
                .CombineLatest(avatarModel.AvatarRoot, avatarModel.FaceSMR, state.BaseAnimationClip, ValueTuple.Create)
                .Throttle(TimeSpan.FromMilliseconds(250))
                .Subscribe(RebuildEntries).AddTo(d);

            Observable.CombineLatest(avatarModel.FaceSMR, state.Threshold, ValueTuple.Create).Subscribe(UpdateInfluenceData).AddTo(d);

            Observable.CombineLatest(entriesSetAspect, state.BlendShapeFolderSplitter, ValueTuple.Create).Subscribe(UpdateEntryFolders).AddTo(d);

            Observable.CombineLatest(avatarModel.FaceSMR, entriesSetAspect, selectedVertexIndex, influenceData, ValueTuple.Create).Subscribe(UpdateInfluenceSortKey).AddTo(d);

            Observable.CombineLatest(entriesSortKeyAspect, selectedVertexIndex, sortRule, ValueTuple.Create).Subscribe(SortEntries).AddTo(d);

            Observable.CombineLatest(expression, avatarModel.DefaultBlendShapeWeights, ValueTuple.Create)
                .Subscribe(UpdateDefaultValues)
                .AddTo(d);

            undoRedoPerformed.Subscribe((_) => expression.Value?.Value?.InvalidateCachedData()).AddTo(d);

            void undoRedoCallback()
            {
                undoRedoPerformed.OnNext(Unit.Value);
            }

            Undo.undoRedoPerformed += undoRedoCallback;

            d.Add(Disposable.Create(() =>
            {
                Undo.undoRedoPerformed -= undoRedoCallback;
            }));
        }

        public ReadOnlyReactiveProperty<Result<Expression>> Expression => expression.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> EntriesSetAspect => entriesSetAspect.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> EntriesAnimationAspect => entriesAnimationAspect.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> EntriesSortKeyAspect => entriesSortKeyAspect.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> EntriesListStructureAspect => entriesListStructureAspect.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<AnimationClip?> BaseAnimationClip => state.BaseAnimationClip.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<float> Threshold => state.Threshold.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<Result<BlendShapeInfluenceData>> InfluenceData => influenceData.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<string> BlendShapeFolderSplitter => state.BlendShapeFolderSplitter.ToReadOnlyReactiveProperty();
        public string[] FolderNames { get; private set; } = new string[] { "" };
        public ReadOnlyReactiveProperty<List<SortRule>> SortRules => sortRule.ToReadOnlyReactiveProperty();

        ExpressionEditorModelState state => ExpressionEditorModelState.instance;

        readonly AvatarService avatarModel;

        readonly AlwaysNotifyReactiveProperty<Result<Expression>> expression = new AlwaysNotifyReactiveProperty<Result<Expression>>(Result<Expression>.Failure(new InvalidOperationException("No expression loaded")));
        readonly AlwaysNotifyReactiveProperty<Result<ExpressionEntry[]>> entriesSetAspect = new(Result<ExpressionEntry[]>.Failure(new InvalidOperationException("No entries loaded")));
        readonly AlwaysNotifyReactiveProperty<Result<ExpressionEntry[]>> entriesAnimationAspect = new(Result<ExpressionEntry[]>.Failure(new InvalidOperationException("No entries loaded")));
        readonly AlwaysNotifyReactiveProperty<Result<ExpressionEntry[]>> entriesSortKeyAspect = new(Result<ExpressionEntry[]>.Failure(new InvalidOperationException("No entries loaded")));
        readonly AlwaysNotifyReactiveProperty<Result<ExpressionEntry[]>> entriesListStructureAspect = new(Result<ExpressionEntry[]>.Failure(new InvalidOperationException("No entries loaded")));
        readonly Subject<Unit> undoRedoPerformed = new Subject<Unit>();

        readonly ReactiveProperty<int> selectedVertexIndex = new(-1);
        readonly AlwaysNotifyReactiveProperty<Result<BlendShapeInfluenceData>> influenceData = new(new InvalidOperationException("No influence data loaded"));
        readonly AlwaysNotifyReactiveProperty<List<SortRule>> sortRule = new(new List<SortRule>()
        {
            new() { Key = SortKey.WillMoveCurrentSelectedVertex, Ascending = false },
            new() { Key = SortKey.IsRegistered, Ascending = false },
            new() { Key = SortKey.FolderIndex, Ascending = true },
            new() { Key = SortKey.BlendShapeInfluenceScore, Ascending = false },
            new() { Key = SortKey.BlendShapeIndex, Ascending = true },
        });

        public void SetThreshold(float newThreshold)
        {
            if (Mathf.Abs(newThreshold - state.Threshold.Value) > 0.00001f)
            {
                Logging.Trace($"Setting new threshold: {newThreshold}");
                state.Threshold.Value = newThreshold;
            }
        }

        public void ChangeSelectedVertex(int vertexIndex)
        {
            selectedVertexIndex.Value = vertexIndex;

            if (vertexIndex > 0)
            {
                SetSortRule(SortKey.BlendShapeInfluenceScore, false);
                SetSortRule(SortKey.WillMoveCurrentSelectedVertex, false);
            }
        }

        public void SetBaseAnimationClip(AnimationClip? clip)
        {
            if (state.BaseAnimationClip.Value == clip)
            {
                return;
            }

            state.BaseAnimationClip.Value = clip;
        }

        public void SetSortRule(SortKey key)
        {
            var rules = sortRule.Value;

            var latestRule = rules.Last();

            if (latestRule.Key == key)
            {
                latestRule.Ascending = !latestRule.Ascending;
                rules[^1] = latestRule;
                sortRule.Value = rules;
                return;
            }

            var shouldAscend = false;

            if (key == SortKey.BlendShapeIndex)
            {
                shouldAscend = true;
            }

            rules.Add(new SortRule() { Key = key, Ascending = shouldAscend });

            if (rules.Count > 6)
            {
                rules.RemoveAt(0);
            }

            sortRule.Value = rules;
        }

        public void SetSortRule(SortKey key, bool ascending)
        {
            var rules = sortRule.Value;

            var latestRule = rules.Last();

            if (latestRule.Key == key)
            {
                latestRule.Ascending = ascending;
                rules[^1] = latestRule;
                sortRule.Value = rules;
                return;
            }

            rules.RemoveAll(r => r.Key == key);

            rules.Add(new SortRule() { Key = key, Ascending = ascending });

            if (rules.Count > 6)
            {
                rules.RemoveAt(0);
            }

            sortRule.Value = rules;
        }

        public string SetBlendShapeFolderSplitter(string splitter)
        {
            if (state.BlendShapeFolderSplitter.Value == splitter)
            {
                return splitter;
            }

            state.BlendShapeFolderSplitter.Value = splitter;

            return splitter;
        }

        void RebuildEntries((Transform? baseTransform, SkinnedMeshRenderer? faceSMR, AnimationClip? baseAnimationClip) args)
        {
            void SetRebuiltEntries(Result<Expression> mayExpression)
            {
                expression.Value = mayExpression;

                var entries = mayExpression.Map(expr => expr.GetEntries());
                entriesAnimationAspect.Value = entries;
                entriesListStructureAspect.Value = entries;
                entriesSetAspect.Value = entries;
            }

            var (baseTransform, faceSMR, baseAnimationClip) = args;

            Logging.Trace("ExpressionEditorModel: Rebuilding entries.");

            if (expression.Value.IsSuccess)
            {
                Logging.Trace("ExpressionEditorModel: Expression already exist. Cleaning up.");

                expression.Value.Unwrap().ClearUndoHistory();
            }

            if (baseTransform == null)
            {
                Logging.Trace("ExpressionEditorModel: baseTransform is null. Clearing expression.");
                SetRebuiltEntries(Result<Expression>.Failure(new PreconditionException(MessageKey.Get("edit.no-avatar-loaded"))));
                return;
            }

            if (faceSMR == null)
            {
                Logging.Trace("ExpressionEditorModel: faceSMR is null. Clearing expression.");
                SetRebuiltEntries(Result<Expression>.Failure(new PreconditionException(MessageKey.Get("edit.no-face-smr-loaded"))));
                return;
            }

            if (baseAnimationClip == null)
            {
                Logging.Trace("ExpressionEditorModel: baseAnimationClip is null. Clearing expression.");
                SetRebuiltEntries(Result<Expression>.Failure(new PreconditionException(MessageKey.Get("edit.no-base-animationclip"))));
                return;
            }

            Profiler.BeginSample("ExpressionEditorModel: Rebuilding entries");

            var newExpression = new Expression(baseTransform, faceSMR, baseAnimationClip);

            newExpression.EntryAnimationValueChanged += (changedEntry) =>
            {
                Logging.Trace($"ExpressionEditorModel: Entry animation value changed: {changedEntry?.DisplayName ?? "(Unknown, all)"}");
                entriesAnimationAspect.Value = newExpression.GetEntries();
            };

            // Heuristic folder name detection

            Dictionary<string, int> folderNameIndicatorCandidateCount = new Dictionary<string, int>();

            foreach (var entry in newExpression.GetEntries())
            {
                var blendShapeName = entry.PropertyName.Substring("blendShape.".Length);

                // Is folder-like?
                if (blendShapeName.Length >= 3 && blendShapeName[0] == blendShapeName[1] && blendShapeName[1] == blendShapeName[2])
                {
                    var repeatCount = blendShapeName.TakeWhile(c => c == blendShapeName[0]).Count();
                    var count = folderNameIndicatorCandidateCount.GetOrCreate(blendShapeName.Substring(0, repeatCount), () => 0);
                    folderNameIndicatorCandidateCount[blendShapeName[..repeatCount]] = count + 1;
                }
            }

            state.BlendShapeFolderSplitter.Value = folderNameIndicatorCandidateCount
                .Where(kv => kv.Value >= 2)
                .OrderByDescending(kv => kv.Value)
                .Select(kv => kv.Key)
                .FirstOrDefault() ?? "";

            expression.Value = newExpression;
            entriesAnimationAspect.Value = newExpression.GetEntries();
            entriesListStructureAspect.Value = newExpression.GetEntries();
            entriesSetAspect.Value = newExpression.GetEntries();
            Profiler.EndSample();
        }

        void UpdateInfluenceData((SkinnedMeshRenderer? faceSMR, float threshold) args)
        {
            var (faceSMR, threshold) = args;

            Logging.Trace("ExpressionEditorModel: Updating BlendShapeInfluenceData.");

            if (faceSMR == null)
            {
                Logging.Trace("ExpressionEditorModel: faceSMR is null. Clearing influence data.");
                influenceData.Value = new PreconditionException(MessageKey.Get("edit.no-face-smr-loaded"));
                return;
            }

            influenceData.Value = BlendShapeInfluenceData.FromSkinnedMeshRenderer(faceSMR, threshold);
        }

        void UpdateEntryFolders((Result<ExpressionEntry[]> entries, string blendShapeFolderSplitter) args)
        {
            var (mayEntries, blendShapeFolderSplitter) = args;

            Logging.Trace("ExpressionEditorModel: Scanning folders.");

            if (!mayEntries.IsSuccess)
            {
                Logging.Trace("ExpressionEditorModel: entries is not successfully loaded. Skipping folder scanning.");
                return;
            }

            var entries = mayEntries.Unwrap();

            if (blendShapeFolderSplitter == "")
            {
                FolderNames = ExpressionEntryFolderClassifier.Apply(entries, "");
                state.BlendShapeFolderSplitter.Value = "";
                entriesSortKeyAspect.Value = entries;
                return;
            }

            Profiler.BeginSample("ExpressionEditorModel: Scanning folders");
            FolderNames = ExpressionEntryFolderClassifier.Apply(entries, blendShapeFolderSplitter);

            entriesSortKeyAspect.Value = entries;
            Profiler.EndSample();
        }

        void UpdateDefaultValues((Result<Expression> expression, Result<TiedItem<float[], SkinnedMeshRenderer>> defaultBlendShapeWeights) args)
        {
            var (mayExpression, mayDefaultBlendShapeWeights) = args;

            if (!mayExpression.IsSuccess)
            {
                Logging.Trace("ExpressionEditorModel: expression is not successfully loaded. Skipping default value update.");
                return;
            }

            if (!mayDefaultBlendShapeWeights.IsSuccess)
            {
                Logging.Trace("ExpressionEditorModel: defaultBlendShapeWeights is not successfully loaded. Skipping default value update.");
                return;
            }

            Logging.Trace("ExpressionEditorModel: Updating default values.");

            var expression = mayExpression.Unwrap();
            var defaultBlendShapeWeights = mayDefaultBlendShapeWeights.Unwrap();

            if (defaultBlendShapeWeights.TiedTo != expression.Target)
            {
                Logging.Trace("ExpressionEditorModel: defaultBlendShapeWeights is tied to different SkinnedMeshRenderer. Skipping.");
                return;
            }

            Profiler.BeginSample("ExpressionEditorModel: Updating default values");

            foreach (var entry in expression.GetEntries())
            {
                entry.DefaultValue = defaultBlendShapeWeights.Item[entry.BlendShapeIndex];
            }

            entriesSortKeyAspect.Value = expression.GetEntries();
            Profiler.EndSample();
        }

        void UpdateInfluenceSortKey((SkinnedMeshRenderer? faceSMR, Result<ExpressionEntry[]> entries, int selectedVertexIndex, Result<BlendShapeInfluenceData> influenceData) args)
        {
            var (faceSMR, mayEntries, selectedVertexIndex, mayInfluenceData) = args;

            if (!mayEntries.IsSuccess)
            {
                Logging.Trace("ExpressionEditorModel: entries is not successfully loaded. Skipping influence sort key update.");
                return;
            }

            var entries = mayEntries.Unwrap();

            Logging.Trace("ExpressionEditorModel: Updating blendshape influence sort key");

            if (entries == null)
            {
                Logging.Trace("ExpressionEditorModel: entries is null. Skipping.");
                return;
            }

            if (faceSMR == null)
            {
                Logging.Trace("ExpressionEditorModel: faceSMR is null. Skipping.");
                return;
            }

            if (selectedVertexIndex < 0)
            {
                Logging.Trace("ExpressionEditorModel: selectedVertexIndex is less than 0. Removing influence sort key.");
                ExpressionEntryInfluenceUpdater.ResetInfluence(entries);
                return;
            }

            if (!mayInfluenceData.IsSuccess)
            {
                Logging.Trace("ExpressionEditorModel: influenceData is null. Removing influence sort key.");
                ExpressionEntryInfluenceUpdater.ResetInfluence(entries);
                return;
            }

            Profiler.BeginSample("ExpressionEditorModel: Updating blendshape influence sort key");

            var influenceData = mayInfluenceData.Unwrap();

            if (influenceData.Mesh != faceSMR.sharedMesh)
            {
                Logging.Trace("ExpressionEditorModel: influenceData is tied to different mesh. Skipping.");
                ExpressionEntryInfluenceUpdater.ResetInfluence(entries);
                return;
            }
            ExpressionEntryInfluenceUpdater.ApplyInfluenceSortKey(faceSMR, entries, selectedVertexIndex, influenceData);

            entriesSortKeyAspect.Value = entries;
            Profiler.EndSample();
        }

        void SortEntries((Result<ExpressionEntry[]> entries, int selectedVertexIndex, List<SortRule> sortRule) args)
        {
            var (mayEntries, selectedVertexIndex, sortRule) = args;

            Logging.Trace("ExpressionEditorModel: sorting entries.");

            if (!mayEntries.IsSuccess)
            {
                Logging.Trace("ExpressionEditorModel: entries is not successfully loaded. Skipping sorting.");
                return;
            }

            var entries = mayEntries.Unwrap();

            if (entries == null)
            {
                return;
            }

            if (sortRule == null)
            {
                return;
            }

            foreach (var rule in sortRule)
            {
                Logging.Trace($"  Sort Rule: {rule.Key}, Ascending: {rule.Ascending}");
            }

            Profiler.BeginSample("ExpressionEditorModel: sorting entries");
            ExpressionEntrySorter.SortInPlace(entries, sortRule);

            entriesListStructureAspect.Value = entries;
            Profiler.EndSample();
        }
    }
}
