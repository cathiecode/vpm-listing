using System;
using UniRx;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    static class TurboFaceGUI
    {
        public static float Slider(Rect rect, float value, float min, float max, float defaultValue = 0f, bool lineOnly = false)
        {
            var id = GUIUtility.GetControlID(FocusType.Passive);

            var updateValue = false;
            var padding = 10f;

            var effectiveRect = new Rect(rect.x + padding, rect.y, rect.width - padding * 2, rect.height);

            DrawSlider(effectiveRect, value, min, max, defaultValue, lineOnly);

            if (Event.current.type == EventType.MouseDown && rect.Contains(Event.current.mousePosition))
            {
                updateValue = true;
                GUIUtility.hotControl = id;
                Event.current.Use();
            }

            if (Event.current.type == EventType.MouseUp && GUIUtility.hotControl == id)
            {
                GUIUtility.hotControl = 0;
                Event.current.Use();
            }

            if (Event.current.type == EventType.MouseDrag)
            {
                if (GUIUtility.hotControl == id)
                {
                    updateValue = true;
                    Event.current.Use();
                }
            }

            if (updateValue)
            {
                float mousePosRatio = Mathf.Clamp01((Event.current.mousePosition.x - effectiveRect.x) / effectiveRect.width);
                value = Mathf.Lerp(min, max, mousePosRatio);
            }

            return value;
        }

        public static (float, bool) HoverPreviewSlider(Rect rect, float value, float min, float max, EditorWindow currentEditorWindow, float defaultValue = 0f)
        {
            var valueUpdated = false;
            var padding = 10f;

            var effectiveRect = new Rect(rect.x + padding, rect.y, rect.width - padding * 2, rect.height);

            DrawSlider(effectiveRect, value, min, max, defaultValue, isPreview: true);

            if (Event.current.isMouse)
            {
                if (rect.Contains(Event.current.mousePosition))
                {
                    float mousePosRatio = Mathf.Clamp01((Event.current.mousePosition.x - effectiveRect.x) / effectiveRect.width);
                    value = Mathf.Lerp(min, max, mousePosRatio);
                }
                else
                {
                    value = 0f;
                }

                currentEditorWindow.Repaint();

                valueUpdated = true;
            }

            return (value, valueUpdated);
        }

        static void DrawSlider(Rect rect, float value, float min, float max, float defaultValue = 0f, bool isPreview = false, bool lineOnly = false)
        {
            Textures.Instance.DrawTexture(TextureName.Line, rect, Color.gray);
            Textures.Instance.DrawTexture(TextureName.Line, new Rect(rect.x, rect.y, rect.width * ((value - min) / (max - min)), rect.height), Color.cyan);

            var defaultValueKnobCenterX = rect.x + rect.width * ((defaultValue - min) / (max - min));
            var defaultValueKnobCenterY = rect.y + rect.height / 2;
            var defaultValueKnobSize = rect.height * 0.5f;
            var defaultValueKnobColor = value <= defaultValue ? Color.gray : Color.cyan;
            Textures.Instance.DrawTexture(TextureName.Circle, new Rect(defaultValueKnobCenterX - defaultValueKnobSize / 2, defaultValueKnobCenterY - defaultValueKnobSize / 2, defaultValueKnobSize, defaultValueKnobSize), defaultValueKnobColor);

            if (!isPreview && !lineOnly)
            {
                var knobCenter = rect.x + rect.width * ((value - min) / (max - min));
                Textures.Instance.DrawTexture(TextureName.Circle, new Rect(knobCenter - rect.height / 2, rect.y, rect.height, rect.height));
            }
        }

        public static void Exception(Rect rect, Exception ex)
        {
            if (ex is PreconditionException)
            {
                EditorGUI.HelpBox(rect, ex.Message, MessageType.Warning);
            }
            else
            {
                EditorGUI.HelpBox(rect, $"Unexpected error: {ex.GetType().Name} {ex.Message}", MessageType.Error);
            }
        }

        public static void Exception(Exception ex)
        {
            var rect = GUILayoutUtility.GetRect(0, 40, GUILayout.ExpandWidth(true));
            Exception(rect, ex);
        }

        public static IDisposable WithColor(Color color)
        {
            var previousColor = GUI.color;
            GUI.color = color;

            return Disposable.Create(() =>
            {
                GUI.color = previousColor;
            });
        }
    }
}
