using System;
using System.Collections.Generic;
using System.Linq;
using UniRx;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal sealed class EntriesView : IDisposable
    {
        enum ColumnType
        {
            BlendShapeInfluenceScore,
            Name,
            FirstFrameValue,
            Registered
        }

        sealed class Header : MultiColumnHeader
        {
            readonly ServiceRoot serviceRoot;

            public Header(MultiColumnHeaderState state, ServiceRoot serviceRoot) : base(state)
            {
                allowDraggingColumnsToReorder = true;
                this.serviceRoot = serviceRoot;
            }

            public void Initialize(CompositeDisposable disposableBuilder)
            {
                serviceRoot.ExpressionEditorService.SortRules.AsObservable().Subscribe(_ => { UpdateSorting(); }).AddTo(disposableBuilder);
            }

            protected override void ColumnHeaderClicked(MultiColumnHeaderState.Column column, int columnIndex)
            {
                var innerColumn = (Column)column;

                switch (innerColumn.Type)
                {
                    case ColumnType.BlendShapeInfluenceScore:
                        serviceRoot.ExpressionEditorService.SetSortRule(ExpressionEditorService.SortKey.BlendShapeInfluenceScore, false);
                        serviceRoot.ExpressionEditorService.SetSortRule(ExpressionEditorService.SortKey.WillMoveCurrentSelectedVertex, false);
                        break;
                    case ColumnType.Name:
                        serviceRoot.ExpressionEditorService.SetSortRule(ExpressionEditorService.SortKey.BlendShapeIndex);
                        break;
                    case ColumnType.FirstFrameValue:
                        serviceRoot.ExpressionEditorService.SetSortRule(ExpressionEditorService.SortKey.RegisteredDataFirstFrameValue);
                        break;
                    case ColumnType.Registered:
                        serviceRoot.ExpressionEditorService.SetSortRule(ExpressionEditorService.SortKey.IsRegistered);
                        break;
                }
            }

            public void UpdateSorting()
            {
                var sortRules = serviceRoot.ExpressionEditorService.SortRules.Value;

                if (sortRules.Count == 0)
                {
                    SetSorting(-1, true);
                    return;
                }

                var importantSortRule = sortRules[^1];

                for (var i = 0; i < state.columns.Length; i++)
                {
                    var innerColumn = (Column)GetColumn(i);

                    switch (innerColumn.Type)
                    {
                        case ColumnType.BlendShapeInfluenceScore:
                            if (importantSortRule.Key == ExpressionEditorService.SortKey.BlendShapeInfluenceScore)
                            {
                                SetSorting(i, importantSortRule.Ascending);
                                return;
                            }
                            break;
                        case ColumnType.Name:
                            if (importantSortRule.Key == ExpressionEditorService.SortKey.BlendShapeIndex)
                            {
                                SetSorting(i, importantSortRule.Ascending);
                                return;
                            }
                            break;
                        case ColumnType.FirstFrameValue:
                            if (importantSortRule.Key == ExpressionEditorService.SortKey.RegisteredDataFirstFrameValue)
                            {
                                SetSorting(i, importantSortRule.Ascending);
                                return;
                            }
                            break;
                        case ColumnType.Registered:
                            if (importantSortRule.Key == ExpressionEditorService.SortKey.IsRegistered)
                            {
                                SetSorting(i, importantSortRule.Ascending);
                                return;
                            }
                            break;
                    }
                }
            }
        }

        sealed class Column : MultiColumnHeaderState.Column
        {
            public ColumnType Type;
        }

        Vector2 scrollPosition = Vector2.zero;
        readonly bool showHeader;
        readonly ServiceRoot model;
        readonly EditorWindow window;
        readonly Header header;
        readonly MultiColumnHeaderState headerState;
        readonly CompositeDisposable subscriptions = new CompositeDisposable();

        bool initialized;
        int hoveringEntryIndex;

        public EntriesView(EditorWindow window, ServiceRoot model, bool showHeader = true)
        {
            this.model = model;
            this.window = window;
            this.showHeader = showHeader;

            var columns = new List<Column>
            {
                new()
                {
                    headerContent = new GUIContent("Vertex Influence Score"),
                    width = 50,
                    minWidth = 50,
                    maxWidth = 100,
                    autoResize = false,
                    allowToggleVisibility = true,
                    Type = ColumnType.BlendShapeInfluenceScore
                },
                new()
                {
                    headerContent = new GUIContent("Name"),
                    width = 150,
                    minWidth = 100,
                    autoResize = true,
                    allowToggleVisibility = true,
                    Type = ColumnType.Name
                },
                new()
                {
                    headerContent = new GUIContent("First Frame Value"),
                    width = 150,
                    minWidth = 100,
                    autoResize = true,
                    allowToggleVisibility = true,
                    Type = ColumnType.FirstFrameValue
                },
                new()
                {
                    headerContent = new GUIContent("Registered"),
                    width = 20,
                    minWidth = 20,
                    maxWidth = 20,
                    autoResize = false,
                    allowToggleVisibility = false,
                    Type = ColumnType.Registered
                }
            };

            headerState = new MultiColumnHeaderState(columns.ToArray());
            header = new Header(headerState, model);
        }

        public void Initialize()
        {
            if (initialized)
            {
                return;
            }

            if (showHeader)
            {
                header.Initialize(subscriptions);
            }

            AssemblyReloadEvents.beforeAssemblyReload += Dispose;
            initialized = true;
        }

        public void OnGUI(Expression? expression, IEnumerable<ExpressionEntry>? entries = null)
        {
            var tableSpace = GUILayoutUtility.GetRect(50, 50, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
            OnGUI(tableSpace, expression, entries);
        }

        public void OnGUI(Rect tableSpace, Expression? expression, IEnumerable<ExpressionEntry>? entries = null)
        {
            if (expression == null)
            {
                GUI.Label(tableSpace, "No Expression loaded.");
                return;
            }

            var highlightStyle = new GUIStyle(GUI.skin.label);
            highlightStyle.normal.textColor = Color.cyan;
            highlightStyle.hover.textColor = Color.cyan;
            highlightStyle.active.textColor = Color.cyan;

            (int, float) hoverPreview = (-1, 0f);
            var tableBodyRect = tableSpace;

            if (showHeader)
            {
                var headerRect = tableSpace;
                headerRect.height = 30;
                header.OnGUI(headerRect, scrollPosition.x);
                tableBodyRect.height -= headerRect.height;
                tableBodyRect.y += headerRect.height;
            }

            using (Table.BeginTable(tableBodyRect, scrollPosition))
            {
                foreach (var column in headerState.visibleColumns)
                {
                    Table.GetHeaderCell(headerState.columns[column].width);
                }

                Table.EndHeader();

                var expressionEntries = entries ?? expression.GetEntries();
                var rowCount = expressionEntries.Count();
                scrollPosition = Table.BeginBody(rowCount);

                var quickPreviewingBlendShape = model.PreviewService.QuickPreviewingBlendShape.Value;
                var quickPreviewingBlendShapeIndex = quickPreviewingBlendShape?.Item1 ?? -1;
                var quickPreviewingBlendShapeValue = quickPreviewingBlendShape?.Item2 ?? 0f;

                var entryRowIndex = 0;

                foreach (var entry in expressionEntries)
                {
                    using (var rowScope = Table.BeginRow())
                    {
                        if (!rowScope.IsVisible)
                        {
                            entryRowIndex++;
                            continue;
                        }

                        if (Event.current.isMouse && rowScope.Rect.Contains(Event.current.mousePosition))
                        {
                            hoveringEntryIndex = entryRowIndex;
                        }

                        if (Event.current.type == EventType.MouseDown && Event.current.button == 1 && rowScope.Rect.Contains(Event.current.mousePosition))
                        {
                            ExpressionEntryContextMenu.Open(rowScope.Rect, model, expression, entry);
                            Event.current.Use();
                        }

                        if (hoveringEntryIndex == entryRowIndex)
                        {
                            EditorGUI.DrawRect(rowScope.Rect, new Color(1f, 1f, 1f, 0.1f));
                        }

                        foreach (var columnIndex in headerState.visibleColumns)
                        {
                            var column = (Column)headerState.columns[columnIndex];

                            switch (column.Type)
                            {
                                case ColumnType.BlendShapeInfluenceScore:
                                    GUI.Label(Table.GetNextCell(), $"{entry.BlendShapeInfluenceScore:F2}");
                                    break;
                                case ColumnType.Name:
                                    var style = entry.WillMoveCurrentSelectedVertex ? highlightStyle : GUI.skin.label;
                                    GUI.Button(Table.GetNextCell(), entry.DisplayName, style);
                                    break;
                                case ColumnType.FirstFrameValue:
                                    var sliderCell = Table.GetNextCell();
                                    var changedValue = TurboFaceGUI.Slider(sliderCell, entry.RegisteredData?.FirstFrameValue ?? 0f, 0f, 100f, entry.DefaultValue, entry.RegisteredData == null);

                                    if (changedValue != (entry.RegisteredData?.FirstFrameValue ?? 0f))
                                    {
                                        expression.RecordObject($"Change Entry Value for {entry.DisplayName}");
                                        entry.ChangeFirstFrameValue(changedValue);
                                    }

                                    if (entry.RegisteredData == null)
                                    {
                                        var oldQuickPreviewWeight = entry.BlendShapeIndex == quickPreviewingBlendShapeIndex ? quickPreviewingBlendShapeValue : 0f;
                                        var (newQuickPreviewWeight, valueUpdate) = TurboFaceGUI.HoverPreviewSlider(sliderCell, oldQuickPreviewWeight, 0f, 100f, window, entry.DefaultValue);

                                        if (valueUpdate && newQuickPreviewWeight != 0f)
                                        {
                                            hoverPreview = (entry.BlendShapeIndex, newQuickPreviewWeight);
                                        }
                                    }
                                    break;
                                case ColumnType.Registered:
                                    var toggleOn = entry.RegisteredData != null;
                                    toggleOn = GUI.Toggle(Table.GetNextCell(), toggleOn, "");

                                    if (!toggleOn && entry.RegisteredData != null)
                                    {
                                        expression.RecordObject($"Removed Entry {entry.DisplayName}");
                                        entry.ClearRegisteredData();
                                    }

                                    if (toggleOn && entry.RegisteredData == null)
                                    {
                                        expression.RecordObject($"Added Entry {entry.DisplayName}");
                                        entry.RegisterData();
                                    }
                                    break;
                            }
                        }
                    }

                    entryRowIndex++;
                }

                Table.EndBody();
            }

            if (Event.current.type == EventType.MouseMove)
            {
                if (hoverPreview.Item1 >= 0)
                {
                    model.PreviewService.SetQuickPreviewBlendShape(hoverPreview.Item1, hoverPreview.Item2);
                }
                else
                {
                    model.PreviewService.SetQuickPreviewBlendShape(-1, 0f);
                }
            }
        }

        public void ResetScrollPosition()
        {
            scrollPosition = Vector2.zero;
        }

        public void Dispose()
        {
            if (!initialized)
            {
                return;
            }

            AssemblyReloadEvents.beforeAssemblyReload -= Dispose;
            subscriptions.Dispose();
            initialized = false;
        }
    }
}
