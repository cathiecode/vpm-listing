using System;
using UniRx;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal class ExpressionEntrySearchService : ReactiveService
    {
        readonly ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> entries;
        readonly AlwaysNotifyReactiveProperty<Result<EntryIndex>> entryIndex =
            new(Result.Failure<EntryIndex>(new InvalidOperationException("Entry index is not built yet.")));
        readonly AlwaysNotifyReactiveProperty<Result<ExpressionEntry[]>> searchResults =
            new(Result.Failure<ExpressionEntry[]>(new InvalidOperationException("Search results are not available yet.")));

        public ReactiveProperty<string> SearchQueryString { get; } = new("");
        public ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> SearchResults => searchResults.ToReadOnlyReactiveProperty();

        public ExpressionEntrySearchService(ReadOnlyReactiveProperty<Result<ExpressionEntry[]>> entries)
        {
            this.entries = entries;
        }

        protected override void Initialize(CompositeDisposable d)
        {
            entries.Subscribe(UpdateIndex).AddTo(d);
            Observable.CombineLatest(entryIndex, SearchQueryString, ValueTuple.Create).Subscribe(UpdateSearchResults).AddTo(d);
        }

        public ExpressionEntry[] SearchByQuery(EntryQuery query)
        {
            var index = entryIndex.Value.Value;

            if (index == null)
            {
                return Array.Empty<ExpressionEntry>();
            }

            return index.SearchByQuery(query);
        }

        public ExpressionEntry[] FindSimilarEntries(ExpressionEntry entry)
        {
            var index = entryIndex.Value.Value;

            if (index == null)
            {
                return Array.Empty<ExpressionEntry>();
            }

            return index.FindBySimilarDisplayName(entry);
        }

        void UpdateIndex(Result<ExpressionEntry[]> entries)
        {
            entryIndex.Value = entries.Map(value => new EntryIndex(value));
        }

        void UpdateSearchResults((Result<EntryIndex>, string) args)
        {
            var (index, queryString) = args;

            searchResults.Value = index.Map(currentIndex =>
            {
                if (string.IsNullOrEmpty(queryString))
                {
                    return Array.Empty<ExpressionEntry>();
                }

                var query = new EntryQuery(queryString);
                return currentIndex.SearchByQuery(query);
            });
        }
    }
}
