using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal static class ExpressionEntryFolderClassifier
    {
        public static string[] Apply(ExpressionEntry[] entries, string blendShapeFolderSplitter)
        {
            var folderNames = new List<string>();

            if (blendShapeFolderSplitter == "")
            {
                foreach (var entry in entries)
                {
                    entry.SetFolderName("");
                    entry.IsFolder = false;
                }

                return new[] { "" };
            }

            folderNames.Add("");
            var folderIndex = 0;

            var entriesSortedByBlendShapeIndex = entries.OrderBy(entry => entry.BlendShapeIndex).ToArray();

            for (var i = 0; i < entriesSortedByBlendShapeIndex.Length; i++)
            {
                var entry = entriesSortedByBlendShapeIndex[i];
                var isFolder = entry.PropertyName.Substring("blendShape.".Length).StartsWith(blendShapeFolderSplitter);

                if (isFolder)
                {
                    var folderName = entry.PropertyName.Substring("blendShape.".Length + blendShapeFolderSplitter.Length);

                    if (folderName.StartsWith(blendShapeFolderSplitter))
                    {
                        folderName = folderName.Substring(blendShapeFolderSplitter.Length);
                    }

                    var suffix = new string(blendShapeFolderSplitter.Select(c => c.CounterPart()).Reverse().ToArray());

                    if (folderName.EndsWith(suffix))
                    {
                        folderName = folderName[..^blendShapeFolderSplitter.Length];
                    }

                    folderNames.Add(folderName);
                    folderIndex++;
                }

                entry.SetFolderName(folderNames[folderIndex]);
                entry.IsFolder = isFolder;
            }

            return folderNames.ToArray();
        }
    }

    internal static class ExpressionEntryInfluenceUpdater
    {
        public static void ApplyInfluenceSortKey(
            SkinnedMeshRenderer faceSmr,
            ExpressionEntry[] entries,
            int selectedVertexIndex,
            BlendShapeInfluenceData influenceData
        )
        {
            if (selectedVertexIndex < 0 || influenceData.Mesh != faceSmr.sharedMesh)
            {
                ResetInfluence(entries);
                return;
            }

            var influencingBlendShapeIndicesForVertex = influenceData.GetInfluencingBlendShapesForVertex(selectedVertexIndex);
            var sharedMesh = faceSmr.sharedMesh;

            ResetInfluence(entries);

            foreach (var blendShapeIndex in influencingBlendShapeIndicesForVertex)
            {
                var blendShapeName = sharedMesh.GetBlendShapeName(blendShapeIndex);
                var path = entries[0].Path;
                var propertyName = $"blendShape.{blendShapeName}";

                for (var i = 0; i < entries.Length; i++)
                {
                    var entry = entries[i];

                    if (entry.Path == path && entry.PropertyName == propertyName)
                    {
                        entries[i].WillMoveCurrentSelectedVertex = true;
                        break;
                    }
                }
            }

            var scores = influenceData.GetBlendShapeInfluenceScores(selectedVertexIndex);

            if (scores == null)
            {
                return;
            }

            for (var i = 0; i < entries.Length; i++)
            {
                var entry = entries[i];
                entries[i].BlendShapeInfluenceScore = scores[entry.BlendShapeIndex];
            }
        }

        public static void ResetInfluence(ExpressionEntry[] entries)
        {
            foreach (var entry in entries)
            {
                entry.WillMoveCurrentSelectedVertex = false;
                entry.BlendShapeInfluenceScore = 0;
            }
        }
    }

    internal static class ExpressionEntrySorter
    {
        public static void SortInPlace(ExpressionEntry[] entries, List<ExpressionEditorService.SortRule> sortRule)
        {
            var sortRuleArray = sortRule.ToArray().Reverse();

            Array.Sort(entries, (a, b) =>
            {
                foreach (var rule in sortRuleArray)
                {
                    var comparison = rule.Key switch
                    {
                        ExpressionEditorService.SortKey.WillMoveCurrentSelectedVertex => a.WillMoveCurrentSelectedVertex.CompareTo(b.WillMoveCurrentSelectedVertex),
                        ExpressionEditorService.SortKey.IsFolder => a.IsFolder.CompareTo(b.IsFolder),
                        ExpressionEditorService.SortKey.BlendShapeInfluenceScore => a.BlendShapeInfluenceScore.CompareTo(b.BlendShapeInfluenceScore),
                        ExpressionEditorService.SortKey.BlendShapeIndex => a.BlendShapeIndex.CompareTo(b.BlendShapeIndex),
                        ExpressionEditorService.SortKey.RegisteredDataFirstFrameValue => a.RegisteredFirstFrameDataOrZero().CompareTo(b.RegisteredFirstFrameDataOrZero()),
                        ExpressionEditorService.SortKey.IsRegistered => (a.RegisteredData != null).CompareTo(b.RegisteredData != null),
                        _ => 0
                    };

                    if (comparison != 0)
                    {
                        return rule.Ascending ? comparison : -comparison;
                    }
                }

                return 0;
            });
        }
    }
}
