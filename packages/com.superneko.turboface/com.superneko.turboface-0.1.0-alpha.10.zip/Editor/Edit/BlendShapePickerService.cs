using System;
using UniRx;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal class BlendShapePickerService : ReactiveService
    {
        internal sealed class VertexSelectionResult
        {
            public bool IsVertexPicked;
            public Vector3 PickedVertexPosition = Vector3.zero;
            public int PickedVertexIndex = -1;
        }

        public BlendShapePickerService(AvatarService avatarModel, PreviewService previewModel, ExpressionEditorService expressionEditorModel)
        {
            Logging.Trace("BlendShapePickerModel: Constructing BlendShapePickerModel.");

            this.avatarModel = avatarModel;
            this.previewModel = previewModel;
            this.expressionEditorModel = expressionEditorModel;
        }

        protected override void Initialize(CompositeDisposable d)
        {
            Logging.Trace("BlendShapePickerModel: Initialize");

            var currentAvatarFaceSMR = Observable.CombineLatest(avatarModel.FaceSMR, previewModel.PreviewFaceSMR, (originalSMR, previewSMR) => previewSMR ?? originalSMR);

            InfluenceData = currentAvatarFaceSMR.Select(smr =>
            {
                if (smr != null)
                {
                    var data = BlendShapeInfluenceData.FromSkinnedMeshRenderer(smr, 0.001f);
                    return data;
                }
                else
                {
                    return null;
                }
            }).ToReadOnlyReactiveProperty().AddTo(d);

            Pickable = InfluenceData.Select(influenceData =>
            {
                return influenceData != null;
            }).ToReadOnlyReactiveProperty().AddTo(d);

            Logging.Trace("BlendShapePickerModel: Creating TempCollider reactive property.");

            // TODO: Observe Transform
            var timer = Observable.Interval(TimeSpan.FromSeconds(5)).Select(_ => (int)(Time.realtimeSinceStartup / 5)).Distinct();

            timer.Subscribe(_ =>
            {
                Logging.Trace("BlendShapePickerModel: TempCollider timer tick.");
            }).AddTo(d);

            tempCollider = Observable.CombineLatest(timer, currentAvatarFaceSMR, (_, smr) => smr).Select((smr) =>
            {
                Logging.Trace("BlendShapePickerModel: Updating TempCollider.");

                if (tempCollider != null && tempCollider.Value != null)
                {
                    Logging.Trace("Disposing previous temp collider.");
                    UnityEngine.Object.DestroyImmediate(tempCollider.Value.sharedMesh);
                    UnityEngine.Object.DestroyImmediate(tempCollider.Value.gameObject);
                }

                if (smr == null)
                {
                    Logging.Trace("BlendShapePickerModel: No SkinnedMeshRenderer found. TempCollider will be null.");
                    return null;
                }

                Logging.Trace("Creating temp collider.");

                var bakedMesh = new Mesh();

                smr.BakeMesh(bakedMesh);

                var go = new GameObject("~tempCollider");
                go.hideFlags = HideFlags.HideAndDontSave;
                var tempColliderComponent = go.AddComponent<MeshCollider>();

                tempColliderComponent.sharedMesh = bakedMesh;
                tempColliderComponent.transform.SetPositionAndRotation(
                    smr.transform.position,
                    smr.transform.rotation);

                Logging.Trace("Temp collider created.");

                return tempColliderComponent;
            }).ToReadOnlyReactiveProperty().AddTo(d);
        }

        protected override void OnDisposed()
        {
            if (tempCollider?.Value == null)
            {
                return;
            }

            if (tempCollider.Value.sharedMesh != null)
            {
                UnityEngine.Object.DestroyImmediate(tempCollider.Value.sharedMesh);
            }

            UnityEngine.Object.DestroyImmediate(tempCollider.Value.gameObject);
        }

        PreviewService previewModel;
        AvatarService avatarModel;
        ExpressionEditorService expressionEditorModel;

        public ReadOnlyReactiveProperty<bool> Picking => picking.ToReadOnlyReactiveProperty();

        public ReadOnlyReactiveProperty<bool> Pickable { get; private set; } = null!;
        public ReadOnlyReactiveProperty<BlendShapeInfluenceData?> InfluenceData { get; private set; } = null!;

        public ReadOnlyReactiveProperty<VertexSelectionResult?> PickResult => pickResult.ToReadOnlyReactiveProperty();

        readonly ReactiveProperty<bool> picking = new(false);
        readonly AlwaysNotifyReactiveProperty<VertexSelectionResult?> pickResult = new(null);
        ReadOnlyReactiveProperty<MeshCollider?> tempCollider = null!;

        public bool StartPicking()
        {
            if (!Pickable.Value)
            {
                Logging.Info("BlendShapePickerModel: Cannot start picking because Pickable is false.");
                return false;
            }

            Logging.Trace("BlendShapePickerModel: StartPicking called. Setting picking to true.");

            picking.Value = true;
            return true;
        }

        public bool StopPicking()
        {
            Logging.Trace("BlendShapePickerModel: StopPicking called. Setting picking to false.");
            picking.Value = false;
            return false;
        }

        public void Pick(Vector2 mousePosition)
        {
            StopPicking();

            Ray ray = HandleUtility.GUIPointToWorldRay(mousePosition);

            if (InfluenceData.Value == null)
            {
                Logging.Info("BlendShapePickerModel: Cannot pick because InfluenceData is null.");
                return;
            }

            if (tempCollider.Value == null)
            {
                Logging.Info("BlendShapePickerModel: Cannot pick because TempCollider is null.");
                return;
            }

            if (tempCollider.Value.Raycast(ray, out RaycastHit hit, 1000f))
            {
                int triIndex = hit.triangleIndex;

                // Get nearest vertex
                var mesh = tempCollider.Value.sharedMesh;
                var triangles = mesh.triangles;
                var vertices = mesh.vertices;
                int v0 = triangles[triIndex * 3 + 0];
                int v1 = triangles[triIndex * 3 + 1];
                int v2 = triangles[triIndex * 3 + 2];
                float d0 = (hit.point - tempCollider.Value.transform.TransformPoint(vertices[v0])).sqrMagnitude;
                float d1 = (hit.point - tempCollider.Value.transform.TransformPoint(vertices[v1])).sqrMagnitude;
                float d2 = (hit.point - tempCollider.Value.transform.TransformPoint(vertices[v2])).sqrMagnitude;
                int nearestVertex = v0;
                if (d1 < d0 && d1 < d2)
                {
                    nearestVertex = v1;
                }
                else if (d2 < d0 && d2 < d1)
                {
                    nearestVertex = v2;
                }

                Logging.Info($"Picked vertex index: {nearestVertex}");

                var result = new VertexSelectionResult
                {
                    IsVertexPicked = true,
                    PickedVertexPosition = tempCollider.Value.transform.TransformPoint(vertices[nearestVertex]),
                    PickedVertexIndex = nearestVertex
                };
                pickResult.Value = result;
                expressionEditorModel.ChangeSelectedVertex(nearestVertex);
            }
            else
            {
                Logging.Info("No vertex picked.");
                pickResult.Value = null;
                expressionEditorModel.ChangeSelectedVertex(-1);
            }
        }

        public void ClearPickedVertex()
        {
            pickResult.Value = null;
            expressionEditorModel.ChangeSelectedVertex(-1);
        }
    }
}
