using System.Collections.Generic;
using UniRx;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{

    internal class ModelState : ScriptableSingleton<ModelState>
    {
        public ReactiveProperty<bool> Debug = new(false);
    }

    internal sealed class ServiceRoot
    {
        static ServiceRoot? _instance;

        public static ServiceRoot Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new ServiceRoot();
                    _instance.Initialize();
                }

                return _instance;
            }
        }

        ModelState? _state;

        ModelState State
        {
            get
            {
                if (_state == null)
                {
                    _state = ModelState.instance;
                }

                return _state;
            }
        }

        ServiceRoot()
        {
            Logging.Trace("Model: Constructing Model.");

            AvatarService = new AvatarService();

            ExpressionEditorService = new ExpressionEditorService(AvatarService);

            PreviewService = new PreviewService(
                ExpressionEditorService.EntriesAnimationAspect,
                AvatarService.DefaultBlendShapeWeights,
                AvatarService.AvatarRoot,
                AvatarService.FaceSMR,
                ExpressionEditorService.InfluenceData
                );

            BlendShapePickerService = new BlendShapePickerService(AvatarService, PreviewService, ExpressionEditorService);

            ExpressionEntrySearchService = new ExpressionEntrySearchService(ExpressionEditorService.EntriesSetAspect);
        }

        public void Initialize()
        {
            Logging.Trace("Model: Initializing Model.");

            AvatarService.Initialize();
            ExpressionEditorService.Initialize();
            PreviewService.Initialize();
            BlendShapePickerService.Initialize();
            ExpressionEntrySearchService.Initialize();

            AssemblyReloadEvents.beforeAssemblyReload += () =>
            {
                AvatarService.Dispose();
                ExpressionEditorService.Dispose();
                PreviewService.Dispose();
                BlendShapePickerService.Dispose();
                ExpressionEntrySearchService.Dispose();
            };
        }

        internal BlendShapePickerService BlendShapePickerService { get; }
        internal PreviewService PreviewService { get; }
        internal AvatarService AvatarService { get; }
        internal ExpressionEditorService ExpressionEditorService { get; }
        internal ExpressionEntrySearchService ExpressionEntrySearchService { get; }

        internal ReadOnlyReactiveProperty<bool> Debug => State.Debug.ToReadOnlyReactiveProperty();

        internal bool SetDebug(bool debug)
        {
            if (State.Debug.Value == debug)
            {
                return debug;
            }

            State.Debug.Value = debug;

            return debug;
        }
    }
}
