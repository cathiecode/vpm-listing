using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Edit
{
    internal sealed class SearchPopupController
    {
        const string SearchFieldControlName = "com.superneko.TurboFace.Editor.Edit.View.SearchField";
        Rect searchFieldRect = Rect.zero;

        public void DrawAndHandleOpen(ServiceRoot model)
        {
            GUI.SetNextControlName(SearchFieldControlName);
            EditorGUILayout.TextField("Search", GUILayout.Height(30));

            if (Event.current.type == EventType.Repaint)
            {
                searchFieldRect = GUILayoutUtility.GetLastRect();
            }

            if (GUI.GetNameOfFocusedControl() != SearchFieldControlName)
            {
                return;
            }

            GUI.FocusControl(null);

            var activator = searchFieldRect;
            activator.y -= searchFieldRect.height;
            ExpressionEntrySearchWindow.Open(activator, model, model.ExpressionEditorService.Expression.Value);
        }
    }
}
