namespace com.superneko.TurboFace.Editor
{
    internal static class L
    {
        public static string M(string key)
        {
            return Localization.GetTranslated(MessageKey.Get(key));
        }
    }
}
