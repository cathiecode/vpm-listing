using UnityEditor;

namespace com.superneko.TurboFace.Editor.Settings
{
    class TurboFaceSettingsProvider : SettingsProvider
    {
        UnityEditor.Editor cachedEditor;

        public TurboFaceSettingsProvider()
            : base("Project/TurboFace", SettingsScope.Project) { }

        public static bool IsSettingsAvailable()
        {
            return true;
        }

        public override void OnGUI(string searchContext)
        {
            var settings = TurboFaceSettings.instance;

            EditorGUI.BeginChangeCheck();

            var currentLanguageIndex = System.Array.IndexOf(Localizer.AvailableLanguages, settings.Language);
            var newLanguageIndex = EditorGUILayout.Popup(currentLanguageIndex, Localizer.AvailableLanguages);
            var logLevel = (LogLevel)EditorGUILayout.EnumPopup("Log Level", settings.LogLevel);

            if (EditorGUI.EndChangeCheck())
            {
                settings.Language = Localizer.AvailableLanguages[newLanguageIndex];
                settings.LogLevel = logLevel;
                settings.Save();
            }
        }

        // Register the SettingsProvider
        [SettingsProvider]
        public static SettingsProvider CreateTurboFaceSettingsProvider()
        {
            return new TurboFaceSettingsProvider();
        }
    }
}
