using UnityEditor;

namespace com.superneko.TurboFace.Editor.Settings
{
    [FilePath("TurboFaceGlobalSettings.asset", FilePathAttribute.Location.PreferencesFolder)]
    internal class TurboFaceSettings : ScriptableSingleton<TurboFaceSettings>
    {
        string lang = "ja-JP";
        public string Language
        {
            get => lang;
            set {
                lang = value;
                Localization.SetLanguage(lang);
            }
        }

        public LogLevel LogLevel = LogLevel.Info;

        public void Save()
        {
            Save(true);
        }
    }
}