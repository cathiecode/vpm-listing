using System;
using UniRx;
using UnityEditor;
using UnityEngine;

namespace com.superneko.TurboFace.Editor
{
    internal class ObservableEditorEvents
    {
        readonly static ReactiveProperty<PlayModeStateChange> playMode = new(EditorApplication.isPlaying ? PlayModeStateChange.EnteredPlayMode : PlayModeStateChange.EnteredEditMode);
        public static IReadOnlyReactiveProperty<PlayModeStateChange> PlayMode => playMode;

        readonly static Subject<Unit> hierarchyChanged = new();
        public static IObservable<Unit> HierarchyChanged => hierarchyChanged;

        readonly static Subject<Unit> projectChanged = new();
        public static IObservable<Unit> ProjectChanged => projectChanged;

        [InitializeOnLoadMethod]
        static void Initialize()
        {
            EditorApplication.playModeStateChanged += (state) =>
            {
                playMode.Value = state;
            };

            EditorApplication.hierarchyChanged += () =>
            {
                hierarchyChanged.OnNext(Unit.Value);
            };

            EditorApplication.projectChanged += () =>
            {
                projectChanged.OnNext(Unit.Value);
            };
        }
    }
}
