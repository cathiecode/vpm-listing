#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    internal class GestureWeightWillOverridedMisconfiguration : IConflictingMisconfiguration<Expression>
    {
        public Expression Target { get; private set; }
        public MessageKey Message { get; private set; }

        public Expression ConflictingConfiguration { get; private set; }

        public GestureWeightWillOverridedMisconfiguration(Expression target, Expression conflictingConfiguration, HandData handData)
        {
            Target = target;
            ConflictingConfiguration = conflictingConfiguration;

            if (handData == HandData.Left)
            {
                Message = MessageKey.Get("setup.expression.gesture-weight.misconfiguration-will-overided.left");
            }
            else
            {
                Message = MessageKey.Get("setup.expression.gesture-weight.misconfiguration-will-overided.right");
            }
        }
    }
}
