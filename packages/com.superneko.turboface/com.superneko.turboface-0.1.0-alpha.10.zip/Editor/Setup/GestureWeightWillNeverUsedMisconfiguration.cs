#nullable enable

namespace com.superneko.TurboFace.Editor.Setup
{
    internal class GestureWeightWillNeverBeUsedMisconfiguration : IMisconfiguration<Expression>
    {
        public MessageKey Message { get; private set; }
    
        public Expression Target { get; private set; }

        public GestureWeightWillNeverBeUsedMisconfiguration(Expression target, HandData handData)
        {
            Target = target;

            if (handData == HandData.Left)
            {
                Message = MessageKey.Get("setup.expression.gesture-weight.will-never-used.left");
            } else
            {
                Message = MessageKey.Get("setup.expression.gesture-weight.will-never-used.right");
            }
        }
    }
}
