namespace com.superneko.TurboFace.Editor.Setup
{
    internal interface IConflictingMisconfiguration<T> : IMisconfiguration<T>
    {
        T ConflictingConfiguration { get; }
    }
}
