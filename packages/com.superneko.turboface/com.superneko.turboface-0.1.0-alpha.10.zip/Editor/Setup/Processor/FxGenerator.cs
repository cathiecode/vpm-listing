using System.Data;
using System.Linq;
using Anatawa12.AnimatorControllerAsACode.Framework;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    using System;
    using Runtime.Setup;

    internal class FxGenerator
    {
        readonly AccParameter<bool> isLocal;
        readonly AccParameter<int> expressionSelectL;
        readonly AccParameter<int> expressionSelectR;
        readonly AccParameter<int> expressionPreselect;
        readonly AccParameter<bool> swapHands;
        readonly AccParameter<bool> disableLeftHand;
        readonly AccParameter<bool> disableRightHand;
        readonly AccParameter<bool> expressionLockEnable;
        readonly AccParameter<bool> expressionPrelockEnable;
        readonly AccParameter<int> expressionSetParameter;
        readonly AccParameter<int> expressionParameter;
        readonly AccParameter<float> gestureLeftWeightParameter;
        readonly AccParameter<float> gestureRightWeightParameter;
        readonly AccParameter<float> oneParameter;

        readonly AnimatorController animatorController;
        readonly Acc acc;
        readonly IAssetJar assetJar;

        public FxGenerator(IAssetJar assetJar)
        {
            var originalAnimatorController = TurboFaceUtils.LoadAssetByGUID<AnimatorController>("2ecac71e55776a84e81f3db4d300ddef");

            if (originalAnimatorController == null)
            {
                throw new LogicException("Failed to load original AnimatorController");
            }

            var duplicatedAnimatorController = new UnityObjectDuplicateContext()
                .AddSkipType(typeof(AnimationClip))
                .AddSkipType(typeof(AvatarMask))
                .AddDuplicatedObjectsTo(assetJar)
                .StartDuplication(originalAnimatorController);

            if (duplicatedAnimatorController == null)
            {
                throw new LogicException("Failed to duplicate AnimatorController");
            }

            animatorController = duplicatedAnimatorController;

            acc = new Acc("TurboFaceFX", animatorController, new AccConfig(null), assetJar.AsAacAssetSaver());

            isLocal = acc.BoolParameter("IsLocal");
            expressionSelectL = acc.IntParameter(Parameters.EM_EMOTE_SELECT_L.Name);
            expressionSelectR = acc.IntParameter(Parameters.EM_EMOTE_SELECT_R.Name);
            expressionPreselect = acc.IntParameter(Parameters.EM_EMOTE_PRESELECT.Name);
            swapHands = acc.BoolParameter(Parameters.EM_EMOTE_SWAP_LR.Name);
            disableLeftHand = acc.BoolParameter(Parameters.CN_EMOTE_SELECT_DISABLE_LEFT.Name);
            disableRightHand = acc.BoolParameter(Parameters.CN_EMOTE_SELECT_DISABLE_RIGHT.Name);
            expressionLockEnable = acc.BoolParameter(Parameters.CN_EMOTE_LOCK_ENABLE.Name);
            expressionPrelockEnable = acc.BoolParameter(Parameters.CN_EMOTE_PRELOCK_ENABLE.Name);
            expressionSetParameter = acc.IntParameter(Parameters.EM_EMOTE_PATTERN.Name);
            expressionParameter = acc.IntParameter(Parameters.SYNC_EM_EMOTE.Name);
            gestureLeftWeightParameter = acc.FloatParameter(Parameters.GestureLeftWeight.Name);
            gestureRightWeightParameter = acc.FloatParameter(Parameters.GestureRightWeight.Name);
            oneParameter = acc.FloatParameter(Parameters.One.Name, 1f);
            this.assetJar = assetJar;
        }

        public AnimatorController Generate(CompiledSetup setup)
        {
            new ObjectWalker().Walk(animatorController, (obj) =>
            {
                switch (obj)
                {
                    case AnimatorControllerLayer layer:
                        var replaceTargetBehaviours = layer.stateMachine.behaviours.Where(b => b is TurboFaceTemplateReplaceTargetStateMachineBehaviour);

                        foreach (var replaceTargetBehaviour in replaceTargetBehaviours)
                        {
                            var behaviour = (TurboFaceTemplateReplaceTargetStateMachineBehaviour)replaceTargetBehaviour;

                            switch (behaviour.Name)
                            {
                                case "FaceEmoteControl":
                                    var accLayer = new AccLayer(layer, acc, assetJar.AsAacAssetSaver());
                                    GenerateFaceEmoteControlLayer(accLayer);
                                    accLayer.SaveToAsset();
                                    break;
                                case "FaceEmoteSetControl":
                                    var accLayer2 = new AccLayer(layer, acc, assetJar.AsAacAssetSaver());
                                    GenerateFaceEmoteSetControlLayer(accLayer2, setup);
                                    accLayer2.SaveToAsset();
                                    break;
                                case "FaceEmotePlayer":
                                    var accLayer3 = new AccLayer(layer, acc, assetJar.AsAacAssetSaver());
                                    var playerStateMachineCandidates = layer.stateMachine.stateMachines.Where(child => child.stateMachine.behaviours.Count(b => b is TurboFaceTemplateReplaceTargetStateMachineBehaviour behaviour && behaviour.Name == "FaceEmotePlayer.Player") != 0).ToArray();

                                    if (playerStateMachineCandidates.Length != 1)
                                    {
                                        throw new LogicException("FaceEmotePlayer template does not contain or contains multiple FaceEmotePlayer.Player sub state machine.");
                                    }

                                    var playerStateMachine = playerStateMachineCandidates[0].stateMachine;

                                    var accStateMachine = accLayer3.ExistingSubStateMachine(playerStateMachine);

                                    GenerateFaceEmotePlayerLayerStateMachine(accStateMachine, setup);

                                    accStateMachine.SaveToAsset();
                                    accLayer3.SaveToAsset();
                                    break;
                                case "DefaultFace":
                                    var accLayer4 = new AccLayer(layer, acc, assetJar.AsAacAssetSaver());
                                    GenerateDefaultFaceLayer(accLayer4, setup);
                                    accLayer4.SaveToAsset();
                                    break;
                            }
                        }
                        break;
                    case AnimatorState state:
                        var replaceTargetBehaviours2 = state.behaviours.Where(b => b is TurboFaceTemplateReplaceTargetStateMachineBehaviour);

                        foreach (var replaceTargetBehaviour in replaceTargetBehaviours2)
                        {
                            var behaviour = (TurboFaceTemplateReplaceTargetStateMachineBehaviour)replaceTargetBehaviour;

                            switch (behaviour.Name)
                            {
                                case "BlinkAnimation":
                                    state.motion = setup.BlinkingEnableAnimation;
                                    break;
                            }
                        }
                        break;
                }
            });

            return animatorController;
        }

        void GenerateDefaultFaceLayer(AccLayer layer, CompiledSetup setup)
        {
            layer.NewState($"DefaultFace")
                .WithAnimation(setup.DefaultFaceAnimation);
        }

        void GenerateFaceEmoteControlLayer(AccLayer layer)
        {
            var init = layer.NewState("Init").OnGridAt(0, 0).AsDefaultState();

            var gridY = 0;

            foreach (var swap in new[] { false, true })
            {
                foreach (var disableLeft in new[] { false, true })
                {
                    foreach (var disableRight in new[] { false, true })
                    {
                        var name = $"Swap={swap}, DisableLeft={disableLeft}, DisableRight={disableRight}";
                        var stateMachine = layer.NewSubStateMachine(name).OnGridAt(1, gridY++);

                        init.TransitionsTo(stateMachine)
                            .When(
                                isLocal.IsTrue()
                                    .And(swapHands.IsEqualTo(swap))
                                    .And(disableLeftHand.IsEqualTo(disableLeft))
                                    .And(disableRightHand.IsEqualTo(disableRight))
                            );

                        GenerateFaceEmoteControlLayerSubStateMachine(stateMachine, swap, disableLeft, disableRight);

                        stateMachine.TransitionsToExit()
                            .When(isLocal.IsFalse());

                        stateMachine.TransitionsToExit()
                            .When(swapHands.IsNotEqualTo(swap));

                        stateMachine.TransitionsToExit()
                            .When(disableLeftHand.IsNotEqualTo(disableLeft));

                        stateMachine.TransitionsToExit()
                            .When(disableRightHand.IsNotEqualTo(disableRight));
                    }
                }
            }
        }

        void GenerateFaceEmoteControlLayerSubStateMachine(AccStateMachine subStateMachine, bool swap, bool disableLeft, bool disableRight)
        {
            subStateMachine.TransitionsTo(subStateMachine)
                .When(
                    isLocal.IsTrue()
                        .And(swapHands.IsEqualTo(swap))
                        .And(disableLeftHand.IsEqualTo(disableLeft))
                        .And(disableRightHand.IsEqualTo(disableRight))
                );

            foreach (var actualLeftHand in GestureExt.Enumerate())
            {
                var leftHandSubStateMachine = subStateMachine.NewSubStateMachine($"L={actualLeftHand.Name()}");

                subStateMachine.EntryTransitionsTo(leftHandSubStateMachine)
                    .When(expressionSelectL.IsEqualTo(actualLeftHand.Index()));

                leftHandSubStateMachine.TransitionsTo(leftHandSubStateMachine)
                    .When(expressionSelectL.IsEqualTo(actualLeftHand.Index()));

                leftHandSubStateMachine.TransitionsToExit()
                    .When(expressionSelectL.IsNotEqualTo(actualLeftHand.Index()));

                foreach (var actualRightHand in GestureExt.Enumerate())
                {
                    var leftHand = swap ? actualRightHand : actualLeftHand;
                    var rightHand = swap ? actualLeftHand : actualRightHand;

                    if (disableLeft)
                    {
                        if (swap)
                        {
                            rightHand = Gesture.Neutral;
                        }
                        else
                        {
                            leftHand = Gesture.Neutral;
                        }
                    }

                    if (disableRight)
                    {
                        if (swap)
                        {
                            leftHand = Gesture.Neutral;
                        }
                        else
                        {
                            rightHand = Gesture.Neutral;
                        }
                    }


                    var convertedGestureCombination = new GestureCombination(leftHand, rightHand);

                    var name = $"Actual(L={actualLeftHand.Name()}, R={actualRightHand.Name()}) => Converted({convertedGestureCombination})";

                    var state = leftHandSubStateMachine.NewState(name);

                    leftHandSubStateMachine.EntryTransitionsTo(state)
                        .When(expressionSelectR.IsEqualTo(actualRightHand.Index()));

                    state.TransitionsToExit()
                        .When(
                            expressionSelectR.IsNotEqualTo(actualRightHand.Index())
                                .And(expressionLockEnable.IsFalse())
                                .And(expressionPrelockEnable.IsFalse())
                        );

                    state.TransitionsToExit()
                        .When(
                            expressionSelectL.IsNotEqualTo(actualLeftHand.Index())
                                .And(expressionLockEnable.IsFalse())
                                .And(expressionPrelockEnable.IsFalse())
                        );

                    var behaviour = state.AddStateMachineBehaviour<VRCAvatarParameterDriver>();

                    behaviour.parameters = new[]
                    {
                        new VRC.SDKBase.VRC_AvatarParameterDriver.Parameter
                        {
                            name = expressionPreselect.Name,
                            value = convertedGestureCombination.Index(),
                            type = VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set,
                        },
                    }.ToList();

                    behaviour.localOnly = true;
                }
            }
        }

        void GenerateFaceEmoteSetControlLayer(AccLayer layer, CompiledSetup setup)
        {
            var init = layer.NewState("Init").AsDefaultState();

            foreach (var expressionSet in setup.EnumerateExpressionSet())
            {
                var stateMachine = layer.NewSubStateMachine($"EmoteSet {expressionSet.Index}");

                init.TransitionsTo(stateMachine)
                    .When(isLocal.IsTrue().And(expressionSetParameter.IsEqualTo(expressionSet.Index)));

                GenerateFaceEmoteSetControlLayerSubStateMachine(stateMachine, expressionSet.Index, expressionSet);

                stateMachine.TransitionsToExit()
                    .When(expressionSetParameter.IsNotEqualTo(expressionSet.Index));
            }
        }

        void GenerateFaceEmoteSetControlLayerSubStateMachine(AccStateMachine subStateMachine, int setIndex, CompiledSetup.ExpressionSet expressionSet)
        {
            subStateMachine.TransitionsTo(subStateMachine)
                .When(isLocal.IsTrue().And(expressionSetParameter.IsEqualTo(setIndex)));

            foreach (var gestureCombination in GestureCombination.Enumerate())
            {
                var gestureIndex = gestureCombination.Index();

                var expressionInterSetIndex = expressionSet.GetExpressionInterSetIndexForCombination(gestureCombination);

                var state = subStateMachine.NewState($"{gestureCombination} => {expressionInterSetIndex}");

                var behaviour = state.AddStateMachineBehaviour<VRCAvatarParameterDriver>();

                behaviour.parameters = new[]
                {
                        new VRC.SDKBase.VRC_AvatarParameterDriver.Parameter
                        {
                            name = expressionParameter.Name,
                            value = expressionInterSetIndex,
                            type = VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set,
                        },
                    }.ToList();

                behaviour.localOnly = true;

                subStateMachine.EntryTransitionsTo(state)
                    .When(expressionPreselect.IsEqualTo(gestureIndex));

                state.TransitionsToExit()
                    .When(expressionSetParameter.IsNotEqualTo(setIndex));

                state.TransitionsToExit()
                    .When(expressionPreselect.IsNotEqualTo(gestureIndex));
            }
        }

        void GenerateFaceEmotePlayerLayerStateMachine(AccStateMachine stateMachine, CompiledSetup compiledSetup)
        {
            foreach (var expression in compiledSetup.EnumerateExpression())
            {
                var state = stateMachine
                    .NewState(expression.AnimationClip != null ? expression.AnimationClip.name.Replace(".", "_") + Guid.NewGuid().ToString("N") : "EMPTY");

                stateMachine.EntryTransitionsTo(state)
                    .When(expressionParameter.IsEqualTo(expression.InterSetIndex));

                state.TransitionsToExit()
                    .WithTransitionDurationSeconds(0.1f)
                    .When(expressionParameter.IsNotEqualTo(expression.InterSetIndex));


                state.AddStateMachineBehaviour<VRCAvatarParameterDriver>().parameters = new[]
                {
                    new VRC.SDKBase.VRC_AvatarParameterDriver.Parameter
                    {
                        name = Parameters.CN_BLINK_ENABLE.Name,
                        value = expression.CompatibleWithBlinking ? 1 : 0,
                        type = VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set,
                    },
                    new VRC.SDKBase.VRC_AvatarParameterDriver.Parameter
                    {
                        name = Parameters.CN_MOUTH_MORPH_CANCEL_ENABLE.Name,
                        value = expression.CancelMouthMorphing ? 1 : 0,
                        type = VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set,
                    },
                }.ToList();

                var trackingControl = state.AddStateMachineBehaviour<VRCAnimatorTrackingControl>();

                trackingControl.trackingEyes = expression.CompatibleWithEyeMovements ? VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.Tracking : VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.Animation;
                trackingControl.trackingMouth = expression.CompatibleWithLipSync ? VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.Tracking : VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.Animation;

                if (expression.AnimationClip != null)
                {
                    state.WithAnimation(expression.AnimationClip);
                }

                switch (expression.Blending)
                {
                    case CompiledSetup.TwoVariableBlending blending:
                        var additiveMixerBlendTree = new BlendTree
                        {
                            useAutomaticThresholds = false,
                            blendType = BlendTreeType.Direct,
                            blendParameter = oneParameter.Name,
                            children = new[]
                            {
                                new ChildMotion
                                {
                                    motion = blending.AdditiveAnimationClipX,
                                    directBlendParameter = blending.ParameterX.Name,
                                    threshold = 0,
                                },
                                new ChildMotion
                                {
                                    motion = blending.AdditiveAnimationClipY,
                                    directBlendParameter = blending.ParameterY.Name,
                                    threshold = 0,
                                },
                            }
                        };

                        var rootBlendTree = new BlendTree
                        {
                            useAutomaticThresholds = false,
                            blendType = BlendTreeType.Direct,
                            children = new[]
                            {
                                new ChildMotion
                                {
                                    motion = expression.AnimationClip,
                                    directBlendParameter = oneParameter.Name,
                                },
                                new ChildMotion
                                {
                                    motion = additiveMixerBlendTree,
                                    directBlendParameter = oneParameter.Name,
                                },
                            }
                        };

                        assetJar.AddAsset(additiveMixerBlendTree);
                        assetJar.AddAsset(rootBlendTree);

                        state.WithAnimation(rootBlendTree);

                        break;
                    case CompiledSetup.OneVariableBlending blending:
                        var oneVariableBlendTree = new BlendTree
                        {
                            blendType = BlendTreeType.Simple1D,
                            blendParameter = blending.Parameter.Name,
                            children = new[]
                            {
                                new ChildMotion
                                {
                                    motion = expression.AnimationClip,
                                    threshold = 0,
                                },
                                new ChildMotion
                                {
                                    motion = blending.AnimationClipForFullBlend,
                                    threshold = 1,
                                },
                            },
                        };

                        assetJar.AddAsset(oneVariableBlendTree);

                        state.WithAnimation(oneVariableBlendTree);

                        break;

                    case null:
                        state.WithAnimation(expression.AnimationClip);
                        break;
                }
            }
        }
    }
}
