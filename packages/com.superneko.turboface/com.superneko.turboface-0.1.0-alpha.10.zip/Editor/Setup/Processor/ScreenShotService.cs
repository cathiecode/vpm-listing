using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UniRx;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.Processor
{
    class ScreenShotService
    {
        public class Request
        {
            public Vector3 CameraPosition;
            public Quaternion CameraRotation;
            public int Width;
            public int Height;
            public float OrthoSize;
            public Action? OnPreShot;
            public Action? OnPostShot;
        }

        readonly Queue<(Request, WeakRefCount<ReactiveProperty<Texture2D?>>)> queue = new();

        bool isProcessing = false;

        public RefCount<ReactiveProperty<Texture2D?>> RequestScreenShot(Request request, RefCount<ReactiveProperty<Texture2D?>>? refCount = null)
        {
            if (refCount == null)
            {
                var reactiveProperty = new ReactiveProperty<Texture2D?>(null);

                refCount = new RefCount<ReactiveProperty<Texture2D?>>(reactiveProperty, (v) =>
                {
                    if (v.Value != null)
                    {
                        UnityEngine.Object.DestroyImmediate(v.Value);
                    }
                });
            }

            queue.Enqueue((request, refCount.ToWeak()));

            Schedule();

            return refCount;
        }

        void Schedule()
        {
            if (isProcessing) return;

            isProcessing = true;

            Process();
        }

        void Process()
        {
            if (queue.Count == 0)
            {
                Logging.Trace($"All requested screenshot processed!");
                isProcessing = false;
                return;
            }

            Logging.Trace($"Processing screen shot request. remaining: {queue.Count}");

            var (request, refCount) = queue.Dequeue();

            // If the refCount is already disposed, skip processing.
            if (refCount.Value == null)
            {
                Process();
                return;
            }

            try
            {
                request.OnPreShot?.Invoke();

                try
                {
                    var texture = TakeScreenShot(request);
                    refCount.Value.Value = texture;
                }
                finally
                {
                    request.OnPostShot?.Invoke();
                }
            }
            catch (System.Exception ex)
            {
                // Handle exception if needed
                Debug.LogError($"ScreenShotService failed to take screenshot: {ex}");
            }

            EditorApplication.delayCall += Process;
        }

        Texture2D TakeScreenShot(Request request)
        {
            using var cameraGO = new GameObject("ScreenShotCamera").AsTemporary();

            var camera = cameraGO.Object.AddComponent<Camera>();
            camera.transform.SetPositionAndRotation(request.CameraPosition, request.CameraRotation);
            camera.orthographic = true;
            camera.orthographicSize = request.OrthoSize;
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = Color.clear;

            using var renderTexture = new RenderTexture(request.Width, request.Height, 24).AsTemporary();
            camera.targetTexture = renderTexture.Object;

            var texture = new Texture2D(request.Width, request.Height, TextureFormat.ARGB32, false);
            camera.Render();

            var prevActive = RenderTexture.active;
            RenderTexture.active = renderTexture;
            texture.ReadPixels(new Rect(0, 0, request.Width, request.Height), 0, 0);
            texture.Apply();
            RenderTexture.active = prevActive;

            camera.targetTexture = null;

            return texture;
        }
    }
}
