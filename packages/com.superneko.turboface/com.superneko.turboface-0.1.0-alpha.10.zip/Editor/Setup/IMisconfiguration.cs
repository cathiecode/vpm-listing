namespace com.superneko.TurboFace.Editor.Setup
{
    internal interface IMisconfiguration<T>
    {
        public T Target { get; }
        public MessageKey Message { get; }
    }
}
