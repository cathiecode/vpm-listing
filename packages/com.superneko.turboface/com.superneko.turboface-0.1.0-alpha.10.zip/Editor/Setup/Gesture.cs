using System.Collections.Generic;

namespace com.superneko.TurboFace.Editor.Setup
{
    internal enum Gesture
    {
        Neutral = 0,
        Fist = 1,
        OpenHand = 2,
        PointingUp = 3,
        Victory = 4,
        RockNRoll = 5,
        HandGun = 6,
        ThumbsUp = 7,
        Length = 8
    }

    internal static class GestureExt
    {
        public static string Name(this Gesture gesture)
        {
            return gesture switch
            {
                Gesture.Neutral => "Neutral",
                Gesture.Fist => "Fist",
                Gesture.OpenHand => "OpenHand",
                Gesture.PointingUp => "PointingUp",
                Gesture.Victory => "Victory",
                Gesture.RockNRoll => "RockNRoll",
                Gesture.HandGun => "HandGun",
                Gesture.ThumbsUp => "ThumbsUp",
                _ => throw new System.ArgumentOutOfRangeException(nameof(gesture), gesture, null)
            };
        }

        public static int Index(this Gesture gesture)
        {
            return (int)gesture;
        }

        public static Gesture FromData(GestureData gestureData)
        {
            return gestureData switch
            {
                GestureData.Neutral => Gesture.Neutral,
                GestureData.Fist => Gesture.Fist,
                GestureData.HandOpen => Gesture.OpenHand,
                GestureData.FingerPoint => Gesture.PointingUp,
                GestureData.Victory => Gesture.Victory,
                GestureData.RockNRoll => Gesture.RockNRoll,
                GestureData.HandGun => Gesture.HandGun,
                GestureData.ThumbsUp => Gesture.ThumbsUp,
                _ => throw new System.ArgumentOutOfRangeException(nameof(gestureData), gestureData, null)
            };
        }

        public static IEnumerable<Gesture> Enumerate()
        {
            for (int i = 0; i < (int)Gesture.Length; i++)
            {
                yield return (Gesture)i;
            }
        }
    }

    internal struct GestureCombination
    {
        readonly public Gesture LeftHand;
        readonly public Gesture RightHand;

        public GestureCombination(Gesture leftHand, Gesture rightHand)
        {
            LeftHand = leftHand;
            RightHand = rightHand;
        }

        public int Index()
        {
            return (int)LeftHand * (int)Gesture.Length + (int)RightHand;
        }

        public override string ToString()
        {
            return $"GestureCombination(L={LeftHand.Name()}, R={RightHand.Name()} GestureIndex={Index()})";
        }

        public static int CombinationCount()
        {
            return (int)Gesture.Length * (int)Gesture.Length;
        }

        public static IEnumerable<GestureCombination> Enumerate()
        {
            for (int leftHandIndex = 0; leftHandIndex < (int)Gesture.Length; leftHandIndex++)
            {
                for (int rightHandIndex = 0; rightHandIndex < (int)Gesture.Length; rightHandIndex++)
                {
                    yield return new GestureCombination((Gesture)leftHandIndex, (Gesture)rightHandIndex);
                }
            }
        }

        public static IEnumerable<GestureCombination> EnumerateWhenLeftHandIs(Gesture leftHand)
        {
            for (int rightHandIndex = 0; rightHandIndex < (int)Gesture.Length; rightHandIndex++)
            {
                yield return new GestureCombination(leftHand, (Gesture)rightHandIndex);
            }
        }

        public static IEnumerable<GestureCombination> EnumerateWhenRightHandIs(Gesture rightHand)
        {
            for (int leftHandIndex = 0; leftHandIndex < (int)Gesture.Length; leftHandIndex++)
            {
                yield return new GestureCombination((Gesture)leftHandIndex, rightHand);
            }
        }
    }
}
