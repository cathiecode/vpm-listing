namespace com.superneko.TurboFace.Editor.Setup
{
    internal class ExpressionGestureConditionWillAlwaysOverridedMisconfiguration : IConflictingMisconfiguration<Expression>
    {
        public MessageKey Message => MessageKey.Get("setup.expression.gesture.will-always-overrided");

        public Expression Target { get; private set; }
        public Expression ConflictingConfiguration { get; private set; }

        public ExpressionGestureConditionWillAlwaysOverridedMisconfiguration(Expression target, Expression conflictingConfiguration, HandData handData)
        {
            Target = target;
            ConflictingConfiguration = conflictingConfiguration;
        }
    }
}
