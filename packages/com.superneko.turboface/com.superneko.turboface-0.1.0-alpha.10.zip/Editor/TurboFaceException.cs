using System;

namespace com.superneko.TurboFace.Editor
{
    internal class TurboFaceException : ApplicationException
    {
        public MessageKey MessageKey { get; }

        public TurboFaceException(MessageKey messageKey) : base(Localization.GetTranslated(messageKey))
        {
            MessageKey = messageKey;
        }
    }
}
