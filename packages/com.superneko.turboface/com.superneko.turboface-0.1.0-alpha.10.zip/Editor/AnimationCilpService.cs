using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor
{
    internal static class AnimationClipService
    {
        public static AnimationClip? CreateNewClip(string? basePath)
        {
            var newPath = EditorUtility.SaveFilePanelInProject(
                "Create New AnimationClip",
                "New AnimationClip.anim",
                "anim",
                "Please enter a file name to save the animation clip to.",
                basePath
            );

            if (string.IsNullOrEmpty(newPath))
            {
                return null;
            }

            var newClip = new AnimationClip();
            AssetDatabase.CreateAsset(newClip, newPath);
            AssetDatabase.SaveAssets();

            return newClip;
        }

        public static AnimationClip? OpenClip(string? basePath)
        {
            var selectedPath = EditorUtility.OpenFilePanel("Select AnimationClip", basePath, "anim");

            if (string.IsNullOrEmpty(selectedPath))
            {
                return null;
            }

            if (!selectedPath.StartsWith(Application.dataPath))
            {
                EditorUtility.DisplayDialog("Invalid Selection", "Please select an AnimationClip inside this Unity project.", "OK");
                return null;
            }

            var relativePath = "Assets" + selectedPath.Substring(Application.dataPath.Length);
            var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(relativePath);

            return clip;
        }
    }
}
