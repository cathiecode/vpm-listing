#nullable enable

using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace com.superneko.TurboFace.Editor
{
    using Runtime.Setup;
    using Setup;
    using Setup.FaceEmoImporter;
    using Setup.HeuristicAnimatorControllerParser;

    public static class SetupLauncher
    {
        [MenuItem("GameObject/TurboFace/Open With TurboFace Setup", true, 0)]
        public static bool CanOpenWithTurboFaceSetup()
        {
            var selectedObject = Selection.activeObject;

            if (selectedObject is not GameObject go)
            {
                return false;
            }

            if (!go.TryGetComponent<VRCAvatarDescriptor>(out var descriptor))
            {
                return false;
            }

            return true;
        }

        [MenuItem("GameObject/TurboFace/Open With TurboFace Setup", priority = 0)]
        public static void OpenWithTurboFaceSetup()
        {
            var selectedObject = Selection.activeObject;

            if (selectedObject is not GameObject go)
            {
                Logging.Error("Please select a GameObject with an Animator component.");
                return;
            }

            if (!go.TryGetComponent<VRCAvatarDescriptor>(out var descriptor))
            {
                Logging.Error("Please select a GameObject with a VRCAvatarDescriptor component.");
                return;
            }

            if (go.GetComponentsInChildren<TurboFaceSetupComponent>().Length > 0)
            {
                TurboFaceSetupEditorWindow.ShowWindow(go.GetComponentInChildren<TurboFaceSetupComponent>());
                return;
            }

            SetupData? setupData = null;
            var hasFaceEmoPrefab = go.transform.Find("FaceEmoPrefab") != null;

            if (hasFaceEmoPrefab)
            {
                var result = FaceEmoSetupDataImporter.TryImportFromAvatar(descriptor);
                if (result.IsSuccess)
                {
                    var (importedSetupData, faceEmoWarnings) = result.Unwrap();

                    setupData = importedSetupData;

                    foreach (var warning in faceEmoWarnings)
                    {
                        Logging.Warn($"[FaceEmo Import] {warning}");
                    }

                    EditorUtility.DisplayDialog("TurboFace Setup", L.M("setup.launcher.imported-from-faceemo"), "OK");
                }
                else
                {
                    var error = result.UnwrapError();

                    if (error is PreconditionException pex)
                    {
                        EditorUtility.DisplayDialog("TurboFace Setup", Localization.GetTranslated(pex.MessageKey), "OK");
                    }
                    else
                    {
                        Logging.Error($"Failed to import from FaceEmo Prefab: {error}");
                        Debug.LogException(error);
                    }
                }
            }
            else
            {
                var fxRuntimeController = descriptor.baseAnimationLayers.First(layer => layer.type == VRCAvatarDescriptor.AnimLayerType.FX).animatorController;

                if (fxRuntimeController != null)
                {
                    var fxController = fxRuntimeController as AnimatorController;

                    if (fxController != null)
                    {
                        setupData = VRCHeuristicAnimatorControllerParser.Parse(fxController, descriptor);
                    }
                }
            }

            if (setupData == null)
            {
                EditorUtility.DisplayDialog("TurboFace Setup", L.M("setup.launcher.failed-to-import"), "OK");
                setupData = new SetupData();
            }

            var setupGameObject = new GameObject("TurboFaceSetup");
            setupGameObject.transform.SetParent(go.transform);
            setupGameObject.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            setupGameObject.transform.localScale = Vector3.one;

            var component = setupGameObject.AddComponent<TurboFaceSetupComponent>();
            component.SerializedSetupData = SetupSerializer.Serialize(setupData);

            TurboFaceSetupEditorWindow.ShowWindow(component);

            return;
        }
    }
}
