using JetBrains.Annotations;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

#nullable enable

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class AnimationClipFieldVisualElement : ReactiveVisualElement<IAssetReference<AnimationClip>>
    {
        public new class UxmlFactory : UxmlFactory<AnimationClipFieldVisualElement, UxmlTraits> { }

        ObjectField animationClipField;
        TranslatedButtonVisualElement editButton;

        public AnimationClipFieldVisualElement() : base()
        {
            var tree = UIDocumentLoader.Instance.Load("AnimationClipFieldVisualElement").CloneTree();

            animationClipField = tree.Q<ObjectField>("AnimationClip");

            animationClipField.RegisterCallback<ChangeEvent<Object>>(evt =>
            {
                if (ReactiveProperty != null)
                {
                    var newValue = evt.newValue as AnimationClip;

                    if (newValue != null)
                    {
                        ReactiveProperty.Value = new AssetReference<AnimationClip>(newValue);
                    }
                    else
                    {
                        ReactiveProperty.Value = AssetReference<AnimationClip>.Empty;
                    }
                }
            });

            tree.Q<TranslatedButtonVisualElement>("CreateNewButton").RegisterCallback<ClickEvent>(ev =>
            {
                if (ReactiveProperty != null)
                {
                    var path = "Assets";

                    if (ReactiveProperty.Value.Instance != null)
                    {
                        var currentPath = AssetDatabase.GetAssetPath(ReactiveProperty.Value.Instance);

                        if (!string.IsNullOrEmpty(currentPath))
                        {
                            path = currentPath;
                        }
                    }

                    var animationClip = AnimationClipService.CreateNewClip(path);

                    if (animationClip != null) {
                        ReactiveProperty.Value = new AssetReference<AnimationClip>(animationClip);
                    }
                }
            });

            tree.Q<TranslatedButtonVisualElement>("OpenButton").RegisterCallback<ClickEvent>(ev =>
            {
                if (ReactiveProperty != null)
                {
                    var path = "Assets";

                    if (ReactiveProperty.Value.Instance != null)
                    {
                        var currentPath = AssetDatabase.GetAssetPath(ReactiveProperty.Value.Instance);

                        if (!string.IsNullOrEmpty(currentPath))
                        {
                            path = currentPath;
                        }
                    }

                    var animationClip = AnimationClipService.OpenClip(path);

                    if (animationClip != null) {
                        ReactiveProperty.Value = new AssetReference<AnimationClip>(animationClip);
                    }
                }
            });

            editButton = tree.Q<TranslatedButtonVisualElement>("EditButton");

            editButton.RegisterCallback<ClickEvent>(ev =>
            {
                if (ReactiveProperty != null)
                {
                    var editorService = this.GetContextValueUnwrap<SetupEditorService>();

                    if (editorService is null)
                    {
                        return;
                    }

                    var rootTransform = editorService.CurrentAvatarData.Value?.RootTransform;
                    var faceSMR = editorService.CurrentAvatarData.Value?.FaceSMR;

                    if (rootTransform == null || faceSMR == null)
                    {
                        return;
                    }

                    EditLauncher.Launch(rootTransform, faceSMR, ReactiveProperty.Value.Instance);
                }
            });

            Add(tree);
        }

        public override void OnReactivePropertyChanged(IAssetReference<AnimationClip> value)
        {
            var animationClip = value.Instance;

            if (animationClipField.value != animationClip)
            {
                animationClipField.SetValueWithoutNotify(animationClip);
            }

            editButton.SetEnabled(value.Instance != null);
        }
    }
}