using System.Collections.Generic;
using System.Linq;
using UnityEngine.UIElements;

namespace com.superneko.TurboFace.Editor.Setup.VisualElements
{
    internal class TranslatedDropdownVisualElement : DropdownField
    {
        public new class UxmlFactory : UxmlFactory<TranslatedDropdownVisualElement, UxmlTraits> { }

        public new class UxmlTraits : DropdownField.UxmlTraits
        {
            readonly UxmlStringAttributeDescription choiceMessageKeys = new()
            {
                name = "choice-message-keys",
                defaultValue = string.Empty
            };

            public override void Init(VisualElement ve, IUxmlAttributes bag, CreationContext cc)
            {
                base.Init(ve, bag, cc);

                var dropdown = (TranslatedDropdownVisualElement)ve;
                dropdown.SetChoiceMessageKeys(ParseMessageKeys(choiceMessageKeys.GetValueFromBag(bag, cc)));
            }

            static List<string> ParseMessageKeys(string raw)
            {
                if (string.IsNullOrWhiteSpace(raw))
                {
                    return new List<string>();
                }

                return raw
                    .Split(',')
                    .Select(choice => choice.Trim())
                    .Where(choice => choice != string.Empty)
                    .ToList();
            }
        }

        readonly List<string> choiceKeys = new();

        public TranslatedDropdownVisualElement()
        {
            RegisterCallback<AttachToPanelEvent>(_ => UpdateTranslation());
        }

        public void SetChoiceMessageKeys(IEnumerable<string> messageKeys)
        {
            choiceKeys.Clear();
            choiceKeys.AddRange(messageKeys);
            UpdateTranslation();
        }

        void UpdateTranslation()
        {
            if (choiceKeys.Count == 0)
            {
                return;
            }

            var selectedIndex = choices.IndexOf(value);
            var translatedChoices = BuildTranslatedChoices();

            choices = translatedChoices;

            if (translatedChoices.Count == 0)
            {
                SetValueWithoutNotify(string.Empty);
                return;
            }

            if (selectedIndex < 0 || selectedIndex >= translatedChoices.Count)
            {
                selectedIndex = 0;
            }

            SetValueWithoutNotify(translatedChoices[selectedIndex]);
        }

        List<string> BuildTranslatedChoices()
        {
            var hasTranslationActivator = this.GetContextValue<TranslationActivator>() != null;
            var translatedChoices = new List<string>(choiceKeys.Count);

            foreach (var choiceKey in choiceKeys)
            {
                if (hasTranslationActivator)
                {
                    translatedChoices.Add(Localization.GetTranslated(Editor.MessageKey.Get(choiceKey)));
                }
                else
                {
                    translatedChoices.Add(choiceKey);
                }
            }

            return translatedChoices;
        }
    }
}

