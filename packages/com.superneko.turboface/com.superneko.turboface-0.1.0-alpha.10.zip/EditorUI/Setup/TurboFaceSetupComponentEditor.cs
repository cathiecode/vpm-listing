using UnityEditor;

namespace com.superneko.TurboFace.Editor.Setup
{
    using System;
    using System.Linq;
    using com.superneko.TurboFace.Editor.Setup.Processor;
    using NUnit.Framework.Internal.Commands;
    using Runtime.Setup;
    using UniRx;
    using UnityEditor.VersionControl;
    using UnityEngine;
    using UnityEngine.SceneManagement;
    using UnityEngine.UIElements;
    using VisualElements;

    [CustomEditor(typeof(TurboFaceSetupComponent))]
    internal class TurboFaceSetupComponentEditor : UnityEditor.Editor
    {
        bool allowPrefabEdit = false;

        public override void OnInspectorGUI()
        {
            var component = target as TurboFaceSetupComponent;

            bool isPrefab = PrefabUtility.IsPartOfPrefabInstance(component);
            bool isOverriding = serializedObject.FindProperty("SerializedSetupData").prefabOverride;

            var canEdit = !isPrefab || (isPrefab && allowPrefabEdit) || isOverriding;
            var showAllowEditToggle = isPrefab && !isOverriding;

            if (isPrefab)
            {
                if (isOverriding)
                {
                    EditorGUILayout.HelpBox(L.M("setup.warn.prefab-overriding"), MessageType.Warning);
                }
                else
                {
                    EditorGUILayout.HelpBox(L.M("setup.warn.is-prefab"), MessageType.Warning);

                    if (GUILayout.Button(L.M("setup.open-prefab.button")))
                    {
                        var sourcePrefabRoot = PrefabUtility.GetCorrespondingObjectFromOriginalSource(component.gameObject);

                        AssetDatabase.OpenAsset(sourcePrefabRoot);
                    }
                }
            }

            if (showAllowEditToggle)
            {
                allowPrefabEdit = EditorGUILayout.Toggle(L.M("setup.allow-prefab-edit.toggle"), allowPrefabEdit);
            }

            EditorGUI.BeginDisabledGroup(!canEdit);

            if (GUILayout.Button(L.M("setup.open-editor.button")))
            {
                if (component == null)
                {
                    Logging.Error("Failed to get TurboFaceSetupComponent");
                    return;
                }

                TurboFaceSetupEditorWindow.ShowWindow(component);
            }

            if (isOverriding)
            {
                var rect = GUILayoutUtility.GetLastRect();
                rect.width = 2;
                rect.x = 0;

                var previousColor = GUI.color;
                GUI.color = new Color(0.24f, 0.49f, 0.90f);

                GUI.DrawTexture(rect, Texture2D.whiteTexture);

                GUI.color = previousColor;
            }

            EditorGUI.EndDisabledGroup();

            if (GUILayout.Button(L.M("setup.apply.button")))
            {
                if (component == null)
                {
                    Logging.Error("Failed to get TurboFaceSetupComponent");
                    return;
                }

                var asset = CreateInstance<TurboFaceSetupGeneratedAsset>();
                AssetDatabase.CreateAsset(asset, $"Assets/TurboFaceSetupGeneratedAsset_{Guid.NewGuid()}.asset");

                var assetJar = new AssetJar(asset);

                Generator.Generate(component, assetJar);

                EditorUtility.SetDirty(asset);
                AssetDatabase.SaveAssets();
            }

            if (GUILayout.Button(L.M("setup.copy-current-setup-data.button")))
            {
                if (component == null)
                {
                    Logging.Error("Failed to get TurboFaceSetupComponent");
                    return;
                }

                var body = component.SerializedSetupData.Body;

                EditorGUIUtility.systemCopyBuffer = body;

                Logging.Info("Copied current setup data to clipboard.");
                Logging.Info($"Current version: {component.SerializedSetupData.Version}");
            }
        }
    }
}
