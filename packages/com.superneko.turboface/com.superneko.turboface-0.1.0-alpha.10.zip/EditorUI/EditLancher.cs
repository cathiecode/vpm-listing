using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace.Editor
{
    using Edit;

    public static class EditLauncher
    {
        [MenuItem("GameObject/TurboFace", true, 0)]
        public static bool CanOpenEditorWindowWithGameObject()
        {
            var gameObject = Selection.activeGameObject;

            if (gameObject == null)
            {
                return false;
            }

            if (gameObject.GetComponent("Animator") == null)
            {
                return false;
            }

            return true;
        }

        [MenuItem("GameObject/TurboFace/Open With TurboFace Edit", priority = 0)]
        public static void OpenEditorWindowWithGameObject()
        {
            var selectedGameObject = Selection.activeGameObject;

            if (selectedGameObject == null)
            {
                EditorUtility.DisplayDialog(
                    "No GameObject Selected",
                    "Please select a GameObject to open the TurboFace Editor with.",
                    "OK");
                return;
            }

            Launch(selectedGameObject.transform, null, null);
        }


        [MenuItem("Assets/Open in TurboFace Editor")]
        public static void OpenEditorWindowWithAnimationClip()
        {
            var selectedObject = Selection.activeObject;

            if (selectedObject is AnimationClip animationClip)
            {
                ServiceRoot.Instance.ExpressionEditorService.SetBaseAnimationClip(animationClip);
                return;
            }

            return;
        }

        [MenuItem("Assets/Open in TurboFace Editor", true)]
        static bool CanOpenEditorWindowWithAnimationClip()
        {
            var selectedObject = Selection.activeObject;

            if (selectedObject is not AnimationClip)
            {
                return false;
            }

            if (!ServiceRoot.Instance.PreviewService.CheckPreviewable().IsSuccess)
            {
                return false;
            }

            return true;
        }

        public static void Launch(Transform avatarRoot, SkinnedMeshRenderer? faceSMR, AnimationClip? baseAnimationClip)
        {
            ServiceRoot.Instance.AvatarService.SetAvatarRoot(avatarRoot);

            if (faceSMR != null)
            {
                ServiceRoot.Instance.AvatarService.SetFaceSMR(faceSMR);
            }

            if (baseAnimationClip != null)
            {
                ServiceRoot.Instance.ExpressionEditorService.SetBaseAnimationClip(baseAnimationClip);
            }

            if (ServiceRoot.Instance.AvatarService.FaceSMR.Value == null)
            {
                EditorUtility.DisplayDialog("TurboFace", L.M("edit.failed-to-detect-face-smr"), "OK");
            }
            else
            {
                ServiceRoot.Instance.PreviewService.StartPreview();
            }

            TurboFaceEditorWindow.ShowWindow();
        }
    }
}
