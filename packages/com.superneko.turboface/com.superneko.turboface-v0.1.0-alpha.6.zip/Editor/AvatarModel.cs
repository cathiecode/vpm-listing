using System;
using UniRx;
using UnityEditor;
using UnityEngine;
using UnityEngine.Profiling;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class AvatarModel : ReactiveService
    {
        class AvatarModelState : ScriptableSingleton<AvatarModelState>
        {
            public AlwaysNotifyReactiveProperty<Transform?> AvatarRoot = new(null);
            public AlwaysNotifyReactiveProperty<SkinnedMeshRenderer?> FaceSMR = new(null);
            public AlwaysNotifyReactiveProperty<AnimationClip?> DefaultFaceAnimation = new(null);
        }

        AvatarModelState? _state;

        AvatarModelState State
        {
            get
            {
                if (_state == null)
                {
                    _state = AvatarModelState.instance;
                }

                return _state;
            }
        }

        public ReadOnlyReactiveProperty<Transform?> AvatarRoot => State.AvatarRoot.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<SkinnedMeshRenderer?> FaceSMR => State.FaceSMR.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<AnimationClip?> DefaultFaceAnimation => State.DefaultFaceAnimation.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<TiedItem<float[], SkinnedMeshRenderer>?> DefaultBlendShapeWeights => defaultBlendShapeWeights.ToReadOnlyReactiveProperty();

        readonly ReactiveProperty<TiedItem<float[], SkinnedMeshRenderer>?> defaultBlendShapeWeights = new(null);

        protected override void Initialize(CompositeDisposable d)
        {
            Observable.CombineLatest(Observable.Interval(TimeSpan.FromSeconds(1)), State.FaceSMR, State.DefaultFaceAnimation, (_, smr, clip) => (smr, clip))
                .Throttle(TimeSpan.FromMilliseconds(100))
                .Subscribe(UpdateDefaultBlendShapeWeights).AddTo(d);
        }

        public void SetAvatarRoot(Transform? newAvatarRoot)
        {
            if (State.AvatarRoot.Value == newAvatarRoot)
            {
                return;
            }

            State.AvatarRoot.Value = newAvatarRoot;

            if (newAvatarRoot == null)
            {
                SetFaceSMR(null);
                return;
            }

            if (FaceSMR.Value == null || !Utils.IsChildOf(FaceSMR.Value.transform, newAvatarRoot))
            {
                var faceTransform = newAvatarRoot.Find("body") ?? newAvatarRoot.Find("Body");

                if (faceTransform != null)
                {
                    var smr = faceTransform.GetComponentInChildren<SkinnedMeshRenderer>();

                    SetFaceSMR(smr);
                    return;
                }
            }
        }

        public void SetFaceSMR(SkinnedMeshRenderer? smr)
        {
            if (State.FaceSMR.Value == smr)
            {
                return;
            }

            State.FaceSMR.Value = smr;
        }

        public void SetDefaultFaceAnimation(AnimationClip? clip)
        {
            if (State.DefaultFaceAnimation.Value == clip)
            {
                return;
            }

            State.DefaultFaceAnimation.Value = clip;
        }

        void UpdateDefaultBlendShapeWeights((SkinnedMeshRenderer?, AnimationClip?) args)
        {
            Profiler.BeginSample("AvatarModel.UpdateDefaultBlendShapeWeights");

            var (smr, defaultFaceAnimationClip) = args;

            if (smr == null)
            {
                defaultBlendShapeWeights.Value = null;
                return;
            }

            var blendShapeCount = smr.sharedMesh?.blendShapeCount ?? 0;
            var weights = new float[blendShapeCount];

            var changed = false;

            var currentDefaultBlendShapeWeights = defaultBlendShapeWeights.Value;

            if (currentDefaultBlendShapeWeights == null || currentDefaultBlendShapeWeights?.Item.Length != blendShapeCount || currentDefaultBlendShapeWeights?.TiedTo != smr)
            {
                changed = true;
            }

            var mesh = smr.sharedMesh;

            for (int i = 0; i < blendShapeCount; i++)
            {
                var newWeight = smr.GetBlendShapeWeight(i);

                if (mesh != null && defaultFaceAnimationClip != null)
                {
                    var curve = AnimationUtility.GetEditorCurve(defaultFaceAnimationClip, EditorCurveBinding.FloatCurve(
                            AnimationUtility.CalculateTransformPath(smr.transform, smr.transform.root),
                            typeof(SkinnedMeshRenderer),
                            $"blendShape.{mesh.GetBlendShapeName(i)}"));

                    if (curve != null)
                    {
                        newWeight = curve.Evaluate(0);
                    }
                }

                if (!changed && !Mathf.Approximately(currentDefaultBlendShapeWeights?.Item[i] ?? -100, newWeight))
                {
                    changed = true;
                }

                weights[i] = newWeight;
            }

            if (changed)
            {
                Logging.Trace("AvatarModel: Default blend shape weights updated.");
                defaultBlendShapeWeights.Value = new TiedItem<float[], SkinnedMeshRenderer>(weights, smr);
            }

            Profiler.EndSample();
        }
    }
}
