using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class ExpressionEntryContextMenu : PopupWindowContent
    {
        readonly Model model;
        readonly Expression expression;
        readonly Entry entry;
        readonly List<Entry> relatedEntries;
        FBCGUI.EntriesView? entriesView;

        ExpressionEntryContextMenu(Model model, Expression expression, Entry entry)
        {
            this.model = model;
            this.entry = entry;
            this.expression = expression;

            relatedEntries = new List<Entry>();

            foreach (var index in model.ExpressionEntrySearchService.FindSimilarEntries(entry))
            {
                relatedEntries.Add(index);
            }

            relatedEntries.Sort((a, b) => a.BlendShapeIndex.CompareTo(b.BlendShapeIndex));
        }

        public override void OnOpen()
        {
            entriesView = new FBCGUI.EntriesView(this.editorWindow, model);
            editorWindow.wantsMouseMove = true;
        }

        public override Vector2 GetWindowSize()
        {
            return new Vector2(500, 500);
        }

        public override void OnGUI(Rect rect)
        {
            GUILayout.BeginArea(rect);
            GUILayout.Label($"Related entries for {entry.DisplayName}");

            entriesView?.OnGUI(expression, relatedEntries);

            GUILayout.EndArea();
        }

        public static void Open(Rect rect, Model model, Expression expression, Entry entry)
        {
            var menu = new ExpressionEntryContextMenu(model, expression, entry);

            PopupWindow.Show(rect, menu);
        }
    }
}
