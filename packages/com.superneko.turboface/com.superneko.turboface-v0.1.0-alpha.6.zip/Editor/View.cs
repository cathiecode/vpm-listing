using UniRx;
using UnityEditor;
using UnityEngine;
using System;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class Window : EditorWindow
    {
        [MenuItem("Window/TurboFace")]
        static void ShowWindow()
        {
            var window = GetWindow<Window>();
            window.titleContent = new GUIContent("TurboFace");
            window.Show();
        }

        Model model;

        System.IDisposable subscription;

        FBCGUI.EntriesView entriesView;

        Rect searchFieldRect = Rect.zero;

        void OnEnable()
        {
            // HACK: UniRx Observable Tracker does not track Subscriptions created immediately after domain reload.
            EditorApplication.delayCall += () =>
            {
                model = Model.Instance;
                entriesView = new FBCGUI.EntriesView(this, model);
                entriesView.Initialize();

                var d = new CompositeDisposable();

                Observable.CombineLatest(
                    model.PreviewModel.IsPreviewing,
                    model.ExpressionEditorModel.EntriesSortKeyAspect,
                    model.ExpressionEditorModel.EntriesAnimationAspect,
                    ValueTuple.Create
                )
                    .Subscribe(_ =>
                    {
                        Repaint();
                    })
                    .AddTo(d);

                Observable.CombineLatest(model.ExpressionEditorModel.EntriesListStructureAspect).Subscribe(_ =>
                {
                    EditorApplication.delayCall += () => {
                        entriesView.ResetScrollPosition();
                        Repaint();
                    };
                }).AddTo(d);

                subscription = d;

                SceneView.duringSceneGui += OnSceneGUI;
                EditorApplication.update += Update;
                wantsMouseMove = true;
            };
        }

        void OnDisable()
        {
            subscription.Dispose();
            SceneView.duringSceneGui -= OnSceneGUI;
            EditorApplication.update -= Update;
        }

        void Update()
        {

        }

        void OnGUI()
        {
            if (model == null) return;

            var mayAnimationClip = EditorGUILayout.ObjectField("Animation Clip", model.ExpressionEditorModel.BaseAnimationClip.Value, typeof(AnimationClip), true);

            if (mayAnimationClip is AnimationClip clip)
            {
                model.ExpressionEditorModel.SetBaseAnimationClip(clip);
            }
            else
            {
                model.ExpressionEditorModel.SetBaseAnimationClip(null);
            }

            model.AvatarModel.SetAvatarRoot((Transform?)EditorGUILayout.ObjectField("Avatar Root", model.AvatarModel.AvatarRoot.Value, typeof(Transform), true));
            model.AvatarModel.SetFaceSMR((SkinnedMeshRenderer?)EditorGUILayout.ObjectField("Face SkinnedMeshRenderer", model.AvatarModel.FaceSMR.Value, typeof(SkinnedMeshRenderer), true));
            model.AvatarModel.SetDefaultFaceAnimation((AnimationClip?)EditorGUILayout.ObjectField("Default Face Animation", model.AvatarModel.DefaultFaceAnimation.Value, typeof(AnimationClip), true));

            if (model.BlendShapePickerModel.Picking.Value)
            {
                if (GUILayout.Button("Exit Picking Mode"))
                {
                    model.BlendShapePickerModel.StopPicking();
                }

                EditorGUILayout.HelpBox("Picking mode is enabled. Click on the avatar in Scene view to pick a vertex.", MessageType.Info);
            }
            else
            {
                if (GUILayout.Button("Enter Picking Mode"))
                {
                    model.BlendShapePickerModel.StartPicking();
                }
            }

            if (model.BlendShapePickerModel.PickResult.Value != null)
            {
                if (GUILayout.Button("Clear Picked Vertex"))
                {
                    model.BlendShapePickerModel.ClearPickedVertex();
                }
            }

            if (model.PreviewModel.IsPreviewing.Value)
            {
                if (GUILayout.Button("Stop Preview"))
                {
                    model.PreviewModel.StopPreview();
                }
            }
            else
            {
                if (GUILayout.Button("Open Preview Window"))
                {
                    model.PreviewModel.StartPreview();
                }
            }

            GUI.SetNextControlName("com.superneko.TurboFace.View.SearchField");

            EditorGUILayout.TextField("Search");

            if (Event.current.type == EventType.Repaint)
            {
                searchFieldRect = GUILayoutUtility.GetLastRect();
            }

            if (GUI.GetNameOfFocusedControl() == "com.superneko.TurboFace.View.SearchField")
            {
                GUI.FocusControl(null);

                var activator = searchFieldRect;

                activator.y -= searchFieldRect.height; // NOTE: Adjust position to hide behind the search field.

                ExpressionEntrySearchWindow.Open(activator, model, model.ExpressionEditorModel.Expression.Value);
            }

            var expressionEntries = model.ExpressionEditorModel.GetEntries();

            entriesView.OnGUI(model.ExpressionEditorModel.Expression.Value, expressionEntries);

            OnGUISettings();
        }

        void OnGUISettings()
        {
            var threshold = model.ExpressionEditorModel.Threshold.Value;

            var visibleThreshold = (Mathf.Log10(threshold) + 4f) / 4f;

            visibleThreshold = EditorGUILayout.Slider("Blend Shape Influence Threshold", visibleThreshold, 0f, 1f);

            var newThreshold = Mathf.Pow(10f, visibleThreshold * 4f - 4f);

            model.ExpressionEditorModel.SetThreshold(newThreshold);

            model.ExpressionEditorModel.SetBlendShapeFolderSplitter(EditorGUILayout.TextField("Blend Shape Folder Splitter", model.ExpressionEditorModel.BlendShapeFolderSplitter.Value));
        }

        void OnSceneGUI(SceneView sceneView)
        {
            if (model == null) return;

            Event e = Event.current;

            if (model.BlendShapePickerModel.Picking.Value)
            {
                if (e.type == EventType.MouseDown && e.button == 0)
                {
                    model.BlendShapePickerModel.Pick(e.mousePosition);
                    e.Use();
                }
            }

            if (model.BlendShapePickerModel.PickResult.Value is BlendShapePickerModel.VertexSelectResultValue pickResult)
            {
                if (e.type == EventType.Repaint)
                {
                    Handles.color = Color.cyan;

                    Handles.SphereHandleCap(
                        GUIUtility.GetControlID(FocusType.Passive),
                        pickResult.PickedVertexPosition,
                        Quaternion.identity,
                        HandleUtility.GetHandleSize(pickResult.PickedVertexPosition) * 0.1f,
                        EventType.Repaint);
                }
            }
        }
    }
}

