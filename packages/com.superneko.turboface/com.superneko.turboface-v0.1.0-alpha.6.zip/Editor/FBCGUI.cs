using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UniRx;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    static class FBCGUI
    {
        public static float Slider(Rect rect, float value, float min, float max, float defaultValue = 0f, bool lineOnly = false)
        {
            var id = GUIUtility.GetControlID(FocusType.Passive);

            var updateValue = false;
            var padding = 10f;

            var effectiveRect = new Rect(rect.x + padding, rect.y, rect.width - padding * 2, rect.height);

            DrawSlider(effectiveRect, value, min, max, defaultValue, lineOnly);

            if (Event.current.type == EventType.MouseDown && rect.Contains(Event.current.mousePosition))
            {
                updateValue = true;
                GUIUtility.hotControl = id;
                Event.current.Use();
            }

            if (Event.current.type == EventType.MouseUp && GUIUtility.hotControl == id)
            {
                GUIUtility.hotControl = 0;
                Event.current.Use();
            }

            if (Event.current.type == EventType.MouseDrag)
            {
                if (GUIUtility.hotControl == id)
                {
                    updateValue = true;
                    Event.current.Use();
                }
            }

            if (updateValue)
            {
                float mousePosRatio = Mathf.Clamp01((Event.current.mousePosition.x - effectiveRect.x) / effectiveRect.width);
                value = Mathf.Lerp(min, max, mousePosRatio);
            }

            return value;
        }

        public static (float, bool) HoverPreviewSlider(Rect rect, float value, float min, float max, EditorWindow currentEditorWindow, float defaultValue = 0f)
        {
            var valueUpdated = false;
            var padding = 10f;

            var effectiveRect = new Rect(rect.x + padding, rect.y, rect.width - padding * 2, rect.height);

            DrawSlider(effectiveRect, value, min, max, defaultValue, isPreview: true);

            if (Event.current.isMouse)
            {
                if (rect.Contains(Event.current.mousePosition))
                {
                    float mousePosRatio = Mathf.Clamp01((Event.current.mousePosition.x - effectiveRect.x) / effectiveRect.width);
                    value = Mathf.Lerp(min, max, mousePosRatio);
                }
                else
                {
                    value = 0f;
                }

                currentEditorWindow.Repaint();

                valueUpdated = true;
            }

            return (value, valueUpdated);
        }

        static void DrawSlider(Rect rect, float value, float min, float max, float defaultValue = 0f, bool isPreview = false, bool lineOnly = false)
        {
            Textures.Instance.DrawTexture(TextureName.Line, rect, Color.gray);
            Textures.Instance.DrawTexture(TextureName.Line, new Rect(rect.x, rect.y, rect.width * ((value - min) / (max - min)), rect.height), Color.cyan);

            var defaultValueKnobCenterX = rect.x + rect.width * ((defaultValue - min) / (max - min));
            var defaultValueKnobCenterY = rect.y + rect.height / 2;
            var defaultValueKnobSize = rect.height * 0.5f;
            var defaultValueKnobColor = value <= defaultValue ? Color.gray : Color.cyan;
            Textures.Instance.DrawTexture(TextureName.Circle, new Rect(defaultValueKnobCenterX - defaultValueKnobSize / 2, defaultValueKnobCenterY - defaultValueKnobSize / 2, defaultValueKnobSize, defaultValueKnobSize), defaultValueKnobColor);

            if (!isPreview && !lineOnly)
            {
                var knobCenter = rect.x + rect.width * ((value - min) / (max - min));
                Textures.Instance.DrawTexture(TextureName.Circle, new Rect(knobCenter - rect.height / 2, rect.y, rect.height, rect.height));
            }
        }

        public class EntriesView
        {
            enum ColumnType
            {
                BlendShapeInfluenceScore,
                Name,
                FirstFrameValue,
                Registered
            }

            class Header : MultiColumnHeader
            {
                Model model;

                public Header(MultiColumnHeaderState state, Model model) : base(state)
                {
                    allowDraggingColumnsToReorder = true;
                    this.model = model;
                }

                public void Initialize(CompositeDisposable disposableBuilder)
                {
                    model.ExpressionEditorModel.SortRules.AsObservable().Subscribe((sortRule) =>
                    {
                        UpdateSorting();
                    }).AddTo(disposableBuilder);
                }

                protected override void ColumnHeaderClicked(MultiColumnHeaderState.Column column, int columnIndex)
                {
                    var innerColumn = (Column)column;

                    switch (innerColumn.type)
                    {
                        case ColumnType.BlendShapeInfluenceScore:
                            model.ExpressionEditorModel.SetSortRule(ExpressionEditorService.SortKey.BlendShapeInfluenceScore, false);
                            model.ExpressionEditorModel.SetSortRule(ExpressionEditorService.SortKey.WillMoveCurrentSelectedVertex, false);
                            break;
                        case ColumnType.Name:
                            model.ExpressionEditorModel.SetSortRule(ExpressionEditorService.SortKey.BlendShapeIndex);
                            break;
                        case ColumnType.FirstFrameValue:
                            model.ExpressionEditorModel.SetSortRule(ExpressionEditorService.SortKey.RegisteredDataFirstFrameValue);
                            break;
                        case ColumnType.Registered:
                            model.ExpressionEditorModel.SetSortRule(ExpressionEditorService.SortKey.IsRegistered);
                            break;
                    }
                }

                public void UpdateSorting()
                {
                    var sortRules = model.ExpressionEditorModel.SortRules.Value;

                    if (sortRules.Count == 0)
                    {
                        SetSorting(-1, true);
                        return;
                    }

                    var importantSortRule = sortRules[^1];

                    for (int i = 0; i < state.columns.Length; i++)
                    {
                        var innerColumn = (Column)GetColumn(i);

                        switch (innerColumn.type)
                        {
                            case ColumnType.BlendShapeInfluenceScore:
                                if (importantSortRule.Key == ExpressionEditorService.SortKey.BlendShapeInfluenceScore)
                                {
                                    SetSorting(i, importantSortRule.Ascending);
                                    return;
                                }
                                break;
                            case ColumnType.Name:
                                if (importantSortRule.Key == ExpressionEditorService.SortKey.BlendShapeIndex)
                                {
                                    SetSorting(i, importantSortRule.Ascending);
                                    return;
                                }
                                break;
                            case ColumnType.FirstFrameValue:
                                if (importantSortRule.Key == ExpressionEditorService.SortKey.RegisteredDataFirstFrameValue)
                                {
                                    SetSorting(i, importantSortRule.Ascending);
                                    return;
                                }
                                break;
                            case ColumnType.Registered:
                                if (importantSortRule.Key == ExpressionEditorService.SortKey.IsRegistered)
                                {
                                    SetSorting(i, importantSortRule.Ascending);
                                    return;
                                }
                                break;
                        }
                    }
                }
            }

            class Column : MultiColumnHeaderState.Column
            {
                public ColumnType type;
            }

            Vector2 scrollPosition = Vector2.zero;
            Model model;
            EditorWindow window;
            Header header;
            MultiColumnHeaderState headerState;

            int hoveringEntryIndex = 0;

            public EntriesView(EditorWindow window, Model model)
            {
                this.model = model;
                this.window = window;

                var columns = new List<Column>
                {
                    new()
                    {
                        headerContent = new GUIContent("Vertex Influence Score"),
                        width = 50,
                        minWidth = 50,
                        maxWidth = 100,
                        autoResize = false,
                        allowToggleVisibility = true,
                        type = ColumnType.BlendShapeInfluenceScore
                    },
                    new()
                    {
                        headerContent = new GUIContent("Name"),
                        width = 200,
                        minWidth = 100,
                        autoResize = true,
                        allowToggleVisibility = true,
                        type = ColumnType.Name
                    },
                    new()
                    {
                        headerContent = new GUIContent("First Frame Value"),
                        width = 200,
                        minWidth = 100,
                        autoResize = true,
                        allowToggleVisibility = true,
                        type = ColumnType.FirstFrameValue
                    },
                    new()
                    {
                        headerContent = new GUIContent("Registered"),
                        width = 20,
                        minWidth = 20,
                        maxWidth = 20,
                        autoResize = false,
                        allowToggleVisibility = false,
                        type = ColumnType.Registered
                    }
                };

                headerState = new MultiColumnHeaderState(columns.ToArray());
                header = new Header(headerState, model);
            }

            public void Initialize()
            {
                var disposableBuilder = new CompositeDisposable();

                header.Initialize(disposableBuilder);

                var subscription = disposableBuilder;

                AssemblyReloadEvents.beforeAssemblyReload += () =>
                {
                    subscription.Dispose();
                };
            }

            public void OnGUI(Expression? expression, IEnumerable<Entry>? entries = null)
            {
                var tableSpace = GUILayoutUtility.GetRect(200, 400, GUILayout.ExpandWidth(true));
                OnGUI(tableSpace, expression, entries);
            }

            public void OnGUI(Rect tableSpace, Expression? expression, IEnumerable<Entry>? entries = null)
            {
                if (expression == null)
                {
                    GUI.Label(tableSpace, "No Expression loaded.");
                    return;
                }

                var highlightStyle = new GUIStyle(GUI.skin.label);
                highlightStyle.normal.textColor = Color.cyan;
                highlightStyle.hover.textColor = Color.cyan;
                highlightStyle.active.textColor = Color.cyan;

                (int, float) hoverPreview = (-1, 0f);

                var headerRect = tableSpace;
                headerRect.height = 30;
                header.OnGUI(headerRect, scrollPosition.x);

                var tableBodyRect = tableSpace;
                tableBodyRect.y += headerRect.height;
                tableBodyRect.height -= headerRect.height;

                using (Table.BeginTable(tableBodyRect, scrollPosition))
                {
                    foreach (var column in headerState.visibleColumns)
                    {
                        Table.GetHeaderCell(headerState.columns[column].width);
                    }

                    Table.EndHeader();

                    var expressionEntries = entries ?? expression.GetEntries();

                    var rowCount = expressionEntries.Count();

                    scrollPosition = Table.BeginBody(rowCount);

                    var quickPreviewingBlendShape = model.PreviewModel.QuickPreviewingBlendShape.Value;
                    var quickPreviewingBlendShapeIndex = quickPreviewingBlendShape?.Item1 ?? -1;
                    var quickPreviewingBlendShapeValue = quickPreviewingBlendShape?.Item2 ?? 0f;

                    if (expressionEntries != null)
                    {
                        int entryRowIndex = 0;
                        foreach (var entry in expressionEntries)
                        {
                            if (entry == null)
                            {
                                continue; // Something went wrong?
                            }

                            using (var rowScope = Table.BeginRow())
                            {
                                if (rowScope.isVisible == false)
                                {
                                    continue;
                                }

                                if (Event.current.isMouse && rowScope.Rect.Contains(Event.current.mousePosition))
                                {
                                    hoveringEntryIndex = entryRowIndex;
                                }

                                if (Event.current.type == EventType.MouseDown && Event.current.button == 1 && rowScope.Rect.Contains(Event.current.mousePosition))
                                {
                                    ExpressionEntryContextMenu.Open(rowScope.Rect, model, expression, entry);
                                    Event.current.Use();
                                }

                                if (hoveringEntryIndex == entryRowIndex)
                                {
                                    EditorGUI.DrawRect(rowScope.Rect, new Color(1f, 1f, 1f, 0.1f));
                                }

                                foreach (var columnIndex in headerState.visibleColumns)
                                {
                                    var column = (Column)headerState.columns[columnIndex];

                                    switch (column.type)
                                    {
                                        case ColumnType.BlendShapeInfluenceScore:
                                            GUI.Label(Table.GetNextCell(), $"{entry.BlendShapeInfluenceScore:F2}");
                                            break;
                                        case ColumnType.Name:
                                            var style = entry.WillMoveCurrentSelectedVertex ? highlightStyle : GUI.skin.label;
                                            GUI.Button(Table.GetNextCell(), $"{entry.DisplayName}", style);
                                            break; ;
                                        case ColumnType.FirstFrameValue:
                                            var sliderCell = Table.GetNextCell();

                                            var changedValue = Slider(sliderCell, entry.RegisteredData?.FirstFrameValue ?? 0f, 0f, 100f, entry.DefaultValue, entry.RegisteredData == null);
                                            if (changedValue != ((entry.RegisteredData?.FirstFrameValue) ?? 0f))
                                            {
                                                expression.RecordObject($"Change Entry Value for {entry.DisplayName}");
                                                entry.ChangeFirstFrameValue(changedValue);
                                            }

                                            var quickPreview = entry.RegisteredData == null;

                                            if (quickPreview)
                                            {
                                                var oldQuickPreviewWeight = (entry.BlendShapeIndex == quickPreviewingBlendShapeIndex) ? quickPreviewingBlendShapeValue : 0f;
                                                var (newQuickPreviewWeight, valueUpdate) = HoverPreviewSlider(sliderCell, oldQuickPreviewWeight, 0f, 100f, window, entry.DefaultValue);

                                                if (valueUpdate && newQuickPreviewWeight != 0f)
                                                {
                                                    hoverPreview = (entry.BlendShapeIndex, newQuickPreviewWeight);
                                                }
                                            }
                                            break;
                                        case ColumnType.Registered:
                                            var toggleOn = entry.RegisteredData != null;

                                            toggleOn = GUI.Toggle(Table.GetNextCell(), toggleOn, "");

                                            if (!toggleOn && entry.RegisteredData != null)
                                            {
                                                expression.RecordObject($"Removed Entry {entry.DisplayName}");
                                                entry.ClearRegisteredData();
                                            }

                                            if (toggleOn && entry.RegisteredData == null)
                                            {
                                                expression.RecordObject($"Added Entry {entry.DisplayName}");
                                                entry.RegisterData();
                                            }

                                            break;
                                    }
                                }
                            }

                            entryRowIndex++;
                        }
                    }

                    Table.EndBody();
                }

                if (Event.current.type == EventType.MouseMove)
                {
                    if (hoverPreview.Item1 >= 0)
                    {
                        model.PreviewModel.SetQuickPreviewBlendShape(hoverPreview.Item1, hoverPreview.Item2);
                    }
                    else
                    {
                        model.PreviewModel.SetQuickPreviewBlendShape(-1, 0f);
                    }
                }
            }

            public void ResetScrollPosition()
            {
                scrollPosition = Vector2.zero;
            }
        }
    }
}
