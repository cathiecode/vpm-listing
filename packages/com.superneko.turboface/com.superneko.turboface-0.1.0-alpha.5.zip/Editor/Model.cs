using System.Collections.Generic;
using UniRx;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{

    internal class ModelState : ScriptableSingleton<ModelState>
    {
        public ReactiveProperty<bool> Debug = new(false);
    }

    internal class Model
    {
        static Model? _instance;

        public static Model Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Model();
                    _instance.Initialize();
                }

                return _instance;
            }
        }

        ModelState? _state;

        ModelState State
        {
            get
            {
                if (_state == null)
                {
                    _state = ModelState.instance;
                }

                return _state;
            }
        }

        Model()
        {
            Logging.Trace("Model: Constructing Model.");

            AvatarModel = new AvatarModel();

            ExpressionEditorModel = new ExpressionEditorService(AvatarModel);

            PreviewModel = new PreviewModel(AvatarModel, ExpressionEditorModel);

            BlendShapePickerModel = new BlendShapePickerModel(AvatarModel, PreviewModel, ExpressionEditorModel);

            ExpressionEntrySearchService = new ExpressionEntrySearchService(ExpressionEditorModel.EntriesSetAspect);
        }

        public void Initialize()
        {
            Logging.Trace("Model: Initializing Model.");

            AvatarModel.Initialize();
            ExpressionEditorModel.Initialize();
            PreviewModel.Initialize();
            BlendShapePickerModel.Initialize();
            ExpressionEntrySearchService.Initialize();
        }

        public BlendShapePickerModel BlendShapePickerModel;
        public PreviewModel PreviewModel;
        public AvatarModel AvatarModel;
        public ExpressionEditorService ExpressionEditorModel;
        public ExpressionEntrySearchService ExpressionEntrySearchService;

        public ReadOnlyReactiveProperty<Transform?> AvatarRoot => AvatarModel.AvatarRoot;
        public ReadOnlyReactiveProperty<SkinnedMeshRenderer?> FaceSMR => AvatarModel.FaceSMR;
        public ReadOnlyReactiveProperty<bool> Debug => State.Debug.ToReadOnlyReactiveProperty();
        public ReadOnlyReactiveProperty<string> BlendShapeFolderSplitter => ExpressionEditorModel.BlendShapeFolderSplitter;


        public void SetAnimationClip(AnimationClip? clip)
        {
            ExpressionEditorModel.SetBaseAnimationClip(clip);
        }

        public void SetAvatarRoot(Transform? transform)
        {
            AvatarModel.SetAvatarRoot(transform);
        }

        public void SetFaceSMR(SkinnedMeshRenderer? smr)
        {
            AvatarModel.SetFaceSMR(smr);
        }

        public bool SetDebug(bool debug)
        {
            if (State.Debug.Value == debug)
            {
                return debug;
            }

            State.Debug.Value = debug;

            return debug;
        }

        public string SetBlendShapeFolderSplitter(string splitter)
        {
            return ExpressionEditorModel.SetBlendShapeFolderSplitter(splitter);
        }

        public void StartPreview()
        {
            PreviewModel.StartPreview();
        }

        public void StopPreview()
        {
            PreviewModel.StopPreview();
        }

        public bool IsPreviewingCurrent => PreviewModel.IsPreviewing.Value;
        public ReadOnlyReactiveProperty<bool> IsPreviewing => PreviewModel.IsPreviewing;
    }
}
