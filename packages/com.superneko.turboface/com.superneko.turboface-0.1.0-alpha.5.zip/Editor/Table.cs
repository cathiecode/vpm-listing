using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    public static class Table
    {
        public readonly struct RowScope : IDisposable
        {
            readonly TableScope table;
            public readonly bool isVisible;
            public readonly Rect Rect;

            public RowScope(bool isVisible, Rect rect, TableScope table)
            {
                this.isVisible = isVisible;
                this.Rect = rect;
                this.table = table;
            }

            public void Dispose()
            {
                EndRow();
            }
        }

        public class TableScope : IDisposable
        {
            public readonly List<float> HeaderWidth;
            public readonly Action OnDispose;
            public int currentRow;
            public int currentColumn;
            public float currentX = 0;
            public readonly Rect area;
            public readonly Vector2 scrollPosition;
            public float width;

            public TableScope(Rect area, Vector2 scrollPosition, Action onDispose)
            {
                HeaderWidth = new List<float>();
                currentRow = 0;
                currentColumn = 0;
                currentX = 0;
                OnDispose = onDispose;
                this.area = area;
                this.scrollPosition = scrollPosition;
                this.width = 0;
            }

            public void StartFirstCell()
            {
                currentColumn = 0;
                currentX = 0;
                currentRow = 0;
            }

            public void StartNextCell()
            {
                currentX += HeaderWidth[currentColumn++];
            }

            public Rect CurrentCell()
            {
                var width = HeaderWidth[currentColumn];
                var rect = new Rect(
                    currentX,
                    20 * currentRow,
                    width,
                    20
                );

                return rect;
            }

            public void StartNextRow()
            {
                currentRow++;
                currentColumn = 0;
                currentX = 0;
            }

            public void Dispose()
            {
                OnDispose?.Invoke();
            }
        }

        static readonly FastStack<TableScope> ScopeStack = new(4);

        static TableScope CurrentScope
        {
            get
            {
                ScopeStack.TryPeek(out var scope);

                if (scope == null)
                {
                    throw new InvalidOperationException("No active TableScope. Did you forget to call BeginTable()?");
                }

                return scope;
            }
        }


        public static IDisposable BeginTable(Rect area, Vector2 scrollPosition)
        {
            var tableScope = new TableScope(area, scrollPosition, EndTable);

            ScopeStack.Push(tableScope);

            return tableScope;
        }

        public static void BeginHeader()
        {
            var currentScope = CurrentScope;

            currentScope.HeaderWidth.Clear();
            currentScope.StartFirstCell();
        }

        public static Rect GetHeaderCell(float width)
        {
            var currentScope = CurrentScope;

            currentScope.HeaderWidth.Add(width);
            var currentCell = currentScope.CurrentCell();

            currentCell.x += currentScope.area.x;
            currentCell.y += currentScope.area.y;

            currentScope.StartNextCell();
            return currentCell;
        }

        public static void EndHeader()
        {
            var currentScope = CurrentScope;

            currentScope.width = currentScope.HeaderWidth.Sum();
            currentScope.StartNextRow();
        }

        public static Vector2 BeginBody(float expectedRowCount)
        {
            var currentScope = CurrentScope;

            var newScrollPosition = GUI.BeginScrollView(
                new Rect(
                    currentScope.area.x,
                    currentScope.area.y + 20,
                    currentScope.area.width,
                    currentScope.area.height - 20
                ),
                currentScope.scrollPosition,
                new Rect(
                    0,
                    0,
                    currentScope.width,
                    expectedRowCount * 20
                )
            );
            currentScope.StartFirstCell();

            return newScrollPosition;
        }

        public static RowScope BeginRow()
        {
            var currentScope = CurrentScope;

            var areaSpaceRect = new Rect(
                0,
                currentScope.currentRow * 20,
                currentScope.width,
                20
            );

            if (currentScope.currentRow * 20 + 20 > currentScope.area.height + currentScope.scrollPosition.y ||
                currentScope.currentRow * 20 < currentScope.scrollPosition.y)
            {
                return new RowScope(false, areaSpaceRect, currentScope);
            }

            return new RowScope(true, areaSpaceRect, currentScope);
        }

        public static Rect GetNextCell()
        {
            var currentScope = CurrentScope;

            var currentCell = currentScope.CurrentCell();
            currentScope.StartNextCell();
            return currentCell;
        }

        public static void EndRow()
        {
            CurrentScope.StartNextRow();
        }

        public static void EndBody()
        {
            GUI.EndScrollView();
        }

        public static void EndTable()
        {
            ScopeStack.Pop();
        }
    }
}
