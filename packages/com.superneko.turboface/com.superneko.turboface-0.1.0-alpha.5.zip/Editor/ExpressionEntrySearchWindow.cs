using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    class ExpressionEntrySearchWindow : PopupWindowContent
    {
        readonly Model model;

        bool focused = false;
        Rect activatorRect;
        FBCGUI.EntriesView? entriesView;

        ExpressionEntrySearchWindow(Model model, Rect activatorRect)
        {
            this.model = model;
            this.activatorRect = activatorRect;
        }

        public override Vector2 GetWindowSize()
        {
            return new Vector2(activatorRect.width, 200);
        }

        public override void OnOpen()
        {
            entriesView = new FBCGUI.EntriesView(editorWindow, model);
            editorWindow.wantsMouseMove = true;
        }

        public override void OnGUI(Rect rect)
        {
            EditorGUI.DrawRect(rect, new Color(0f, 0f, 0f));

            GUI.SetNextControlName("com.superneko.TurboFace.ExpressionEntrySearchWindow.SearchField");

            model.ExpressionEntrySearchService.SearchQueryString.Value = EditorGUI.TextField(new Rect(rect.x, rect.y, rect.width, EditorGUIUtility.singleLineHeight), model.ExpressionEntrySearchService.SearchQueryString.Value);

            var searchResults = model.ExpressionEntrySearchService.SearchResults.Value;

            if (searchResults != null)
            {
                var searchResultRect = new Rect(rect.x, rect.y + EditorGUIUtility.singleLineHeight, rect.width, rect.height - EditorGUIUtility.singleLineHeight);
                entriesView?.OnGUI(searchResultRect, searchResults);
            }
            else
            {
                GUI.Label(new Rect(rect.x, rect.y + EditorGUIUtility.singleLineHeight, rect.width, EditorGUIUtility.singleLineHeight), "No results found.");
            }

            if (!focused)
            {
                GUI.FocusControl("com.superneko.TurboFace.ExpressionEntrySearchWindow.SearchField");
                focused = true;
            }

            if (Event.current.type == EventType.KeyDown)
            {
                switch (Event.current.keyCode)
                {
                    case KeyCode.Escape:
                        editorWindow.Close();
                        Event.current.Use();
                        break;
                    case KeyCode.Tab:
                        editorWindow.Close();
                        Event.current.Use();
                        break;
                }
            }
        }

        public override void OnClose()
        {
            
        }

        public static void Open(Rect rect, Model model)
        {
            var menu = new ExpressionEntrySearchWindow(model, rect);
            PopupWindow.Show(rect, menu);
        }
    }
}
