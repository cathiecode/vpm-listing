using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace com.superneko.TurboFace
{
    internal struct TextureName
    {
        public readonly string Name;

        TextureName(string Name)
        {
            this.Name = Name;
        }

        public static TextureName Line = new("Line");
        public static TextureName Circle = new("Circle");
        public static TextureName Picker = new("Picker");
        public static TextureName Diamond = new("Diamond");
        public static TextureName DownArrow = new("DownArrow");
        public static TextureName Folder = new("Folder");
    }

    internal class Textures
    {
        static Textures _instance;

        public static Textures Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Textures("1988389bd99b41c408d9331e36b40faf");
                }

                return _instance;
            }
        }

        readonly Texture2D spriteSheetTexture;

        readonly Dictionary<string, Rect> spriteSheetCoords;

        Textures(string spriteSheetGuid)
        {
            var folderPath = AssetDatabase.GUIDToAssetPath(spriteSheetGuid);

            spriteSheetTexture = AssetDatabase.LoadAssetAtPath<Texture2D>(folderPath);

            if (spriteSheetTexture == null)
            {
                Debug.LogError($"Failed to load sprite sheet texture at {folderPath}");
            }

            spriteSheetCoords = SpriteSheetCoords(
                new TextureName[]
                    {
                        TextureName.Line,
                        TextureName.Circle,
                        TextureName.Picker,
                        TextureName.Diamond,
                        TextureName.DownArrow,
                        TextureName.Folder,
                    },
                4, 4);
        }

        public void DrawTexture(TextureName name, Rect position, bool alphaBlend = true)
        {
            DrawTexture(name, position, Color.white, alphaBlend);
        }

        public void DrawTexture(TextureName name, Rect position, Color color, bool alphaBlend = true)
        {
            if (spriteSheetTexture == null || !spriteSheetCoords.ContainsKey(name.Name))
            {
                Logging.Warn($"Failed to draw texture: {name.Name}");
                return;
            }

            var oldColor = GUI.color;

            GUI.color = color;

            GUI.DrawTextureWithTexCoords(
                position,
                spriteSheetTexture,
                spriteSheetCoords[name.Name],
                alphaBlend
            );

            GUI.color = oldColor;
        }

        static Dictionary<string, Rect> SpriteSheetCoords(TextureName[] spriteNames, int columns, int rows)
        {
            var rects = new Rect[spriteNames.Length];
            var spriteWidth = 1.0f / columns;
            var spriteHeight = 1.0f / rows;

            for (int i = 0; i < spriteNames.Length; i++)
            {
                int col = i % columns;
                int row = i / columns;

                rects[i] = new Rect(
                    col * spriteWidth,
                    1.0f - (row + 1) * spriteHeight,
                    spriteWidth,
                    spriteHeight);
            }

            var result = new Dictionary<string, Rect>();

            for (int i = 0; i < spriteNames.Length; i++)
            {
                result[spriteNames[i].Name] = rects[i];
            }

            return result;
        }
    }
}
