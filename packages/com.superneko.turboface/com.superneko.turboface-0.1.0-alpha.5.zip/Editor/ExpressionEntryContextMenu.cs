using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class ExpressionEntryContextMenu : PopupWindowContent
    {
        readonly Model model;
        readonly Entry entry;
        readonly List<Entry> relatedEntries;
        FBCGUI.EntriesView? entriesView;

        ExpressionEntryContextMenu(Model model, Entry entry)
        {
            this.model = model;
            this.entry = entry;

            relatedEntries = new List<Entry>();

            foreach (var index in model.ExpressionEntrySearchService.FindSimilarEntries(entry))
            {
                relatedEntries.Add(index);
            }

            relatedEntries.Sort((a, b) => a.BlendShapeIndex.CompareTo(b.BlendShapeIndex));
        }

        public override void OnOpen()
        {
            entriesView = new FBCGUI.EntriesView(this.editorWindow, model);
            editorWindow.wantsMouseMove = true;
        }

        public override Vector2 GetWindowSize()
        {
            return new Vector2(500, 500);
        }

        public override void OnGUI(Rect rect)
        {
            GUILayout.BeginArea(rect);
            GUILayout.Label($"Related entries for {entry.DisplayName}");

            entriesView?.OnGUI(relatedEntries);

            GUILayout.EndArea();
        }

        public static void Open(Rect rect, Model model, Entry entry)
        {
            var menu = new ExpressionEntryContextMenu(model, entry);

            PopupWindow.Show(rect, menu);
        }
    }
}
