using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    [Serializable]
    internal class RegisteredData
    {
        // Note: Value inside [SerializeField] cannot be null, so we use IsValid to indicate validity.
        [SerializeField] bool isValid = false;
        [SerializeField] float firstFrameValue;

        public bool IsValid => isValid;
        public float FirstFrameValue => firstFrameValue;

        public RegisteredData(float firstFrameValue)
        {
            this.firstFrameValue = firstFrameValue;
            isValid = true;
        }

        RegisteredData(float firstFrameValue, bool isValid)
        {
            this.firstFrameValue = firstFrameValue;
            this.isValid = isValid;
        }

        public static RegisteredData Invalid => new RegisteredData(0f, false);
    }

    internal class Entry : ScriptableObject, ISerializationCallbackReceiver
    {
        public string Path;
        public string PropertyName;
        public int BlendShapeIndex;
        public float DefaultValue;
        [NonSerialized] public bool WillMoveCurrentSelectedVertex;
        [NonSerialized] public float BlendShapeInfluenceScore;
        [NonSerialized] public bool IsFolder;

        [SerializeField] RegisteredData registeredData;
        [SerializeField] AnimationClip? baseAnimationClip;

        Action? onChangedCallback; // NOTE: After deserialization, this will be null.

        public RegisteredData? RegisteredData
        {
            get
            {
                return registeredData.IsValid ? registeredData : null;
            }
            private set
            {
                registeredData = value ?? RegisteredData.Invalid;
            }
        }
        public string DisplayName {private set; get; } = "";

        public void SetValues(
            AnimationClip animationClip,
            string path,
            string propertyName,
            string folderName,
            bool willMoveCurrentSelectedVertex,
            float blendShapeInfluenceScore,
            int blendShapeIndex,
            float defaultValue,
            RegisteredData? registeredData,
            Action? onChangedCallback = null)
        {
            baseAnimationClip = animationClip;
            Path = path;
            PropertyName = propertyName;
            DisplayName = CalcDisplayName(folderName, propertyName);
            RegisteredData = registeredData;
            WillMoveCurrentSelectedVertex = willMoveCurrentSelectedVertex;
            BlendShapeInfluenceScore = blendShapeInfluenceScore;
            BlendShapeIndex = blendShapeIndex;
            DefaultValue = defaultValue;
            this.onChangedCallback = onChangedCallback;
        }

        public void ChangeFirstFrameValue(float newValue)
        {
            registeredData = new RegisteredData(newValue);
            onChangedCallback?.Invoke();
        }

        public void RegisterData()
        {
            registeredData = new RegisteredData(DefaultValue);
            onChangedCallback?.Invoke();
        }

        public void ClearRegisteredData()
        {
            registeredData = RegisteredData.Invalid;
            onChangedCallback?.Invoke();
        }

        public void SetFolderName(string folderName)
        {
            DisplayName = CalcDisplayName(folderName, PropertyName);
        }

        public void WritebackToAnimationClip()
        {
            Logging.Trace($"Writing back to animation clip for entry: {DisplayName}");

            if (baseAnimationClip == null)
            {
                Logging.Trace("Base animation clip is null. Skipping writeback.");
                return;
            }

            var binding = EditorCurveBinding.FloatCurve(Path, typeof(SkinnedMeshRenderer), PropertyName);

            if (RegisteredData == null)
            {
                AnimationUtility.SetEditorCurve(baseAnimationClip, binding, null);
                return;
            }

            var curve = new AnimationCurve();
            curve.AddKey(0f, RegisteredData.FirstFrameValue);
            AnimationUtility.SetEditorCurve(baseAnimationClip, binding, curve);

            EditorUtility.SetDirty(baseAnimationClip);
        }

        public float RegisteredFirstFrameDataOrZero()
        {
            if (RegisteredData == null)
            {
                return 0f;
            }
            else
            {
                return RegisteredData.FirstFrameValue;
            }
        }

        public void OnBeforeSerialize()
        {

        }

        public void OnAfterDeserialize()
        {
            Logging.Trace($"OnAfterDeserialize called for entry: {DisplayName}");
            if (onChangedCallback != null)
            {
                EditorApplication.delayCall += () => onChangedCallback();
            }
        }

        static string CalcDisplayName(string folderName, string propertyName)
        {
            if (string.IsNullOrEmpty(folderName))
            {
                return propertyName["blendShape.".Length..];
            }

            var blendShapeName = propertyName["blendShape.".Length..];

            if (blendShapeName.StartsWith(folderName, StringComparison.OrdinalIgnoreCase))
            {
                if (blendShapeName[folderName.Length..].IndexOfAny(new char[] { '_', ' ', '.' }) is 0)
                {
                    blendShapeName = blendShapeName[(folderName.Length + 1)..];
                }
            }

            return $"[{folderName}] {blendShapeName}";
        }
    }
}
