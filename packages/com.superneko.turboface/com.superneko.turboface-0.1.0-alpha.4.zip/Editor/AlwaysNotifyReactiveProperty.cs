using System;
using System.Collections.Generic;
using UniRx;

#nullable enable

namespace com.superneko.TurboFace
{
    public class AlwaysNotifyReadOnlyReactiveProperty<T> : ReadOnlyReactiveProperty<T>
    {
        readonly AlwaysFalseEqualityComparer<T> equalityComparer = new AlwaysFalseEqualityComparer<T>();

        public AlwaysNotifyReadOnlyReactiveProperty(AlwaysNotifyReactiveProperty<T> source)
            : base(source)
        {
            equalityComparer = new AlwaysFalseEqualityComparer<T>();
        }

        protected override IEqualityComparer<T> EqualityComparer => equalityComparer;
    }

    public class AlwaysNotifyReactiveProperty<T> : AlwaysNotifyReactiveProperty<T>
    {
        readonly AlwaysFalseEqualityComparer<T> equalityComparer = new AlwaysFalseEqualityComparer<T>();

        public AlwaysNotifyReactiveProperty()
            : base()
        {
        }

        public AlwaysNotifyReactiveProperty(T initialValue)
            : base(initialValue)
        {
        }

        protected override IEqualityComparer<T> EqualityComparer => equalityComparer;

        public ReadOnlyReactiveProperty<T> ToReadOnlyReactiveProperty()
        {
            return new AlwaysNotifyReadOnlyReactiveProperty<T>(this);
        }
    }
}
