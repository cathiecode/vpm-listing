using System;
using R3;

namespace com.superneko.TurboFace
{
    internal abstract class ReactiveService : IDisposable
    {
        IDisposable disposable;

        protected abstract void Initialize(DisposableBuilder d);

        public void Initialize()
        {
            var d = new DisposableBuilder();

            Initialize(d);

            disposable = d.Build();
        }

        protected virtual void OnDisposed() {}

        public void Dispose()
        {
            disposable.Dispose();
            OnDisposed();
        }
    }
}
