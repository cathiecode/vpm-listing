using System;
using R3;
using UnityEditor;
using UnityEngine;

#nullable enable

namespace com.superneko.TurboFace
{
    internal class AvatarModel : ReactiveService
    {
        class AvatarModelState : ScriptableSingleton<AvatarModelState>
        {
            public SerializableReactiveProperty<Transform?> AvatarRoot = new(null);
            public SerializableReactiveProperty<SkinnedMeshRenderer?> FaceSMR = new(null);
        }

        AvatarModelState? _state;

        AvatarModelState State
        {
            get
            {
                if (_state == null)
                {
                    _state = AvatarModelState.instance;
                }

                return _state;
            }
        }

        public ReadOnlyReactiveProperty<Transform?> AvatarRoot => State.AvatarRoot;
        public ReadOnlyReactiveProperty<SkinnedMeshRenderer?> FaceSMR => State.FaceSMR;
        public ReadOnlyReactiveProperty<float[]?> DefaultBlendShapeWeights => defaultBlendShapeWeights;

        readonly ReactiveProperty<float[]?> defaultBlendShapeWeights = new(null);

        protected override void Initialize(DisposableBuilder d)
        {
            Observable.CombineLatest(Observable.Interval(TimeSpan.FromSeconds(1)), State.FaceSMR, (_, smr) => smr)
                .Debounce(TimeSpan.FromMilliseconds(100))
                .Subscribe(UpdateDefaultBlendShapeWeights).AddTo(ref d);
        }

        public void SetAvatarRoot(Transform? newAvatarRoot)
        {
            if (State.AvatarRoot.Value == newAvatarRoot)
            {
                return;
            }

            State.AvatarRoot.Value = newAvatarRoot;

            if (newAvatarRoot == null)
            {
                SetFaceSMR(null);
                return;
            }

            if (FaceSMR.CurrentValue == null || !Utils.IsChildOf(FaceSMR.CurrentValue.transform, newAvatarRoot))
            {
                var faceTransform = newAvatarRoot.Find("body") ?? newAvatarRoot.Find("Body");

                if (faceTransform != null)
                {
                    var smr = faceTransform.GetComponentInChildren<SkinnedMeshRenderer>();

                    SetFaceSMR(smr);
                    return;
                }
            }
        }

        public void SetFaceSMR(SkinnedMeshRenderer? smr)
        {
            if (State.FaceSMR.Value == smr)
            {
                return;
            }

            State.FaceSMR.Value = smr;
        }

        void UpdateDefaultBlendShapeWeights(SkinnedMeshRenderer? smr)
        {
            if (smr == null)
            {
                defaultBlendShapeWeights.Value = null;
                return;
            }

            var blendShapeCount = smr.sharedMesh?.blendShapeCount ?? 0;
            var weights = new float[blendShapeCount];

            var changed = false;

            if (defaultBlendShapeWeights.CurrentValue == null || defaultBlendShapeWeights.CurrentValue.Length != blendShapeCount)
            {
                changed = true;
            }

            for (int i = 0; i < blendShapeCount; i++)
            {
                if (!changed && !Mathf.Approximately(defaultBlendShapeWeights.CurrentValue![i], smr.GetBlendShapeWeight(i)))
                {
                    changed = true;
                }

                weights[i] = smr.GetBlendShapeWeight(i);
            }

            if (changed)
            {
                Logging.Trace("AvatarModel: Default blend shape weights updated.");
                defaultBlendShapeWeights.Value = weights;
            }
        }
    }
}
